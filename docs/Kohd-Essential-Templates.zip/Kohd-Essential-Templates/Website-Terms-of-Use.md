**© Kohd Group Limited 2026. These templates are covered under Kohd Group Limited's workshop license and may be used internally for the purposes authorized. Based on original work by Suzanne Dibble.**

#### TERMS OF WEBSITE USE

This page (and the documents it refers to) tells you the terms of use on
which you may use our website \[**[INSERT YOUR WEBSITE DOMAIN
NAME]{.underline}**\] (**our site**), whether as a guest or a registered
user. Please read these terms of use carefully before you start to use
the site. By using our site, you accept these terms of use and agree to
abide by them. If you do not agree to these terms of use, please do not
use our site.

#### ABOUT US

**INCLUDE THE FOLLOWING IF YOU ARE TRADING THROUGH A LIMITED COMPANY:\
**\[**[INSERT YOUR WEBSITE DOMAIN NAME]{.underline}**\] is a site
operated by **[\[INSERT YOUR COMPANY NAME\]]{.underline}** (\"we\" or
"us"). We are registered in England and Wales under company number
**[\[INSERT YOUR COMPANY NUMBER\]]{.underline}**. Our registered office
address is \[**[INSERT YOUR REGISTERED OFFICE ADDRESS]{.underline}**\]
and our email address is **[\[INSERT YOUR CONTACT EMAIL
ADDRESS\].]{.underline}** Our VAT registration number is **[\[INSERT
YOUR VAT REGISTRATION NUMBER IF APPLICABLE -- IF YOU AREN'T VAT
REGISTERED, DELETE THE LAST SENTENCE\]]{.underline}**.

**INCLUDE THE FOLLOWING IF YOU ARE A SOLE TRADER OR PARTNERSHIP:**

\[**[INSERT YOUR WEBSITE DOMAIN NAME]{.underline}**\] is a site operated
by **[\[INSERT YOUR TRADING NAME EG ALISON PERSON TRADING AS "TRADING
ENTITIES"\]]{.underline}** (\"we\" or "us"). Our address is \[**[INSERT
YOUR TRADING ADDRESS]{.underline}**\] and our email address is
**[\[INSERT YOUR CONTACT EMAIL ADDRESS\].]{.underline}**

#### 

#### OUR SITE

We allow access to our site on a temporary basis and we reserve the
right to withdraw, restrict or change our site at any time and without
notice. We will not be liable if for any reason our site is unavailable
at any time or if the content is changed or out of date.

You must treat as confidential any user identification code, password or
other security feature in relation to our site. If, in our opinion, you
aren't complying with these terms of use, we have the right to disable
any such code, password or feature at any time.

You must comply with the provisions of our Acceptable Use Policy when
using our site.

It is your responsibility that anyone who accesses our site through your
internet connection is aware of these terms and complies with them.

#### VARIATIONS

We may revise these terms of use at any time by amending this page or by
provisions or notices published elsewhere on our site.

#### INTELLECTUAL PROPERTY RIGHTS

#### We are the owner or the licensee of all intellectual property rights in our site and the material published on it. Those works are protected by copyright laws and treaties around the world. All such rights are reserved. 

You must not use any part of the materials on our site for commercial
purposes without a licence from us or our licensors. You may not
reproduce in any format (including on another website) any part of our
site (including content, images, designs, look and feel) without our
prior written consent.

If, in our opinion, you are in breach of these provisions, your right to
use our site will cease immediately and you must either return or
destroy (as required by us) any copies of the materials you have made.

#### RELIANCE ON INFORMATION AND LINKS

The contents of our site (including links to other sites and resources
provided by third parties) are for information only, and we shall not be
liable for any use of, or reliance on, such materials. It shall be your
own responsibility to ensure that any products, services or information
available through this website meet your specific requirements.

#### INFORMATION ABOUT YOU AND YOUR VISITS TO OUR SITE

We process information about you in accordance with our Privacy Policy.
By using our site, you consent to such processing and you warrant that
all data provided by you is accurate.

#### LINKING TO OUR SITE

You may link to our home page only if you have first obtained our
written consent and provided that you do so in a way that is fair and
legal and does not damage our reputation or take advantage of it. We
reserve the right to withdraw linking permission without notice.

The website from which you are linking must comply in all respects with
our Acceptable Use Policy and must be owned by you.

You must not link in such a way as to suggest any form of association,
approval or endorsement on our part where none exists.

Our site must not be framed on any other site, nor may you create a link
to any part of our site other than the home page.

If you wish to make any use of material on our site other than that set
out above, please address your request to **[\[INSERT YOUR CONTACT EMAIL
ADDRESS\]]{.underline}**.

#### UPLOADING MATERIAL TO OUR SITE

When you upload material to our site, or make contact with other users
of our site, you must comply with our Acceptable Use Policy. If you
upload material in breach of our Acceptable Use Policy and we suffer
loss as a result, you will reimburse us for such loss.

Any material you upload to our site will be considered non-confidential
and non-proprietary and we have the right to use, copy, distribute and
disclose it to third parties. If any third party claims that any
material posted or uploaded by you to our site violates their
intellectual property rights, or their right to privacy, we have the
right to disclose your identity to them.

We will not be responsible, or liable to any third party, for the
content or accuracy of any materials posted by you or any other user of
our site.

We have the right to remove any material or posting you make on our site
if, in our opinion, such material does not comply with the content
standards set out in our Acceptable Use Policy.

#### VIRUSES, HACKING AND OTHER OFFENCES

You must not misuse our site by knowingly introducing any material which
is malicious or technologically harmful. You must not attempt to gain
unauthorised access to our site, the server on which our site is stored
or any server, computer or database connected to our site. You must not
attack our site via a denial-of-service attack or a distributed
denial-of service attack.

By failing to comply with this provision, you would commit a criminal
offence and your right to use our site will cease immediately and we
will report your actions to the relevant authorities.

#### OUR LIABILITY

The material displayed on our site is provided without any guarantees,
conditions or warranties as to its accuracy. To the extent permitted by
law, we hereby expressly exclude:

-   All conditions, warranties and other terms which might otherwise be
    implied by statute, common law or the law of equity.

-   Any liability for any direct, indirect or consequential loss or
    damage incurred by any user in connection with our site or in
    connection with the use, inability to use, or results of the use of
    our site, any websites linked to it and any materials posted on it
    (whether by us or a third party), including, without limitation any
    liability for:

    -   loss of income or revenue;

    -   loss of business;

    -   loss of profits or contracts;

    -   loss of anticipated savings;

    -   loss of data;

    -   loss of goodwill;

    -   wasted management or office time; and

for any other loss or damage of any kind, however arising and whether
caused by tort (including negligence), breach of contract or otherwise,
even if foreseeable.

This does not affect any liability which cannot be excluded or limited
under applicable law.

#### JURISDICTION AND APPLICABLE LAW

The English courts will have exclusive jurisdiction over any claim
arising from, or related to, a visit to our site.

These terms of use and any dispute or claim arising out of or in
connection with them or their subject matter or formation (including
non-contractual disputes or claims) shall be governed by and construed
in accordance with the law of England and Wales.
