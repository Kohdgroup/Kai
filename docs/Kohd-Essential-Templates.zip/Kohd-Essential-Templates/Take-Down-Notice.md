**© Kohd Group Limited 2026. These templates are covered under Kohd Group Limited's workshop license and may be used internally for the purposes authorized. Based on original work by Suzanne Dibble.**

***\[PRINT ON YOUR HEADED NOTEPAPER\]***

**\[INSERT THE RELEVANT INTERNET SERVICE PROVIDER'S NAME\]\
\[INSERT ADDRESS OF INTERNET SERVICE PROVIDER\]\
**

**\[INSERT DATE\]**

Dear Sirs,

**Notice and take-down letter under Article 14 of the E-Commerce
Directive** ***(2000/31/EC)***

1\. We are the owner of copyright in \[**INSERT DESCRIPTION OF COPYRIGHT
WORK**\] (**Work**), a copy of which is enclosed. The Work is an
original work which was created by \[**me**\] OR \[**INSERT NAME OF
EMPLOYEE**\], a British citizen, on \[**INSERT DATE OR PERIOD WHEN WORK
WAS MADE**\], \[in the course of \[his **OR** her\] employment with
us\].

2\. We discovered on \[**INSERT DATE**\] that a copy of \[the Work
**OR** a substantial part of the Work\] is currently being communicated
to the public on a website accessible via the URL \[**INSERT URL**\]
(**Offending Webpage**). Each time the Offending Webpage is accessed by
a member of the public, \[the Work **OR** a substantial part of the
Work\] is also reproduced. For ease of reference, we enclose a print out
of the Offending Webpage.

3\. The Work is being communicated to the public and reproduced as set
out above without the consent of our client. Accordingly, these acts
infringe our copyright contrary to sections 16 and 20 of the Copyright,
Designs and Patents Act 1988.

4\. The Offending Webpage is hosted by you. We hereby gives you actual
knowledge of the above infringements of our rights within the meaning of
Article 14(1)(a) of the E-Commerce Directive (*2000/31/EC*), and request
that you act expeditiously to remove or disable access to the Offending
Webpage.

5\. If we receive confirmation within **\[seven\]** days of the date of
this letter that you have removed or disabled access to the Offending
Webpage, we will take no further action against you in respect of this
matter. If this confirmation is not received, we reserve the right to
issue proceedings against you seeking relief for infringement of
copyright. If proceedings become necessary (which may be issued and
served without further notice to you), the remedies that may be
available to us include an injunction, delivery up or (at our option)
destruction of all infringing copies, damages or an account of profits,
legal costs and interest. In the meantime, we reserve all our rights in
this matter.

6\. This is a complex area of law and we recommend that you seek
independent legal advice immediately.

We look forward to hearing from you by \[**INSERT TIME**\] on \[**INSERT
DATE**\].

Yours faithfully

\...\...\...\...\...\...\...\...\...\...\...\...\...\...\...\...\...\...\...\...\....

**\[INSERT YOUR NAME OR THE NAME OF YOUR LIMITED COMPANY\]**
