**© Kohd Group Limited 2026. These templates are covered under Kohd Group Limited's workshop license and may be used internally for the purposes authorized. Based on original work by Suzanne Dibble.**

**\[NOTE: THIS LETTER IS TO BE USED AFTER YOU HAVE SENT A FEW CHASING
EMAILS AND TRIED TO DISCUSS THE OUTSANDING DEBT ON THE PHONE. IF YOU
RECEIVE NO REPLY TO THIS LETTER WITHIN THE TIME PERIOD, THE NEXT STEP IS
TO SEND THE LETTER BEFORE ACTION\]**

**[\[PRINT OUT ON YOUR HEADED PAPER\]]{.underline}**

**              **

**\[INSERT NAME OF DEBTOR\]**

**\[INSERT ADDRESS\]**

**\[INSERT DATE\]**

Dear Sir/ Madam \[**or the name of the individual you have been dealing
with**\]

**Re: [AMOUNT DUE: £\[INSERT AMOUNT OWED\]]{.underline}**

The above amount is outstanding and is now overdue by \[**INSERT NUMBER
OF DAYS**\] days. We enclose copies of the relevant invoice(s) for your
ease of reference.

We demand immediate payment of the above amount.

You should make payment of the amount of £\[**INSERT AMOUNT OWED**\] by
\[**SET OUT ACCEPTABLE METHODS OF PAYMENT**\] to arrive with us in
cleared funds by no later than **7 days from the date of this letter
(namely \[INSERT DATE\]).**

If for some reason, you are not able to pay the amount owed in full by
this date, you should call us on \[**INSERT YOUR PHONE NUMBER**\] or
email us at \[**INSERT YOUR EMAIL ADDRESS**\] to discuss a possible
repayment proposal.

If you do not pay the outstanding amount or contact us by \[**INSERT THE
SAME DATE AS IN PARAGRAPH 3 ABOVE**\], we may have no option but to
bring a claim against you and will seek orders for **court costs and
interest** as well as the amount of the debt. If default judgment is
obtained your credit standing will be adversely effected.

We look forward to hearing from you and to immediate payment of the
amount due. 

*Yours faithfully*

* *

**[\[INSERT YOUR BUSINESS NAME\]]{.underline}**
