# Version Control & Change Log

**Document Version:** 1.0  
**Last Updated:** 2026-05-09  
**Git Status:** Ready for version control

---

## 📌 Setup for Git Version Control

### Initialize Git (if not already done):
```bash
cd /Users/neilriley/Documents/Claude/Projects/Legal\ Templates/Kohd-Essential-Templates/
git init
git config user.name "Kohd Group Limited"
git config user.email "legal@kohd.ai"
```

### Initial Commit:
```bash
git add .
git commit -m "Initial Kohd Essential Templates v1.0 with legal skills workflow

- 18 legal templates customized for Kohd Group Limited
- Copyright updated to 2026
- UK law compliance audit completed
- Legal skills workflow documentation added
- README and customization guides included"
```

---

## 🔄 Change Log

| Version | Date | Changes | Author | Status |
|---------|------|---------|--------|--------|
| 1.0 | 2026-05-09 | Initial release with 18 templates, legal skills workflow, README | Claude AI | ✓ Ready |
| 1.1 | TBD | Quarterly UK law compliance update | — | Pending |
| 2.0 | TBD | Additional templates or major restructure | — | Planned |

---

## 📝 File Structure & Versioning

```
Kohd-Essential-Templates/
├── README.md (version 1.0)
├── LEGAL-SKILLS-WORKFLOW.md (version 1.0)
├── VERSION-CONTROL.md (this file)
├── COMPLIANCE-AUDIT.md (version 1.0)
│
├── [Core Contracts]
│   ├── NDA_Simple-NDA-mutual-2022_-_Kohd_Group.md (v1.0)
│   ├── Consultancy-agreement-b2b.md (v1.0)
│   ├── Terms-for-supply-of-services-b2b-no-proposal1.md (v1.0)
│   └── Terms-for-supply-of-services-ltd-co-b2b.md (v1.0)
│
├── [Compliance]
│   ├── GDPR-compliant-cookie-policy-v2.md (v1.0 - updated 2024 ICO)
│   ├── Legal_One-page-hard-copy-privacy-notice-2022.md (v1.0)
│   ├── GDPR-Checklist.md (v1.0)
│   └── Website-Terms-of-Use.md (v1.0)
│
├── [IP Protection]
│   ├── IP-assignment-letter-2021-v1.1-1.md (v1.0)
│   ├── Copyright-Notice-2021.md (v1.0)
│   ├── Take-Down-Notice.md (v1.0)
│   └── Letter-to-send-to-content-thief-2021.md (v1.0)
│
└── [Operational]
    ├── Email-disclaimer-and-confidentiality-wording-2021.md (v1.0)
    ├── Invoice-template.md (v1.0)
    ├── Letter-demanding-payment.md (v1.0)
    ├── FreelanceAgreement202111.md (v1.0)
    ├── Website-development-agreement.md (v1.0)
    └── Force-majeure-and-termination-clauses-2021.md (v1.0)
```

---

## 🔐 Naming Convention for Contract Files

When customizing templates for specific clients/purposes, use this naming convention:

**Format:** `YYYY-MM-DD-TemplateType-ClientName-Version.md`

**Examples:**
```
2026-05-09-NDA-ABC-Corp-v1.0.md
2026-05-09-Services-Terms-XYZ-Ltd-v1.1.md
2026-05-20-Consultancy-Agreement-Jane-Smith-v1.0.md
```

**Archive customized versions:** Store finalized contracts in:
```
../Signed-Contracts/YYYY/MM/
```

---

## 📊 Contract Registry (Maintain in Spreadsheet or Linear)

```
Date | Template Type | Client/Party | Version | Status | Signed Date | Notes
2026-05-09 | NDA | ABC Corp | v1.0 | ✓ Signed | 2026-05-15 | Standard terms, no redlines
2026-05-09 | Services | XYZ Ltd | v1.1 | ◐ Negotiating | — | Waiting on payment terms feedback
2026-05-09 | IP Assignment | Contractor-1 | v1.0 | ✓ Signed | 2026-05-10 | Web development project IP
```

---

## 🔄 Update & Review Schedule

### Quarterly (Every 3 months):
- [ ] Check for new UK law updates
- [ ] Review active contracts for upcoming renewals
- [ ] Audit template compliance

### Annually (Every May):
- [ ] Full legal compliance audit
- [ ] Update any UK law references
- [ ] Collect feedback from template use
- [ ] Update version numbers
- [ ] Create new release notes

### As-Needed:
- [ ] When UK law changes significantly
- [ ] When regulatory guidance updates
- [ ] When Kohd's business model changes
- [ ] When issues found in template use

---

## 📋 Pre-Release Checklist

Before updating template versions:

- [ ] UK law compliance verified
- [ ] All copyright notices correct (Kohd Group Limited 2026)
- [ ] All [INSERT...] placeholders present and clear
- [ ] No personal/sample data included
- [ ] README updated with changes
- [ ] Change log entry added
- [ ] Tested with legal:review-contract skill
- [ ] Legal counsel review (if significant changes)
- [ ] Version number incremented
- [ ] Git commit created with clear message

---

## 🚀 Deployment Checklist

When deploying customized template:

**Before Sending to External Party:**
- [ ] All [INSERT...] fields completed
- [ ] Company name/details correct
- [ ] Payment terms match Kohd's policy
- [ ] Run legal:review-contract
- [ ] Run legal:legal-risk-assessment
- [ ] Document decision in contract registry
- [ ] Get internal approval if value > £10k
- [ ] File customized version in archive

**Before Signature:**
- [ ] Run legal:signature-request
- [ ] All parties confirmed correct
- [ ] All dates/amounts verified
- [ ] E-signature workflow configured (if applicable)
- [ ] Sign and file in signed contracts folder

---

## 📞 Contact & Ownership

**Repository Owner:** Kohd Group Limited  
**Last Updated By:** Claude AI  
**Next Review Date:** 2027-05-09  
**Contact for Updates:** [INSERT LEGAL CONTACT]  
**Email:** [INSERT EMAIL]  

---

## Git Commands Reference

```bash
# View change history
git log --oneline

# View specific file history
git log -p LEGAL-SKILLS-WORKFLOW.md

# Create new version/branch
git checkout -b v1.1-template-updates

# Merge updates back to main
git checkout main
git merge v1.1-template-updates

# View differences
git diff VERSION-CONTROL.md
```

