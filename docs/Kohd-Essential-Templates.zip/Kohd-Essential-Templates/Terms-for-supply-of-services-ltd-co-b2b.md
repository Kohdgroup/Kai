**© Kohd Group Limited 2026. These templates are covered under Kohd Group Limited's workshop license and may be used internally for the purposes authorized. Based on original work by Suzanne Dibble.**

**\[NOTE: TERMS OF BUSINESS ARE YOUR MAIN BUSINESS PROTECTION AND IT IS
ALWAYS RECOMMENDED THAT YOU INSTRUCT AN EXPERIENCED LAWYER TO DRAFT
TAILORED TERMS OF BUSINESS TO PROTECT YOU AGAINST ALL RISKS\]**

**\[NOTE THIS DOCUMENT IS ONLY FOR USE WHERE (1) YOU ARE TRADING THROUGH
A LIMITED COMPANY AND THERE IS A SPECIFIED INDIVIDUAL PROVIDING THE
SERVICES (WHO COULD BE YOU), (2) YOU ARE SUPPLYING SERVICES (NOT GOODS),
(3) YOU ARE SUPPLYING A BUSINESS (NOT A CONSUMER) AND (4) YOU ARE USING
A PROPOSAL -- THESE TERMS WOULD BE PRINTED AT THE BACK OF THE PROPOSAL
AND YOU MUST MAKE REFERENCE TO THE TERMS IN YOUR MAIN PROPOSAL BY USING
THE WORDS "THE TERMS AND CONDITIONS SET OUT AT THE BACK OF THIS PROPOSAL
SHALL APPLY TO ANY CONTRACT ENTERED INTO BETWEEN US IN RELATION TO THE
SUBJECT MATTER OF THIS PROPOSAL"\]**

**\[INSERT YOUR LIMITED COMPANY NAME\]**

**STANDARD TERMS OF BUSINESS**

1.  Interpretation
    ==============

    1.  The definitions and rules of interpretation in this clause apply to these Terms.
        --------------------------------------------------------------------------------

**Capacity**: as agent, consultant, director, employee, owner, partner,
shareholder or in any other capacity.

**Confidential Information**: confidential information in whatever form
relating to your business, customers, products, affairs and finances for
the time being confidential to you.

**Contract**: the contract between you and us for the supply of Services
in accordance with these Terms.

**Deliverables:** all documents, products and materials developed by us
or our agents, subcontractors, consultants and employees in relation to
the Services in any form, including computer programs, data, reports and
specifications (including drafts).

**\[Equipment:** any equipment, systems, cabling or facilities provided
by you and used directly or indirectly in the supply of the
Services.\]\[**NOTE: YOU CAN DELETE THIS DEFINITION IF YOUR CLIENT IS
NOT GOING TO BE PROVIDING ANY EQUIPMENT**\]

**Individual:** means \[**INSERT YOUR NAME** **OR THE RELEVANT
INDIVIDUAL WHO WILL BE PROVIDING THE SERVICES**\] of \[**INSERT RELEVANT
ADDRESS**\] or such other person as specified in the Proposal.

**Intellectual Property Rights**: patents, rights to inventions,
copyright and related rights, moral rights, trademarks, trade names and
domain names, rights in get-up, rights in goodwill or to sue for passing
off, rights in designs, rights in computer software, database rights,
rights in confidential information (including know-how and trade
secrets) and any other intellectual property rights, in each case
whether registered or unregistered and including all applications (or
rights to apply) for, and renewals or extensions of, such rights and all
similar or equivalent rights or forms of protection which may now or in
the future subsist in any part of the world.

**\[Manager:** your manager for the Services, appointed by you in
accordance with clause 3.2.\]\[**NOTE: DELETE THIS DEFINITION IF YOU
HAVE DELETED THE WORDS IN SQUARE BRACKETS IN CLAUSE 3.2**\]

**Proposal: **your order for the Services as set out at the front of
these Terms.

**Services**: the services that we are providing to you in a consultancy
capacity as set out in the Proposal.

**Substitute**: a substitute for the Individual appointed under the
terms of clause 4.2.

**Terms**: the terms and conditions set out in this document.

**\[Training Session**: any training session, seminar or workshop
provided by us in accordance with these Terms.\]\[**NOTE: DELETE THIS
DEFINITION IF YOU ARE NOT PROVIDING TRAINING AS PART OF THE SERVICES**\]

**We/us**: \[**INSERT YOUR LIMITED COMPANY NAME\]** with our registered
office at \[**INSERT YOUR REGISTERED OFFICE ADDRESS**\], a company
registered in England and Wales under company number \[**INSERT COMPANY
NUMBER**\]. \[Our VAT registration number is \[**PLEASE INSERT VAT
REGISTRATION NUMBER**\].\[**NOTE: DELTETE THE LAST SENTENCE IF YOU ARE
NOT VAT REGISTERED**\].

**writing or written**: includes email.

2.  The headings do not affect the interpretation of these Terms.
    -------------------------------------------------------------

3.  A reference to a particular law is a reference to it as it is in force for the time being taking account of any amendment, extension, or re-enactment and includes any subordinate legislation for the time being in force made under it.
    -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

4.  Unless the context otherwise requires, words in the singular include the plural and in the plural include the singular.
    -----------------------------------------------------------------------------------------------------------------------

```{=html}
<!-- -->
```
2.  Basis of Agreement
    ==================

    1.   These Terms and the Proposal constitute the entire agreement between you and us. You acknowledge that you have not relied on any statement, promise or representation made or given by or on behalf of us that is not set out in these Terms or the Proposal.
        -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    2.  If any of these Terms are inconsistent with any term of the Proposal, the Proposal shall prevail.
        -------------------------------------------------------------------------------------------------

    3.  These Terms shall become binding on you and us and a contract shall be formed between us upon the earlier of (a) you signing and returning to us the Proposal; or (b) you instructing us to commence work in relation to the Proposal (whether in writing, (including by email) or orally), whichever is the earlier.
        ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    4.  Any quotation for the Services is given on the basis that a binding contract shall only come into existence in accordance with [Clause 2.3](http://commercial.practicallaw.com/3-384-9404?q=terms%20and%20conditions#a985708).
        ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

3.  Your Duties
    ===========

You will: {#you-will .list-paragraph}
---------

1.  provide to us all the information we reasonably request to allow us to provide the Services;
    --------------------------------------------------------------------------------------------

2.  co-operate with us in all matters relating to the Services \[and appoint the Manager in relation to the Services, who shall have the authority contractually to bind you on matters relating to the Services\] \[**NOTE: YOU CAN DELETE THE WORDS IN SQUARE BRACKETS IN CLAUSE 3.2 IF THE CLIENT IS A SMALL BUSINESS**\];
    -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

3.  \[provide, for us, our agents, subcontractors, consultants and employees, in a timely manner and at no charge, access to your premises, office accommodation, data and other facilities as we reasonably require in order to provide you with the Services;\]
    -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

4.  \[be responsible (at your own cost) for preparing and maintaining the relevant premises for the supply of the Services, including identifying, monitoring, removing and disposing of any hazardous materials from your premises in accordance with all applicable laws, before and during the supply of the Services at those premises, and informing us of all of your obligations and actions under this clause 3.4;\]
    ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

5.  \[inform us of all health and safety rules and regulations and any other reasonable security requirements that apply at your premises;\]
    ----------------------------------------------------------------------------------------------------------------------------------------

\[**NOTE: YOU CAN DELETE CLAUSES 3.3, 3.4 AND 3.5 IF THERE IS NO PROSPECT OF YOU HAVING TO ACCESS YOUR CLIENT'S OFFICES**\] {#note-you-can-delete-clauses-3.3-3.4-and-3.5-if-there-is-no-prospect-of-you-having-to-access-your-clients-offices .list-paragraph}
---------------------------------------------------------------------------------------------------------------------------

6.  \[ensure that all Equipment is in good working order and suitable for the purposes for which it is used in relation to the Services; and\]\[**NOTE: YOU CAN DELTE THIS CLAUSE 3.6 IF YOUR CLIENT IS NOT PROVIDING ANY EQUIPMENT**\]
    -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

7.  obtain and maintain all necessary licences and consents and comply with all relevant legislation in relation to the Services \[and the use of the Equipment\], before the date on which the Services are to start.\[**NOTE: DELETE THE WORDING IN SQUARE BRACKETS IF THE CLIENT IS NOT PROVIDING ANY EQUIPMENT**\]
    ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

```{=html}
<!-- -->
```
4.  Our Duties
    ==========

    1.  We shall procure that the Individual shall:
        -------------------------------------------

        a.  ### provide the Services with all due care, skill and ability; 

        b.  ### unless prevented by ill health or accident, devote such time to the carrying out of the Services as may be necessary for their proper performance; 

        c.  ### use reasonable endeavours to meet any performance dates specified in the Proposal, but any such dates shall be estimates only and time for performance by us shall not be of the essence of this Contract; and

        d.  ### \[use reasonable endeavours to observe all health and safety rules and regulations and any other reasonable security requirements that apply at your premises and that have been communicated to us under clause 3.5, provided that we shall not be liable under these Terms if, as a result of such observation, we are in breach of any of our obligations under these Terms.\]\[**NOTE: DELETE THIS CLAUSE 4.1(d) IF YOU ARE NOT LIKELY TO ACCESS YOUR CLIENT'S PREMISES**\]

    2.  We may, \[with your prior written approval and\]\[**NOTE: DELETE THE WORDS IN SQUARE BRACKETS IF YOU WANT THE RIGHT TO SUBSTITITE WHOEVER YOU LIKE WITHOUT YOUR CLIENT'S CONSENT**\] subject to the following proviso, appoint a suitably qualified and skilled Substitute to perform the Services in place of the Individual, provided that the Substitute shall be required to enter into direct undertakings with you, including with regard to confidentiality. If you accept the Substitute, we shall continue to invoice you in accordance with clause 5 and shall be responsible for the remuneration of the Substitute.
        -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    3.  We may use a third party to perform any administrative, clerical, secretarial or other functions which are reasonably incidental to the provision of the Services provided that you will not be liable to bear the cost of such functions.
        ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

5.  Fees and Booking
    ================

    1.  The charges for the Services are as set out in the Proposal. 
        ------------------------------------------------------------

    2.  Where the Services are provided for a fixed price, the total price for the Services shall be the amount set out in the Proposal. 
        --------------------------------------------------------------------------------------------------------------------------------

    3.  For \[Training Sessions or other\] Services where the Proposal refers to one single payment, we will invoice you for the fixed price in advance.\[**NOTE: DELETE THE WORDS IN SQUARE BRACKETS IF YOU ARE NOT PROVIDING TRAINING**\]
        -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    4.  Where the Proposal refers to payment of a deposit, stage payments or retainers we will invoice you for the deposit in advance and for each stage payment or retainer at the time or at the stage of the project specified in the Proposal.
        ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    5.  Where the Services are provided on a time-and-materials basis:
        --------------------------------------------------------------

        a.  the charges payable for the Services shall be calculated in
            accordance with our standard hourly or daily fee rates as
            amended from time to time;

        ```{=html}
        <!-- -->
        ```
        a.  our daily fee rates are calculated on the basis of an
            eight-hour day worked between \[8.00 am and 5.00
            pm\]\[**NOTE: AMEND THE HOURS IN SQUARE BRACKETS AS
            APPROPRIATE**\] on weekdays (excluding weekends and public
            holidays);

        b.  we shall be entitled to charge at an overtime rate of
            \[**INSERT PERCENTAGE**\] of the normal rate for part days
            and for time worked outside the hours referred to in
            condition 5.4(b) above on a pro-rata basis; and

        c.  we will invoice you monthly in arrears unless other
            arrangements (such as stage payments) are set out in the
            Proposal.

    6.  \[Where no specific Training Sessions are specified in the Proposal or where you wish to book additional Training Sessions, you may agree these with us by telephone or email.\]
        --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    7.  \[Where additional Training Sessions are booked, we will invoice you after you have made a booking and before the relevant Training Session(s) and you must pay us in full in cleared funds before the relevant Training Session.\]
        -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

\[**NOTE: DELTETE CLAUSES 5.6 and 5.7 IF YOU AREN'T PROVIDING TRAINING**\]  {#note-deltete-clauses-5.6-and-5.7-if-you-arent-providing-training .list-paragraph}
--------------------------------------------------------------------------

8.  All charges are stated exclusive of VAT which shall be added to the charges at the applicable rate (where necessary).
    ---------------------------------------------------------------------------------------------------------------------

9.  You must pay each of our invoices in full, and in cleared funds by the payment method specified on the invoice, within \[7\] days of the date of the invoice. 
    -------------------------------------------------------------------------------------------------------------------------------------------------------------

10. Without prejudice to any other right or remedy, if you fail to pay the invoice on the due date, we may:
    -------------------------------------------------------------------------------------------------------

    a.  ###  charge interest on the sum from the due date for payment at the annual rate of 4% above the base lending rate from time to time of \[**INSERT NAME OF YOUR BANK**\], accruing on a daily basis and being compounded quarterly until payment is made, whether before or after any judgment and you shall pay the interest immediately on demand; and

    b.  ### suspend all Services until payment has been made in full. 

11. All charges are stated exclusive of expenses incurred by us. Subject to your prior written consent, you will reimburse us for all training venue, hotel, subsistence, travelling, stationery, materials, postage, other administrative costs and any other ancillary expenses reasonably incurred by us or the Individual in providing the Services. Such expenses may be invoiced by us at cost at such times as we think appropriate. \[Invoices relating to the costs of hiring training venues must be paid in full in cleared funds prior to the date of the Training Session.\]\[**NOTE: DELETE THE WORDS IN SQUARE BRACKETS IF NOT APPLICABLE**\]
    --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

```{=html}
<!-- -->
```
6.  Cancellation
    ============

    1.  You may cancel any Training Session (but no other Services) by notice in writing to us.
        ---------------------------------------------------------------------------------------

    2.  On cancellation of a Training Session you must pay us the following fees:
        -------------------------------------------------------------------------

        a.  ### if notice of cancellation is received \[24/48 hours\] or less before the start of the relevant Training Session, a cancellation fee of \[100%\] of the fee for the Training Session;

        b.  ### if notice of cancellation is received \[7 days or less\] before the start of the relevant Training Session, a cancellation fee of \[50%\] of the fee for the Training Session;

        c.  ### if notice of cancellation is received \[more than 7 days but less than 14 days\] before the start of the relevant Training Session, a cancellation fee of \[25%\] of the fee for the Training Session; and

        d.  ### if notice of cancellation is received \[more than 14 days\] before the start of the relevant Training Session no cancellation fee is payable.

### \[**NOTE DELTE THIS CLAUSE 6 IF YOU ARE NOT PROVIDING TRAINING**\] {#note-delte-this-clause-6-if-you-are-not-providing-training .list-paragraph}

Other activities
================

Nothing in these Terms shall prevent us or the Individual from being
engaged, concerned or having any financial interest in any Capacity in
any other business, trade, profession or occupation provided that such
activity does not cause a breach of any of our obligations under these
Terms.

8.  Confidential information and our materials
    ==========================================

    1.  We acknowledge that in the course of providing the Services we will have access to Confidential Information. We shall not and we shall procure that the Individual shall not (except in the proper course of our duties) use or disclose to any third party any Confidential Information. 
        -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    2.  You will keep in strict confidence all technical or commercial know-how, specifications, inventions, processes or initiatives which are of a confidential nature and which we or our employees, agents, consultants or subcontractors have disclosed to you and any other confidential information concerning our business or our products and services which you may obtain.
        -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    3.  The restrictions in clauses 8.1 and 8.2 do not apply to:
        --------------------------------------------------------

        a.  ### any use or disclosure required by law or authorised by the party to whom the information relates; or

        b.  ### any information which is already in, or comes into, the public domain otherwise than through unauthorised disclosure by the party to whom the information does not relate.

    4.  All materials, equipment and tools, drawings, specifications and data which we supply to you shall, at all times, be and remain our exclusive property, but shall be held by you in safe custody at your own risk and maintained and kept in good condition by you until returned to us, and shall not be disposed of or used other than in accordance with our written instructions or authorisation.
        ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

9.  Data protection
    ===============

    1.  You consent to our holding and processing data relating to you for legal, personnel, administrative, management and marketing purposes.
        ---------------------------------------------------------------------------------------------------------------------------------------

    2.  You consent to our making such information available to those who provide products or services to us such as advisers, regulatory authorities, governmental or quasi-governmental organisations and potential purchasers of us or any part of our business.
        -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    3.  You consent to the transfer of such information to our business contacts (such as server hosts) outside the European Economic Area.
        -----------------------------------------------------------------------------------------------------------------------------------

10. Intellectual property
    =====================

    1.  We are the owner or the licensee of all Intellectual Property Rights and all other rights in the Services and the Deliverables and nothing in these Terms or otherwise shall operate to transfer the ownership of the Intellectual Property Rights in the Services or the Deliverables. We grant you a limited, non-exclusive, non-transferable, non-sub licensable revocable licence to use all or any of the Deliverables for the purposes for which the Services were provided only.
        ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    2.  You grant to us a non-exclusive perpetual, worldwide, royalty free licence to use all or any of your Intellectual Property Rights in any materials or content you submit to us.
        -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    3.  You acknowledge that, where we do not own any of the materials or content which we submit to you, your use of rights in such materials or content is conditional on our obtaining a written licence (or sub-licence) from the relevant licensor or licensors on such terms as will entitle us to license such rights to you.
        ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

11. Termination
    ===========

    1.  Notwithstanding the provisions of clause 2, we may terminate this Contract on \[1\] months' notice for any reason with no liability to provide any further services to you.
        ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    2.  You may terminate this Contract if we commit any serious or repeated breach or non-observance of any of the provisions of this Contract and such breach is not remedied within 14 days of notification of breach.
        -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    3.  Notwithstanding the provisions of clause 2 or clause 11.1, we may terminate this Contract with immediate effect with no liability to provide any further services to you if at any time:
        ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

```{=html}
<!-- -->
```
1.  

2.  

3.  

4.  

5.  

6.  

7.  

8.  

9.  

10. 1.  a.  ### you fail to make a payment when due and payable under this Contract;

        b.  ### you commit any gross misconduct affecting our business;

        c.  ### you commit any serious or repeated breach or non-observance of any of the provisions of this Contract;

        d.  ### you are convicted of any criminal offence (other than an offence under any road traffic legislation in the United Kingdom or elsewhere for which a fine or non-custodial penalty is imposed);

        e.  ### you commit any fraud or dishonesty or carry out business or otherwise act in any manner which in our opinion brings or is likely to bring us into disrepute or is materially adverse to our interests.

        f.  ### an order is made or a resolution is passed for your winding up, or circumstances arise which entitle a court of competent jurisdiction to make an order winding you up; 

        g.  ### an order is made for the appointment of an administrator to manage your affairs, business and property, or documents are filed with a court of competent jurisdiction for the appointment of an administrator for you, or notice of intention to appoint an administrator is given by you or your directors or by a qualifying floating charge holder (as defined in paragraph 14 of Schedule B1 to the Insolvency Act 1986); 

        h.  ### a receiver is appointed of any of your assets or undertaking, or if circumstances arise which entitle a court of competent jurisdiction or a creditor to appoint a receiver or manager for you, or if any other person takes possession of or sells your assets; or

        i.  ### you make any arrangement or composition with your creditors, or make an application to a court of competent jurisdiction for the protection of your creditors in any way, or become bankrupt; or

        j.  ### you cease, or threaten to cease, to trade; or

        k.  ### you take or suffer any similar or analogous action in any jurisdiction in consequence of debt; or

        l.  ### being an individual, you are subject to a bankruptcy order or are made bankrupt.

    ```{=html}
    <!-- -->
    ```
    1.  Our rights under this clause 11 are without prejudice to any other rights that we might have at law to terminate the Contract. Any delay by us in exercising our rights to terminate shall not constitute a waiver of these rights. 
        -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    2.  We shall not be obliged to retain documents and information relating to you after termination of this Contract. 
        ---------------------------------------------------------------------------------------------------------------

Obligations on termination
==========================

On termination of this Contract you shall immediately pay to us any unpaid fees or other sums payable under this Contract. Termination will not affect either party\'s outstanding rights or duties, including our right to recover from you any money you owe us under these Terms. {#on-termination-of-this-contract-you-shall-immediately-pay-to-us-any-unpaid-fees-or-other-sums-payable-under-this-contract.-termination-will-not-affect-either-partys-outstanding-rights-or-duties-including-our-right-to-recover-from-you-any-money-you-owe-us-under-these-terms. .list-paragraph}
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Status 
======

Our relationship to you will be that of independent contractor and nothing in these Terms shall render us or the Individual your employee, worker, agent or partner and we shall not hold ourselves out as such. {#our-relationship-to-you-will-be-that-of-independent-contractor-and-nothing-in-these-terms-shall-render-us-or-the-individual-your-employee-worker-agent-or-partner-and-we-shall-not-hold-ourselves-out-as-such. .list-paragraph}
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

14. Limitation of Liability
    =======================

    1.  Other than (i) liability for death or personal injury to any
        person caused by our negligence, (ii) liability for any fraud or
        fraudulent misrepresentation made by us or (iii) liability for
        any other matter which we may not legally exclude or limit, we
        exclude all liability for any loss or damage suffered by you
        resulting from the Contract (including all consequential loss or
        damage howsoever caused and whether or not this was in your or
        our reasonable contemplation and including any loss or damage
        suffered by you as a result of advice or opinions given by the
        Individual or by any of our employees, agents, consultants or
        subcontractors).

    2.  If we are prevented from or delayed in performing our
        obligations by your act or omission (or the act or omission of
        your agents, subcontractors, consultants or employees) or by any
        circumstance outside of our control, we shall not be liable for
        any costs, charges or losses sustained or incurred by you that
        arise directly or indirectly from such prevention or delay.

    3.  In the event that we are found liable to you for any loss or
        damage, this liability shall be limited to the amount of any
        fees you paid to us in accordance with these Terms in the 12
        months preceding the judgment. In the event that a court of
        competent jurisdiction does not allow such limitation on
        liability and awards damages against us in excess of such
        amount, you agree to release us from all damages and liability
        in excess of such amount.

    4.  All warranties, conditions and other terms implied by statute or
        common law are, to the fullest extent permitted by law, excluded
        from these Terms.

    5.  This clause 14 shall survive termination of the Contract.

15. Notices
    =======

All notices sent by you to us must be sent to \[**INSERT YOUR NAME AND
ADDRESS**\] or by email to \[INSERT YOUR E-MAIL ADDRESS\]. We may give
notice to you at either the e-mail or postal address you provide to us
in the Proposal or as subsequently notified by you. Notice will be
deemed received and properly served 24 hours after an e-mail is sent or
three days after the date of posting of any letter. In proving the
service of any notice, it will be sufficient to prove, in the case of a
letter, that the letter was properly addressed, stamped and placed in
the post and, in the case of an e-mail, that the e-mail was sent to the
specified e-mail address of the addressee.

16. Assignment and subcontracting
    =============================

    1.  We may at any time assign, transfer, charge, subcontract or deal in any other manner with all or any of our rights under these Terms.
        -------------------------------------------------------------------------------------------------------------------------------------

    2.  You shall not, without our prior written consent, assign, transfer, charge, subcontract or deal in any other manner with all or any of your rights or obligations under these Terms.
        ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

17. General
    =======

    1.   If any court or competent authority decides that any of the provisions of these Terms are invalid, unlawful or unenforceable to any extent, the term will, to that extent only, be severed from the remaining terms, which will continue to be valid to the fullest extent permitted by law.
        --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    2.  No failure or delay by us to exercise any right or remedy provided under these Terms or by law shall constitute a waiver of that (or any other) right or remedy, nor preclude or restrict its further exercise. No single or partial exercise of such right or remedy shall preclude or restrict the further exercise of that (or any other) right or remedy.
        -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    3.  Except as set out in these Terms, any variation, including the introduction of any additional terms and conditions, to the Contract, shall only be binding when agreed in writing and signed by us.
        ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    4.  A person who is not party to these Terms shall not have any rights under or in connection with them under the Contracts (Rights of Third Parties) Act 1999.
        -----------------------------------------------------------------------------------------------------------------------------------------------------------

    5.  These Terms and any dispute or claim arising out of or in connection with them or their subject matter or formation (including non-contractual disputes or claims) shall be governed by English law and you and we both agree to the exclusive jurisdiction of the English courts.
        ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

 {#section .list-paragraph}
