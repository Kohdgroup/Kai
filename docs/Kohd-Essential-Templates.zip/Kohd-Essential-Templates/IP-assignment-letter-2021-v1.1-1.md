**© Kohd Group Limited 2026. These templates are covered under Kohd Group Limited's workshop license and may be used internally for the purposes authorized. Based on original work by Suzanne Dibble.**

**\[NOTE: DELETE ALL NOTES, THE COPYRIGHT NOTICE ABOVE AND ANY SQUARE
BRACKETS WITHIN THE DOCUMENT BEFORE SENDING IT TO THE ASSIGNOR\]**

**\[NOTE: THE PERSON/S WHO OWNS THE COPYRIGHT IS THE ASSIGNOR AND THE
PERSON TO WHOM OWNERSHIP IS BEING TRANSFERRED IS THE ASSIGNEE. THE
PERSON WHO CREATED THE WORK IS THE OWNER OF THE COPYRIGHT, EVEN WHEN
THEY ARE PAID TO PRODUCE IT, EXCEPT WHERE AN EMPLOYEE HAS CREATED A WORK
IN THE COURSE OF THEIR EMPLOYMENT, IN WHICH CASE THE EMPLOYER OWNS IT --
NO SPECIAL TERMS ARE REQUIRED IN AN EMPLOYMENT AGREEMENT: THAT IS THE
LEGAL POSITION UNLESS ANY WRITTEN AGREEMENT STATES ANYTHING TO THE
CONTRARY\]**

**\[NOTE: THIS ASSIGNMENT IS IN FAVOUR OF THE ASSIGNEE. IF YOU ARE
ASSIGNING COPYRIGHT IN YOUR DELIVRABLES, INCLUDE THE ASSIGNMENT IN YOUR
MAIN TERMS OF BUSINESS -- SEE THE STAND ALONE IP ASSIGNMENT CLAUSES FOR
THIS\]**

**\[PRINT ON YOUR HEADED PAPER\]**

**\[INSERT NAME OF ASSIGNOR OF INTELLECTUAL PROPERTY OR LIMITED COMPANY
NAME IF IT IS A LIMITED COMPANY\]**

**\[INSERT ADDRESS OF ASSIGNOR OF IP\]**

**\[INSERT DATE\]**

Dear \[**INSERT FIRST NAME OF OWNER OF IP/ LIMITED COMPANY DIRECTOR**\]

**Assignment of Intellectual Property**

Thank you for agreeing to assign the Intellectual Property Rights in the
Intellectual Property to us. This letter of agreement is to record the
terms agreed between us. All capitalised terms are as defined below in
paragraph 7.

1.  In consideration of the sum of £\[**INSERT AMOUNT PAID FOR THE
    ASSIGNMENT OR IF NOTHING FURTHER IS TO BE PAID INSERT £1**\]
    (receipt of which is acknowledged by you) you hereby assign to us
    absolutely with full title guarantee all of your right, title and
    interest in and to the Assigned Rights. **\[NOTE THERE NEEDS TO BE
    CONSIDERATION FOR A CONTRACT TO BE FORMED SO ENSURE A MINIMUM OF £1
    IS INCLUDED IN THIS CLAUSE IF YOU ARE NOT PAYING A FURTHER AMOUNT
    FOR THE ASSIGNMENT. YOU DO NOT HAVE TO PHYSICALLY HAND OVER THE
    POUND.\]**

2.  You warrant that:

\(a\) you are the sole legal and beneficial owner of, and own all the
rights and interests in, the Assigned Rights;

(b) you have not licensed or assigned any of the Assigned Rights to any
    third party;

(c) the Assigned Rights are free from any security interest, option,
    mortgage, charge or lien;

(d) you are unaware of any infringement or likely infringement of any of
    the Assigned Rights;

(e) so far as you are aware, all the Assigned Rights are valid and
    subsisting and there have been no claims, challenges, disputes or
    proceedings, pending or threatened, in relation to the ownership,
    validity or use of any of the Assigned Rights;

(f) so far as you are aware, exploitation of the Assigned Rights will
    not infringe the rights of any third party;

(g) the Intellectual Property is your original work and has not been
    copied wholly or substantially from any other source; and

(h) to the extent that the Assigned Rights do not vest in us
    automatically in accordance with paragraph 1 above by operation of
    law or under this agreement, you will hold the legal title in such
    rights on trust for us.

```{=html}
<!-- -->
```
3.  \[In the event that you have copied the Intellectual Property (in
    whole or in part) or otherwise infringed the rights of a third party
    in creating the Intellectual Property, you agree to fully reimburse
    us for (or in legal terminology to indemnify and keep us indemnified
    against) all damages, losses, costs, expenses, fees (including
    reasonable professional fees) and any other liability incurred by us
    arising as a result of any third party bringing an action or claim
    against us arising directly or indirectly out of our use (or a third
    party licensee's use) of the Intellectual Property.\]**\[NOTE: THE
    ASSIGNOR MAY REFUSE TO PROVIDE THIS INDEMNITY -- HAVING THE
    ASSIGNMENT WITHOUT THIS CLAUSE IN IT IS BETTER THAN NOTHING. SEND
    THE LETTER WITH THIS CLAUSE IN AND LEAVE IT FOR THE ASSIGNOR TO
    OBJECT TO IT. IF THEY OBJECT YOU CAN ASK WHY THEY ARE CONCERNED
    ABOUT IT IF THEY ARE SURE THEY HAVEN'T COPIED ANYTHING. EVEN SO,
    SOME MAY REFUSE TO SIGN WITH THIS IN SO YOU CAN ULTIMATELY AGREE TO
    TAKE THIS CLAUSE OUT. THE IMPACT OF NOT HAVING THIS CLAUSE INCLUDED
    IS THAT IF THEY HAVE COPIED SOMETHING (OR THE WORK OTHERWISE
    INFRINGES A THIRD PARTY'S RIGHTS) AND YOU SUFFER LOSS AS A RESULT OF
    THAT, YOU WILL HAVE TO BRING AN ACTION FOR DAMAGES IN THE COURTS
    RATHER THAN AN ACTION FOR BREACH OF AN INDEMNITY. AN INDEMNITY IS
    EASIER TO CLAIM UNDER AND PROVIDES POUND FOR POUND REIMBURSEMENT OF
    LOSS WHEREAS A CLAIM FOR DAMAGES UNDER A BREACH OF WARRANTY MEANS
    YOU HAVE TO PROVE CAUSATION (IE THAT THE BREACH OF THE WARRANTY
    CAUSED YOUR LOSS), LOSS (IE THE AMOUNT OF YOUR LOSS) AND MITIGATION
    (THAT YOU TRIED TO REDUCE/MITIGATE THE LOSS YOU SUFFERED)\].**

4.  You hereby waive (or in the event that an employee created the
    Intellectual Property, shall procure that such employee waives) any
    moral rights you (or such employee) may have arising under the
    Copyright, Designs and Patents Act 1988 in relation to the
    Intellectual Property including in relation to any future rights in
    relation to the same. **\[NOTE: SEE THE NOTES ABOUT MORAL RIGHTS AT
    THE END OF THIS DOCUMENT\]**

5.  \[You are permitted to use the Assigned Rights to display the
    Intellectual Property in your portfolio, in your case studies on
    your website and in any printed media that is promoting your
    business. Other than aforesaid and as set out in paragraph 6 below,
    you shall have no right to use the Intellectual Property for any
    purpose.\] \[**NOTE -- DELETE THIS PARAGRAPH 4 IN ITS ENTIRETY IF
    YOU DON'T WANT YOUR INTELLECTUAL PROPERTY TO BE USED IN THIS WAY**\]

6.  You are permitted to retain a digital copy of the Intellectual
    Property for your business records. If we request further copies of
    the Intellectual Property (for example because we have lost our
    copy) you will provide us with replacement digital files for no
    charge \[OR for a fixed price of £\[**insert amount**\] in
    total\].**\[NOTE:THE OPTIONS HERE ARE A MATTER OF NEGOTIATION.
    OBVIOUSLY SEND THIS AGREEMENT OVER WITH THE NO CHARGE OPTION UNLESS
    THIS HAS BEEN EXPRESSLY AGREED OTHERWISE\]**

7.  The following definitions shall apply in this agreement:

**Assigned Rights** means all the Intellectual Property Rights embodied
in the Intellectual Property or arising \[or to arise from\] work done
pursuant to **\[INSERT THE NAME OF SUPPLY AGREEMENT EG BRAND DESIGN
AGREEMENT BETWEEN THE PARTIES HERETO\]** dated **\[INSERT THE DATE THE
SUPPLY AGREEMENT WAS SIGNED\].**

**\[NOTE: DELETE THE WORDS "OR TO ARISE FROM" ABOVE IF ALL OF THE WORK
IS COMPLETED. IF THE WORK IS ONGOING, THEN LEAVE THESE WORDS IN\]**

**Intellectual Property Rights** means copyright and related rights,
trademarks and service marks, business names and domain names, rights in
get-up, goodwill and the right to sue for passing off or unfair
competition, rights in designs and all other intellectual property
rights, in each case whether registered or unregistered and including
all applications and rights to apply for and be granted, renewals or
extensions of, and rights to claim priority from, such rights and all
similar or equivalent rights or forms of protection which subsist or
will subsist now or in the future in any part of the world.

**Intellectual Property** means all records, reports, documents, papers,
drawings, designs, transparencies, photos, graphics, logos,
typographical arrangements, software, and all other materials in
whatever form, including but not limited to hard copy and electronic
form, prepared by you in the provision of the Services and as set out in
the Schedule.

8.  This letter of agreement and any dispute or claim arising out of or
    in connection with it shall be governed by and construed in
    accordance with the law of England and Wales. We each irrevocably
    agree that the courts of England and Wales shall have exclusive
    jurisdiction to settle any dispute or claim that arises out of or in
    connection with this letter of agreement or its subject matter or
    formation.

Please sign where indicated below to acknowledge your agreement to the
terms of this letter.

Yours sincerely

**\[INSERT YOUR NAME OR YOUR LIMITED COMPANY NAME\]**

I/we hereby agree to the terms of this letter

......................................................................

\[**INSERT NAME OF ASSIGNOR OF IP OR THE LIMITED COMPANY NAME IF A
LIMITED COMPANY**\]

Date...................................................................

**Schedule**

**\[insert details of the Materials -- NOTE THAT THIS CAN BE AN IMAGE IF
NECESSARY\]**

**\[NOTE: MORAL RIGHTS**

Moral rights are only available for literary, dramatic, musical and
artistic works and film, as well as some performances.

Unlike economic rights, moral rights cannot be sold or otherwise
transferred. However, the rights holder can choose to waive these
rights.

There are four moral rights recognised in the UK:

**The right to attribution**

This is the right to be recognised as the author of a work. This right
needs to be asserted before it applies. For example, in a contract with
a publisher, an author may state that they assert their right to be
identified as the author of their work.

**The right to object to derogatory treatment of a work**

Derogatory treatment is defined as any addition, deletion, alteration to
or adaptation of a work that amounts to a distortion or mutilation of
the work, or is otherwise prejudicial to the honour or reputation of the
author.

**The right to object to false attribution**

This is the right not to be named as the author of a work you did not
create. This would prevent, for example, a well-known author being named
as the author of a story they did not write.

**The right to privacy of certain photographs and films**

This right enables someone who has commissioned a photograph or film for
private and domestic purposes to prevent it from being made available or
exhibited to the public. For example, this would allow you to prevent a
photographer from putting your wedding photographs on their website
without your permission.\]
