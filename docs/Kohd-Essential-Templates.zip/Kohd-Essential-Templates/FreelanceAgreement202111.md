**Kohdbase Limited**

**The Enterprise Centre**

**291-305 Lytham Rd**

**Blackpool FY4 1EW**

**\[INSERT FREELANCER'S NAME\]**

**\[INSERT NAME OF LIMITED COMPANY\]**

**\[INSERT FREELANCER'S ADDRESS\]**

\[**INSERT DATE**\]

Dear \[**INSERT FREELANCER'S NAME**\]

Freelance agreement

We are writing to confirm the terms of our agreement concerning the
provision of your services to Kohdbase Limited ("**Us" or "We"**).

Term
====

You shall provide your services to us from 1^st^ June 2022 unless and
until the services being fully provided or this agreement is terminated
as provided in this letter.

2.  Duties
    ======

    1.  You shall exercise all due skill and care in providing the following services to us:
        ------------------------------------------------------------------------------------

The services set out in the project plan annexed to this agreement. ("**Services"**). {#the-services-set-out-in-the-project-plan-annexed-to-this-agreement.-services. .list-paragraph}
-------------------------------------------------------------------------------------

2.  If you are unable to provide the Services due to illness or injury you must notify us as soon as reasonably practicable.
    ------------------------------------------------------------------------------------------------------------------------

3.  You may appoint a suitably qualified substitute to perform the Services on your behalf, provided that the substitute shall be required to enter into direct undertakings with us, including with regard to confidentiality. We will continue to pay you your fee as provided in clause 3.1 below and you shall be responsible for the remuneration of (and any expenses incurred by) the substitute. For the avoidance of doubt, you will not be paid for any period during which neither you nor any substitute provides the Services.
    ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

4.  You shall ensure that you are available at all reasonable times on reasonable notice to provide such assistance or information as we may require.
    -------------------------------------------------------------------------------------------------------------------------------------------------

5.  You have no authority (and shall not hold yourself out as having authority) to bind us (for example in relation to any proposed contracts that you may consider entering on our behalf), unless we have specifically permitted this in writing in advance.
    ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

6.  You must follow all policies and procedures that we provide to you in relation to the provision of the Services.
    ----------------------------------------------------------------------------------------------------------------

7.  You shall at all times comply with all applicable laws and regulations when providing the Services including the Data Protection Act 2018, the Criminal Finances Act 2017 and the Bribery Act 2010.
    ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

```{=html}
<!-- -->
```
3.  Fees and expenses
    =================

    1.  We will pay you a fee of £\[**INSERT AMOUNT**\] for completion of the Services exclusive of VAT. 30% of the fee will be payable on the first day of you starting to provide the services, 30% will be payable on satisfactory completion of project milestone **\[X\]**. The remaining 40% shall be payable on satisfactory completion of the project. You shall submit an invoice to us on the satisfactory completion of the Services setting out any VAT payable (if applicable). 
        ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    2.  We will pay your valid invoices within 30 days of our receipt of the relevant invoice.
        --------------------------------------------------------------------------------------

    3.  You shall bear your own expenses in relation to the provision of the Services and we shall not be liable to reimburse you for any such expenses.
        ------------------------------------------------------------------------------------------------------------------------------------------------

    4.  We are entitled to deduct from any sums payable to you any sums that you may owe us at any time.
        ------------------------------------------------------------------------------------------------

    5.  If we are not happy with the standard of work submitted to us, you agree to amend such work at no additional charge until it is approved by us.
        -----------------------------------------------------------------------------------------------------------------------------------------------

4.  Other activities and non-solicitation
    =====================================

    1.  You may be engaged, employed or concerned in any other business, trade, profession or other activity which does not place you in a conflict of interest with us. However, you may not be involved in any capacity with a business which does or could compete with our business without our prior written consent which must not be unreasonably withheld or delayed.
        ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    2.  You may not at any time during the engagement or for a period of 12 months following the termination of the engagement approach, deal directly with, be engaged by, be employed by or solicit any of our existing clients or persons or businesses who have been our clients within the previous 12 months.
        -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

5.  Confidential information and property
    =====================================

    1.  Other than for the purposes of performing the services you shall not use or disclose to any person either during or at any time after your engagement by us any confidential information about our business or affairs or any of our business contacts or clients, or about any other confidential matters which may come to your knowledge in the course of providing the Services. For the purposes of this clause 5, **confidential information** means any information or matter which is not in the public domain and which relates to our affairs or any of our business contacts or clients.
        ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    2.  The restriction in clause 5.1 does not apply to:
        ------------------------------------------------

        a.  ### any use or disclosure authorised by us or as required by law; or

        b.  ### any information which is already in, or comes into, the public domain otherwise than through your unauthorised disclosure.

    3.  All documents, manuals, hardware and software provided for your use by us, and any data or documents (including copies) produced, maintained or stored on our or your computer systems or other electronic equipment, remain our property. 
        ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

6.  Data protection
    ===============

    1.  You acknowledge that we hold and process data relating to you for legal, personnel, administrative and management purposes and in particular to the processing of any \"special category data\" as defined in the retained EU law version of the General Data Protection Regulation (*(EU) 2016/679*) (UK GDPR) relating to you including, as appropriate:
        ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        a.  ### information relating to any criminal proceedings in which you have been involved for insurance purposes and in order to comply with legal requirements and obligations to third parties.

    2.  You acknowledge that we will make such information available to those who provide products or services to us (such as advisers), regulatory authorities, governmental or quasi-governmental organisations and potential purchasers of our business or any part of our business.
        -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    3.  Where we need to transfer such information to our business contacts outside the UK or the European Economic Area for our business purposes, we will comply with all legal requirements and should we require your explicit consent, shall request this from you.
        ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

7.  Intellectual property
    =====================

    1.  Subject to clause 7.2 below, you hereby assign to us all existing and future intellectual property rights (including, without limitation, patents, copyright and related rights and inventions) in all deliverables delivered to us as part of the provision of the Services ("Deliverables"). You agree promptly to execute all documents and do all acts as may, in our opinion, be necessary to give effect to this clause 7.
        --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    2.  Where you do not own intellectual property rights in the Deliverables (including, without limitation, in images), you grant us a non-exclusive, royalty free, irrevocable, worldwide licence to use all or any of the Deliverables for the purposes for which the Services were provided. You warrant that (i) you are entitled to license such rights to us and (ii) the use by us of any Deliverables will not infringe the right of any third party.
        -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

8.  Insurance and liability
    =======================

You shall have personal liability for and shall indemnify us for any
loss, liability, costs (including reasonable legal costs), damages or
expenses arising from any breach by you, or any substitute engaged by
you, of the terms of this agreement, including any negligent or reckless
act, omission or default in the provision of the Services and including
any infringement of a third party's intellectual property rights and
shall maintain in force during the period of this agreement adequate
insurance cover with reputable insurers acceptable to us.

9.  Termination
    ===========

    1.  We may at any time terminate your engagement with immediate effect with no liability to make any further payment to you (other than in respect of any accrued fees at the date of termination).
        -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    2.  We may at any time terminate your engagement with immediate effect with no liability to make any further payment to you (whether for accrued fees or otherwise) if:
        -------------------------------------------------------------------------------------------------------------------------------------------------------------------

        a.  ### you are in material breach of any of your obligations under this agreement; or

        b.  ### other than as a result of illness or accident, after notice in writing, you wilfully neglect to provide or fail to remedy any default in providing the Services.

    3.  Any delay by us in exercising our rights to terminate shall not constitute a waiver of those rights.
        ----------------------------------------------------------------------------------------------------

    4.  You may terminate your engagement at any time by providing us with at least 30 days' written notice.
        ----------------------------------------------------------------------------------------------------

10. Obligations on termination
    ==========================

Any of our property in your possession (including passwords for software
or websites) and any original or copy documents obtained by you in the
course of providing the Services shall be returned to us immediately on
our request and in any event before the termination of this agreement.
You also undertake to irretrievably delete any information relating to
our business or the business of any of our clients stored on any
magnetic or optical disk or memory, and all matter derived from such
sources which is in your possession or under your control.

11. Status
    ======

    1.  You will be an independent contractor and nothing in this agreement shall render you an employee, worker, agent or partner of ours and you shall not hold yourself out as such.
        -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    2.  You shall be fully responsible for and indemnify us against any liability, assessment or claim for:
        ---------------------------------------------------------------------------------------------------

        a.  ### taxation whatsoever arising from or made in connection with the performance of the Services, where such recovery is not prohibited by law; and

        b.  ### any employment-related claim or any claim based on worker status (including reasonable costs and expenses) brought by you or any substitute against us arising out of or in connection with the provision of the Services.

We may satisfy such indemnity (in whole or in part) by way of deduction
from any payment due to you.

12. Variation and third party rights
    ================================

    1.  This agreement may only be varied by a document signed by both of us.
        ---------------------------------------------------------------------

    2.  The Contracts (Rights of Third Parties) Act 1999 shall not apply to this agreement and no person other than each of us shall have any rights under it. The terms of this agreement or any of them may be varied, amended or modified or this agreement may be suspended, cancelled or terminated by agreement in writing between the parties or this agreement may be rescinded (in each case), without the consent of any third party.
        ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

13. Governing law and jurisdiction
    ==============================

    1.  This agreement and any dispute or claim arising out of or in connection with it shall be governed by and construed in accordance with the law of England and Wales.
        -------------------------------------------------------------------------------------------------------------------------------------------------------------------

    2.  The courts of England and Wales shall have exclusive jurisdiction to settle any dispute or claim arising out of this agreement.
        -------------------------------------------------------------------------------------------------------------------------------

Please acknowledge receipt of this letter and acceptance of its terms by
signing, dating and returning the enclosed copy.

Yours sincerely

\...\...\...\...\...\...\...\...\...\...\...\...\...\...\...\...\...\...\...\...\....

Neil Riley

For and on behalf of

**Kohdbase Limited**

 

I hereby acknowledge receipt and accept the contents of this letter.

 

Signed
\...\...\...\...\...\...\...\...\...\...\...\...\...\...\...\...\.....

**\[INSERT FREELANCER'S NAME AND WHERE THE FREELANCER IS TRADING THROUGH
A LIMITED COMPANY ADD THE WORDS "ON BEHALF OF" AND THEN THE COMPANY
NAME\]**

 

Date
\...\...\...\...\...\...\...\...\...\...\...\...\...\...\...\...\...\.....
