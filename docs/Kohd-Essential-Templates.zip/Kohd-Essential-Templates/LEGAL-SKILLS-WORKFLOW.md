# Kohd Group Legal Skills Workflow

**Document Version:** 1.0  
**Date Created:** 2026-05-09  
**Last Updated:** 2026-05-09  
**Status:** Active  
**Jurisdiction:** England and Wales  
**Owner:** Kohd Group Limited

---

## 📌 Overview

This document outlines the structured workflow for using Claude legal skills with Kohd Group's template library. These skills enable rapid contract review, compliance checking, and risk assessment without requiring external legal counsel for routine matters.

---

## 🛠️ Available Legal Skills

### 1. **legal:review-contract** ⭐ HIGH PRIORITY
**Purpose:** Review contracts against organizational playbook and standards  
**When to Use:**
- Before sending customized templates to clients/partners
- When receiving contracts from external parties
- Before signing any agreement

**What It Does:**
- Flags deviations from standard/preferred terms
- Generates redline suggestions
- Provides business impact analysis
- Prioritizes issues by risk level

**Typical Output:** Clause-by-clause analysis with specific redlines and negotiation priorities

**Workflow:**
```
1. Customize template for specific situation
2. Call legal:review-contract
3. Review flagged deviations
4. Decide: approve as-is, request changes, or escalate
5. Document decision in contract tracker
```

---

### 2. **legal:compliance-check** ⚠️ COMPLIANCE CRITICAL
**Purpose:** Verify regulatory compliance of proposed actions/documents  
**When to Use:**
- Deploying new template to website/operations
- Before launching new service/product
- When handling personal data
- When uncertain about regulatory requirements

**What It Does:**
- Identifies applicable regulations (GDPR, DPA 2018, etc.)
- Flags compliance gaps
- Lists required approvals/documentations
- Identifies risk areas

**Typical Output:** Risk matrix with compliance requirements and action items

**Workflow:**
```
1. Draft policy or service terms
2. Call legal:compliance-check
3. Review identified regulations
4. Update document to address gaps
5. Repeat until "green" status achieved
```

---

### 3. **legal:legal-risk-assessment** 🎯 DECISION SUPPORT
**Purpose:** Classify and prioritize legal risks using severity-by-likelihood framework  
**When to Use:**
- Before signing significant contracts (>£10k value)
- Evaluating unfamiliar contract terms
- Deciding whether to negotiate or escalate
- Building risk register

**What It Does:**
- Assesses each identified risk (High/Med/Low)
- Identifies likelihood and impact
- Determines escalation triggers
- Suggests mitigation strategies

**Typical Output:** Risk scorecard with escalation recommendations

**Workflow:**
```
1. Draft or receive contract
2. Call legal:review-contract (get issues)
3. Call legal:legal-risk-assessment (prioritize risks)
4. Decision: accept risk, negotiate, or decline contract
5. Document in risk register
```

---

### 4. **legal:triage-nda** 🟢 RAPID SCREENING
**Purpose:** Quickly classify incoming NDAs as GREEN/YELLOW/RED  
**When to Use:**
- Partner sends NDA for signature
- Evaluating quick partnership opportunities
- Need rapid yes/no decision

**What It Does:**
- Compares against Kohd's NDA template
- Flags problematic clauses
- Classifies overall risk level
- Recommends approval or review

**Typical Output:** 1-page risk summary with GO/NO-GO recommendation

**Workflow:**
```
1. Receive NDA from partner
2. Call legal:triage-nda
3. If GREEN → approve/sign
4. If YELLOW → send to legal:review-contract
5. If RED → escalate to legal counsel
```

---

### 5. **legal:signature-request** ✍️ PRE-SIGNATURE CHECK
**Purpose:** Final pre-signature verification and routing  
**When to Use:**
- Contract finalized and ready to sign
- Need e-signature workflow setup
- Want final QA before execution

**What It Does:**
- Runs pre-signature checklist
- Verifies all details correct
- Configures e-signature service
- Sets up signing order/workflow

**Typical Output:** Signed contract ready for execution

**Workflow:**
```
1. Contract finalized after review/negotiation
2. Call legal:signature-request
3. Confirm all details
4. Authorize e-signature send
5. Track execution status
```

---

### 6. **legal:legal-risk-assessment** (Alternative Use)
**Purpose:** Build contract risk register and track obligations  
**When to Use:**
- Managing multiple active contracts
- Quarterly compliance reviews
- Tracking payment terms/renewal deadlines

**Workflow:**
```
1. Maintain list of active contracts
2. Periodically call legal:legal-risk-assessment
3. Update risk tracking spreadsheet
4. Flag upcoming renewals/deadlines
5. Escalate high-risk obligations
```

---

### 7. **legal:vendor-check** (Optional)
**Purpose:** Track vendor agreement status and compliance  
**When to Use:**
- Renewing vendor contracts
- Checking agreement completeness
- Verifying data processing agreements in place

**Workflow:**
```
1. List vendors Kohd works with
2. Call legal:vendor-check
3. Identify missing documents (MSA, DPA, SOW)
4. Gap analysis
5. Prioritize missing agreements
```

---

## 🔄 Complete Contract Lifecycle Workflow

### Phase 1: Template Customization
```
SELECT TEMPLATE
    ↓
CUSTOMIZE [INSERT] FIELDS
    ↓
INTERNAL REVIEW (compliance-check if uncertain)
    ↓
READY TO SEND
```

### Phase 2: Sending to Client/Partner
```
SEND CUSTOMIZED TEMPLATE
    ↓
RECEIVE CLIENT RESPONSE (accept/modify)
    ↓
IF MODIFICATIONS: review-contract → legal-risk-assessment
    ↓
NEGOTIATE IF NEEDED
```

### Phase 3: Final Review Before Signature
```
FINALIZED VERSION READY
    ↓
review-contract (final audit)
    ↓
legal-risk-assessment (final risk check)
    ↓
signature-request (pre-signature verification)
    ↓
EXECUTE SIGNATURE
```

### Phase 4: Post-Signature Management
```
CONTRACT SIGNED
    ↓
STORE IN VAULT
    ↓
LOG KEY DATES (renewal, payment terms)
    ↓
QUARTERLY vendor-check OR legal-risk-assessment
    ↓
ALERT ON APPROACHING DEADLINES
```

---

## 📊 Decision Trees

### Should I Use a Template vs. Custom Terms?
```
CONTRACT VALUE < £10k
├─ YES → Use template (may customize)
├─ NO → Template + legal:review-contract

CLIENT REQUESTING CUSTOM TERMS?
├─ YES → legal:review-contract on their version
├─ NO → Use template as-is

UNCERTAIN ABOUT COMPLIANCE?
├─ YES → legal:compliance-check
└─ NO → Proceed with template
```

### Which Skill Should I Call?

```
INCOMING EXTERNAL CONTRACT?
├─ NDA → legal:triage-nda
└─ Services/Other → legal:review-contract

CUSTOMIZING TEMPLATE?
├─ High value (>£10k) → legal:review-contract + legal-risk-assessment
├─ Data/GDPR related → legal:compliance-check
└─ Standard use → Manual review sufficient

READY TO SIGN?
└─ ALWAYS → legal:signature-request

UNCERTAIN ABOUT RISK?
└─ ALWAYS → legal:legal-risk-assessment
```

---

## ⚙️ How to Call These Skills

### In Claude Chat:
```
"Can you run legal:review-contract on this customized NDA?"
"I need legal:compliance-check on our new privacy notice"
"Please do a legal:legal-risk-assessment of this vendor contract"
```

### For Multiple Reviews:
```
"Review this consultancy agreement using:
1. legal:review-contract (check terms)
2. legal:legal-risk-assessment (priority issues)"
```

### Integration Points:
- **Before sending anything external** → legal:review-contract
- **Before deploying templates** → legal:compliance-check
- **Before signing** → legal:signature-request
- **For quick NDA screening** → legal:triage-nda
- **When uncertain** → legal:legal-risk-assessment

---

## 📋 Template-to-Skill Mapping

| Template | Primary Skill | Secondary Skill |
|----------|--------------|-----------------|
| NDA | legal:triage-nda | legal:review-contract |
| Consultancy Agreement | legal:review-contract | legal:legal-risk-assessment |
| Terms for Services | legal:review-contract | legal:compliance-check |
| GDPR Cookie Policy | legal:compliance-check | legal:review-contract |
| Privacy Notice | legal:compliance-check | legal:review-contract |
| IP Assignment | legal:review-contract | legal:legal-risk-assessment |
| Invoice/Payment Demand | legal:review-contract | — |
| Website Terms | legal:compliance-check | legal:review-contract |
| Freelancer Agreement | legal:review-contract | legal:legal-risk-assessment |

---

## ⚠️ Escalation Triggers

### ALWAYS escalate to external legal counsel:
- Contract value > £50,000
- International jurisdiction (outside UK)
- M&A or significant business transaction
- Employment contracts or disputes
- Regulatory investigation or complaint
- Litigation risk identified
- Conflicting legal advice
- When legal:legal-risk-assessment returns "RED" across multiple dimensions

### CONSIDER escalation:
- YELLOW risk rating from legal:legal-risk-assessment
- Unusual/non-standard terms
- New industry/regulatory area
- Significant IP value at stake

---

## 📝 Documentation Standards

### When Using Skills, Document:
```markdown
## Contract Review: [Contract Name]
**Date:** YYYY-MM-DD  
**Template Used:** [Template Name]  
**Skill Called:** legal:review-contract, legal:legal-risk-assessment

### Key Issues Identified:
- [Issue 1] - [Risk Level]
- [Issue 2] - [Risk Level]

### Actions Taken:
- [ ] Redlined and sent to client
- [ ] Accepted as-is
- [ ] Escalated to legal counsel

### Signature Status:
- Signed: [Date]
- Executed by: [Party]
```

---

## 🔐 Version Control

### Template Versioning:
- **Format:** YYYY-MM-DD-TemplateName-Version.md
- **Example:** 2026-05-09-NDA-v1.0-ClientName.md

### Contract Registry (maintain in folder or spreadsheet):
```
Date | Template | Client | Status | Signed | Risk Level | Notes
2026-05-09 | NDA | ABC Corp | ✓ Signed | 2026-05-15 | GREEN | Standard terms
```

### Workflow Log:
```
Date | Contract | Skill Used | Outcome | Decision
2026-05-09 | NDA-XYZ | triage-nda | GREEN | Approved
2026-05-09 | Services-ABC | review-contract | Issues found | Negotiating redlines
```

---

## ✅ Best Practices

1. **Always use legal:triage-nda first** for NDAs - it's designed for speed
2. **Combine review-contract + legal-risk-assessment** for high-value contracts
3. **Use legal:compliance-check** before deploying any template to production
4. **Document every skill use** with outcome and decision
5. **Run quarterly vendor-check** on active contracts
6. **Escalate when in doubt** - external legal counsel is cheaper than legal liability
7. **Keep templates clean** - remove all [INSERT...] placeholders after customization
8. **Version everything** - use YYYY-MM-DD naming convention
9. **Review annually** - these templates need legal audit each May

---

## 📞 Support & Updates

**Workflow Created:** 2026-05-09  
**Review Date:** 2027-05-09  
**Owner:** Kohd Group Limited  
**Contact:** [INSERT LEGAL OWNER NAME]  

**Changes to Workflow:**
- All updates to this document should be dated and tracked below

| Date | Change | Version |
|------|--------|---------|
| 2026-05-09 | Initial workflow created | 1.0 |

