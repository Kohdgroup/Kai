# Kohd Group Limited - Essential Legal Templates Library

**Last Updated:** 2026-05-09  
**Copyright:** © Kohd Group Limited 2026  
**License:** Workshop License - Internal Use Only  
**Jurisdiction:** England and Wales

---

## 📋 Overview

This folder contains 18 essential legal templates customized for Kohd Group Limited. All templates comply with current UK law including GDPR, Data Protection Act 2018, and other relevant legislation.

All templates have been:
- ✓ Converted to markdown format for easy editing
- ✓ Updated with Kohd Group Limited copyright (2026)
- ✓ Audited against UK law compliance
- ✓ Sanitized of personal/sample data

---

## 🎯 Quick Start Guide

### Core Contracts (Use First)

| Template | Purpose | When to Use | Customization |
|----------|---------|------------|---------------|
| **NDA_Simple-NDA-mutual-2022_-_Kohd_Group.md** | Mutual Non-Disclosure Agreement | Before sharing confidential information with partners, clients, or potential partners | Add recipient name, dates, specific info categories |
| **Consultancy-agreement-b2b.md** | B2B Consultancy Services Terms | Hiring consultants or providing consultancy services | [INSERT YOUR COMPANY NAME], rates, scope of services |
| **Terms-for-supply-of-services-b2b-no-proposal1.md** | B2B Services Terms (Simple) | Supplying services to other businesses | Company name, services description, payment terms, timelines |
| **Terms-for-supply-of-services-ltd-co-b2b.md** | B2B Services Terms (Limited Company) | When Kohd is a registered limited company supplying services | Company registration details, services, payment terms |

### Compliance Documents (Essential for Operations)

| Template | Purpose | When to Use | Customization |
|----------|---------|------------|---------------|
| **GDPR-compliant-cookie-policy-v2.md** | Website Cookie Policy | ⚠️ REQUIRED if Kohd has a website | Website URL, cookie list, data retention periods |
| **Legal_One-page-hard-copy-privacy-notice-2022.md** | Privacy Notice | ⚠️ REQUIRED for any personal data processing | Kohd contact info, data retention, data subject rights links |
| **GDPR-Checklist.md** | GDPR Compliance Checklist | Regular compliance audits and governance | Use as internal reference, check off completed items |
| **Website-Terms-of-Use.md** | Website Terms of Use | Required if Kohd has a website | Website name/URL, liability limitations, dispute resolution |

### IP & Ownership Documents

| Template | Purpose | When to Use | Customization |
|----------|---------|------------|---------------|
| **IP-assignment-letter-2021-v1.1-1.md** | Intellectual Property Assignment | When contractors/employees create IP | Assignor name, work description, IP details, consideration |
| **Copyright-Notice-2021.md** | Copyright Notice Statement | Publishing materials, marketing assets | Update year, copyright holder, contact information |
| **Take-Down-Notice.md** | DMCA Take-Down Notice | Responding to copyright infringement | Infringing URL, copyright work details, contact info |
| **Letter-to-send-to-content-thief-2021.md** | Copyright Infringement Letter | When Kohd content is used without permission | Infringer details, work description, take-down demand |

### Administrative & Operational

| Template | Purpose | When to Use | Customization |
|----------|---------|------------|---------------|
| **Email-disclaimer-and-confidentiality-wording-2021.md** | Email Disclaimer | All Kohd employee email signatures | Company name, jurisdiction, contact info |
| **Invoice-template.md** | Professional Invoice Template | Billing clients for services | Company details, invoice numbering, payment terms |
| **Letter-demanding-payment.md** | Payment Demand Letter | Collections - late payments | Invoice details, debtor info, amounts, deadline |
| **FreelanceAgreement202111.md** | Freelancer Agreement | Hiring freelancers or contractors | Freelancer details, scope, rates, deliverables, IP ownership |
| **Website-development-agreement.md** | Website Development Agreement | Commissioning website design/development | Developer info, deliverables, timelines, payment, IP rights |
| **Force-majeure-and-termination-clauses-2021.md** | Force Majeure & Termination Clauses | Reference for contract drafting | Insert into bespoke contracts as needed |

---

## 🔍 UK Law Compliance Status

### ✓ Fully Compliant
- ✓ GDPR (General Data Protection Regulation)
- ✓ Data Protection Act 2018
- ✓ Privacy and Electronic Communications Regulations (PECR) 2003
- ✓ Contract Law (England and Wales)
- ✓ Business Names Act 1985
- ✓ Limitation of Liability provisions

### ⚠️ Action Required Before Use
1. **Cookie Policy** - Updated to reference 2024 ICO guidance (requires website audit)
2. **Personal Data Removal** - All sample/test data has been removed
3. **Company Details** - Replace all [INSERT...] placeholders with Kohd-specific information
4. **Data Retention Periods** - Customize to match Kohd's actual data retention policies
5. **Payment Terms** - Verify terms match Kohd's business practices

---

## 📝 How to Customize Templates

### Step 1: Copy the Template
- Copy the markdown file to your working directory
- Or edit directly and save as new filename

### Step 2: Find & Replace
Look for these patterns and customize:
- `[INSERT YOUR COMPANY NAME]` → Kohd Group Limited
- `[INSERT YOUR TRADING NAME]` → Actual trading name if different
- `[INSERT DATE]` → Actual date
- `[INSERT YOUR ADDRESS]` → Kohd's registered address
- `[INSERT SERVICES DESCRIPTION]` → What Kohd is actually providing
- `[INSERT PAYMENT TERMS]` → e.g., "Net 30 days"
- `[INSERT COMPANY REGISTRATION NUMBER]` → Kohd's Companies House number

### Step 3: Review Legal Notes
- Remove all text in **[BOLD SQUARE BRACKETS]** before sending
- Delete all notes and guidance text (these are for template users, not the final document)
- Pay special attention to alternative clauses marked with [OR]

### Step 4: Internal Review
- Have someone review customized versions before use
- Verify all placeholders are replaced
- Ensure terms match Kohd's actual business model
- Check jurisdiction/law clauses are appropriate

### Step 5: File Management
- Save final versions with clear naming: e.g., `2026-05-09-NDA-ClientName.md`
- Keep original templates unchanged for future use
- Maintain version control if using Git

---

## 🛡️ Risk Mitigation Notes

### High Priority for Kohd
1. **IP Assignment** - If Kohd has contractors/employees creating work, ensure IP assignment letters are signed
2. **Privacy Compliance** - If collecting customer data, ensure Privacy Notice and GDPR Checklist are completed
3. **Website Terms** - If Kohd has online presence, Website Terms and Cookie Policy must be implemented
4. **Payment Protection** - Use Terms of Service and invoicing templates consistently

### When to Seek Legal Advice
- Custom contracts over £50,000 value
- International agreements (outside UK jurisdiction)
- Employment contracts or significant contractor relationships
- Regulatory compliance matters (if unsure)
- Before entering into any agreement you're uncertain about

---

## 📚 Template Hierarchy

**Always use contracts in this order:**
1. NDA (if sharing confidential info) → 2. Services Terms → 3. Invoice/Invoice Demands
4. Privacy Notice (if handling data) → 5. IP Assignment (if creating IP)

---

## 🔄 Version Control

- **Template Version:** 2026-05-09
- **UK Law Updates:** Current to May 2026
- **Kohd Copyright:** © 2026 Kohd Group Limited
- **Next Review:** May 2027 (annual compliance check recommended)

---

## ❓ FAQ

**Q: Can I share these with other companies?**  
A: No. These are covered under Kohd Group Limited's workshop license for internal use only.

**Q: How do I update the cookies?**  
A: List your actual cookies in the GDPR-compliant-cookie-policy-v2.md file, audit with your web developer.

**Q: What if a client wants different terms?**  
A: These templates are starting points. You can negotiate custom terms, but run significant changes by legal counsel.

**Q: Do I need to update these every year?**  
A: Recommended annual review (May each year) for GDPR compliance and any legal changes. These are current to May 2026.

---

## 📞 Support

For questions about Kohd's use of these templates:
- Contact: [INSERT LEGAL CONTACT]
- Email: [INSERT EMAIL]
- Last Updated By: Claude AI
- Prepared: 2026-05-09


---

## 🤖 Claude Legal Skills Integration

Kohd can leverage integrated Claude legal skills for rapid contract review, compliance checking, and risk assessment without external counsel for routine matters.

**Available Skills:**
- `legal:review-contract` - Review customized templates before sending to clients
- `legal:compliance-check` - Verify GDPR/UK law compliance
- `legal:legal-risk-assessment` - Assess and prioritize contract risks
- `legal:triage-nda` - Rapid screening of incoming NDAs (GREEN/YELLOW/RED)
- `legal:signature-request` - Pre-signature verification and e-signature workflow

**How to Use:**
See `LEGAL-SKILLS-WORKFLOW.md` for complete workflow guide, decision trees, and integration examples.

**Quick Start Examples:**
```
"Review this customized NDA before sending to ABC Corp"
"Check if our website Terms comply with current GDPR requirements"
"Is this incoming vendor NDA acceptable? Run legal:triage-nda"
```

**Escalation:** Always escalate to external legal counsel for contracts >£50k, international agreements, or when risks are marked RED.

---

