**© Kohd Group Limited 2026. These templates are covered under Kohd Group Limited's workshop license and may be used internally for the purposes authorized. Based on original work by Suzanne Dibble.**

**\[NOTE: TERMS OF BUSINESS ARE YOUR MAIN BUSINESS PROTECTION AND IT IS
ALWAYS RECOMMENDED THAT YOU INSTRUCT AN EXPERIENCED LAWYER TO DRAFT
TAILORED TERMS OF BUSINESS TO PROTECT YOU AGAINST ALL RISKS\]**

**\[NOTE THIS DOCUMENT IS ONLY FOR USE WHERE (2) YOU ARE SUPPLYING
SERVICES (NOT GOODS), AND (2) YOU ARE SUPPLYING A BUSINESS (NOT A
CONSUMER)\]**

**\[INSERT YOUR NAME\] TRADING AS "\[INSERT YOUR TRADING NAME"\]**

**\[OR WHERE YOU ARE TRADING THROUGH A LIMITED COMPANY, THE NAME OF YOUR
LIMITED COMPANY**\]

**STANDARD TERMS OF BUSINESS**

1.  Interpretation
    ==============

    1.  The definitions and rules of interpretation in this clause apply to these Terms.
        --------------------------------------------------------------------------------

**Contract**: the contract between you and us for the supply of Services
in accordance with these Terms.

**Intellectual Property Rights**: patents, rights to inventions,
copyright and related rights, moral rights, trademarks, trade names and
domain names, rights in get-up, rights in goodwill or to sue for passing
off, rights in designs, rights in computer software, database rights,
rights in confidential information (including know-how and trade
secrets) and any other intellectual property rights, in each case
whether registered or unregistered and including all applications (or
rights to apply) for, and renewals or extensions of, such rights and all
similar or equivalent rights or forms of protection which may now or in
the future subsist in any part of the world.

**Services**: the services that we are providing to you on these Terms.

**Terms**: the terms and conditions set out in this document.

**Writing or written**: includes email.

2.  The headings do not affect the interpretation of these Terms.
    -------------------------------------------------------------

3.  A reference to a particular law is a reference to it as it is in force for the time being taking account of any amendment, extension, or re-enactment and includes any subordinate legislation for the time being in force made under it.
    -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

4.  Unless the context otherwise requires, words in the singular include the plural and in the plural include the singular.
    -----------------------------------------------------------------------------------------------------------------------

```{=html}
<!-- -->
```
2.  Basis of Agreement
    ==================

    1.   These Terms constitute the entire agreement between you and us. You acknowledge that you have not relied on any statement, promise or representation made or given by or on behalf of us that is not set out in these Terms.
        ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    2.  A contract shall be formed between us ("**Contract"**) upon you instructing us to commence work in relation to the Services (whether in writing, (including by email) or orally) and shall continue unless and until terminated in accordance with clause 9 below. 
        ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    3.  \[The minimum term of the Contract shall be \[12 months\] (**"Initial Term"**) and you may not terminate the Contract prior to that date\]. \[If you do not serve notice of termination of the Contract prior to the Initial Term the Contract shall automatically renew for a further period of \[12 months\]\] \[**DELETE THE WORDING IN SQUARE BRACKETS IF NOT APPLICABLE**\].
        ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    4.  These Terms take precedence over any other terms and conditions (including your own terms of business) and any course of dealing or industry practice.
        ------------------------------------------------------------------------------------------------------------------------------------------------------

3.  The Services
    ============

    1.  We shall provide the Services with all due care, skill and ability and shall use our reasonable endeavours to meet any timescales set out in **\[the Order Form\] OR \[email correspondence between us\]**, but these dates are estimates only and if we fail to meet these dates you shall not have any legal rights in relation to this.
        ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    2.  We shall provide the following Services to you:
        -----------------------------------------------

**\[INSERT DETAILS OF SERVICES\]** (**"Services"**) {#insert-details-of-services-services .list-paragraph}
---------------------------------------------------

\[Any samples, drawings, descriptive matter or advertising issued by us, and any descriptions or illustrations contained in our catalogues or brochures do not form part of the Contract and are for illustration purposes only.\]**\[DELETE WORDS IN SQUARE BRACKETS IF NOT RELEVANT\]**
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

4.  Fees and Booking
    ================

    1.  The charges for the Services are as set out in **\[the Order Form\] OR \[email correspondence between us\]**. 
        -------------------------------------------------------------------------------------------------------------

    2.  Where the Services are provided for a fixed price, the total price for the Services shall be the amount set out in **\[the Order Form\] OR \[email correspondence between us\]**. 
        ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    3.  For Services where fees are payable in one single payment, we will invoice you for the fixed price in advance.
        --------------------------------------------------------------------------------------------------------------

    4.  Where the fees are to be made by a deposit, stage payments or retainers we will invoice you for the deposit in advance and for each stage payment or retainer at the time or at the stage of the project specified in **\[the Order Form\] OR \[email correspondence between us\]**.
        ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    5.  Where the Services are provided on a time-and-materials basis:
        --------------------------------------------------------------

        a.  the charges payable for the Services shall be calculated in
            accordance with our standard hourly or daily fee rates in
            force at that time;

        ```{=html}
        <!-- -->
        ```
        a.  our daily fee rates are calculated on the basis of an
            \[eight-hour\] day worked between \[8.00 am and 5.00
            pm\]\[**NOTE: AMEND THE HOURS IN SQUARE BRACKETS AS
            APPROPRIATE**\] on weekdays (excluding weekends and public
            holidays);

        b.  we shall be entitled to charge at an overtime rate of
            \[**INSERT PERCENTAGE**\] of our normal rate for time worked
            outside the hours referred to in condition 4.4(b) above; and

        c.  we will invoice you monthly in arrears unless we have agreed
            in writing otherwise.

    6.  All charges are stated exclusive of VAT which shall be added to the charges at the applicable rate (where necessary).
        ---------------------------------------------------------------------------------------------------------------------

    7.  You must pay each of our invoices in full, and in cleared funds by the payment method specified on the invoice, within **\[7\]** days of the date of the invoice. 
        -----------------------------------------------------------------------------------------------------------------------------------------------------------------

    8.  Without prejudice to any other right or remedy, if you fail to pay the invoice on the due date, we may:
        -------------------------------------------------------------------------------------------------------

        a.  ###  charge interest on the sum due from the due date for payment at the annual rate of 4% above the base lending rate from time to time of \[**INSERT NAME OF YOUR BANK**\], accruing on a daily basis and being compounded quarterly until payment is made (whether before or after any court judgment) and you shall pay the interest immediately on our demand; and

        b.  ### suspend all Services until payment has been made in full. 

    9.  \[All fees and charges are stated exclusive of expenses incurred by us. Subject to your prior written consent, you will reimburse us for all training venues, hotels, subsistence, travelling, stationery, materials, postage, other administrative costs and any other ancillary expenses reasonably incurred by us in providing the Services. Such expenses may be invoiced by us at cost at such times as we think appropriate.\] \[**NOTE: DELETE THE WORDS IN SQUARE BRACKETS IF NOT APPLICABLE**\]
        --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

5.  Other activities
    ================

Nothing in these Terms shall prevent us from being involved in any way
in any other business as long as that does not cause us to breach any of
our obligations under these Terms.

6.  Confidential information and our materials
    ==========================================

    1.  We acknowledge that we will have access to confidential information about your business, your suppliers and your customers in the course of providing the Services. We shall not use or disclose to any third party any such confidential information, except where we need to in order to properly perform the Services. 
        -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    2.  You will keep strictly confidential all information about our business, our suppliers and our customers.
        --------------------------------------------------------------------------------------------------------

    3.  The restrictions in clauses 6.1 and 6.2 do not apply to:
        --------------------------------------------------------

        a.  ### any use or disclosure required by law;

        b.  ### any disclosure authorised by the party who owns the confidential information; or

        c.  ### any information which is already public knowledge (otherwise than through unauthorised disclosure by the party to whom the information does not relate).

    4.  \[All property of whatsoever nature that we supply to you (including any materials, equipment, drawings, specifications and data) shall, at all times, remain our exclusive property, but you agree to keep them safe and good condition until you return them to us, and you agree not to dispose of such property or use it other than in accordance with our written instructions or authorisation.\] **\[DELETE WORDS IN SQUARE BRACKETS IF NOT APPLICABLE\]**
        ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

7.  Data protection
    ===============

    1.  You consent to our holding and processing data relating to you for legal, personnel, administrative, management and marketing purposes.
        ---------------------------------------------------------------------------------------------------------------------------------------

    2.  You consent to our making such information available to those who provide products or services to us such as advisers, regulatory authorities, governmental or quasi-governmental organisations and potential purchasers of us or any part of our business.
        -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    3.  You consent to the transfer of such information to our business contacts (such as server hosts) outside the European Economic Area.
        -----------------------------------------------------------------------------------------------------------------------------------

8.  Intellectual property
    =====================

    1.  We are the owner or the licensee of all Intellectual Property Rights and all other rights in the Services and any materials provided as part of the Services and nothing in these Terms or otherwise shall operate to transfer the ownership of the Intellectual Property Rights in the Services or such materials.
        -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    2.  You grant to us a non-exclusive perpetual, worldwide, royalty free licence to use all or any of your Intellectual Property Rights in any materials or content you submit to us.
        -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    3.  You acknowledge that, where we do not own any of the materials or content which we submit to you, your use of rights in such materials or content is conditional on our obtaining a written licence (or sub-licence) from the relevant licensor or licensors on such terms as will entitle us to license such rights to you.
        ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

9.  Termination
    ===========

    1.  Subject to the provisions of clause 2, either of us may terminate this Contract on **\[1\]** months' notice for any reason with no liability to the other (apart from liabilities that had already accrued and been incurred).
        ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    2.  You may terminate this Contract if we commit any serious or repeated breach or non-observance of any of the provisions of this Contract and such breach is not remedied within 14 days of notification of breach.
        -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    3.  Notwithstanding the provisions of clause 2 or clause 9.1, we may terminate this Contract with immediate effect with no liability to provide any further services to you if at any time:
        ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        a.  ### you fail to make a payment when due and payable under this Contract;

        b.  ### you commit any gross misconduct affecting our business;

        c.  ### you commit any serious or repeated breach or non-observance of any of the provisions of this Contract;

        d.  ### you are convicted of any criminal offence (other than an offence under any road traffic legislation in the United Kingdom or elsewhere for which a fine or non-custodial penalty is imposed);

        e.  ### you commit any fraud or dishonesty or carry out business or otherwise act in any manner which in our opinion brings or is likely to bring us into disrepute or is materially adverse to our interests.

        f.  ### an order is made or a resolution is passed for your winding up; 

        g.  ### an order is made for the appointment of an administrator to manage your affairs, business and property; 

        h.  ### a receiver is appointed of any of your assets or undertaking; or

        i.  ### you make any arrangement or composition with your creditors or become bankrupt; or

        j.  ### you cease, or threaten to cease, to trade.

    4.  Our rights under this clause 9 are without prejudice to any other rights that we might have at law to terminate the Contract. Any delay by us in exercising our rights to terminate shall not constitute a waiver of these rights. 
        ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    5.  We shall not be obliged to retain documents and information relating to you after termination of this Contract. 
        ---------------------------------------------------------------------------------------------------------------

10. Obligations on termination
    ==========================

On termination of this Contract you shall immediately pay to us any unpaid fees or other sums payable under this Contract. Termination will not affect either of our outstanding rights or duties, including our right to recover from you any money you owe us under these Terms. {#on-termination-of-this-contract-you-shall-immediately-pay-to-us-any-unpaid-fees-or-other-sums-payable-under-this-contract.-termination-will-not-affect-either-of-our-outstanding-rights-or-duties-including-our-right-to-recover-from-you-any-money-you-owe-us-under-these-terms. .list-paragraph}
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Status 
======

Our relationship to you will be that of independent contractor and nothing in these Terms shall make us your employee, worker, agent or partner. {#our-relationship-to-you-will-be-that-of-independent-contractor-and-nothing-in-these-terms-shall-make-us-your-employee-worker-agent-or-partner. .list-paragraph}
------------------------------------------------------------------------------------------------------------------------------------------------

12. Limitation of Liability
    =======================

    1.  Other than (i) liability for death or personal injury to any person caused by our negligence, (ii) liability for any fraud or fraudulent misrepresentation made by us or (iii) liability for any other matter which we may not legally exclude or limit, we exclude all liability for any loss or damage suffered by you resulting from the Contract (including all consequential loss or damage howsoever caused and whether or not this was in your or our reasonable contemplation and including any loss or damage suffered by you as a result of advice or opinions given by us or by any of our employees, agents, consultants or subcontractors). 
        --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    2.  In the event that we are found liable to you for any loss or damage, this liability shall be limited to the amount of any fees you paid to us in accordance with these Terms in the 12 months preceding the date on which any claim is made. 
        --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    3.  If we are prevented from or delayed in performing our obligations by your act or omission or by any circumstance outside of our control, we shall not be liable for any costs, charges or losses incurred by you that arise from such prevention or delay.
        ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    4.  All warranties, conditions and other terms implied by statute or common law are, to the fullest extent permitted by law, excluded from these Terms.
        ---------------------------------------------------------------------------------------------------------------------------------------------------

    5.  This clause 12 shall survive termination of the Contract.
        ---------------------------------------------------------

13. Notices
    =======

All notices sent by you to us must be sent to \[**INSERT YOUR NAME AND
ADDRESS**\] or by email to **\[INSERT YOUR E-MAIL ADDRESS\]**. We may
give notice to you at either the e-mail or postal address you provided
to us. Notice will be deemed received and properly served 24 hours after
an e-mail is sent or three days after the date of posting of any letter.
In proving the service of any notice, it will be sufficient to prove, in
the case of a letter, that the letter was properly addressed,
stamped and placed in the post and, in the case of an e-mail, that the
e-mail was sent to the specified e-mail address of the addressee.

14. Assignment and subcontracting
    =============================

    1.  We may at any time assign, transfer, subcontract or deal in any other manner with all or any of our rights under these Terms.
        -----------------------------------------------------------------------------------------------------------------------------

    2.  You shall not, without our prior written consent, assign, transfer, subcontract or deal in any other manner with all or any of your rights or obligations under these Terms.
        ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

15. General
    =======

    1.   If any court or competent authority decides that any of the provisions of these Terms are invalid, unlawful or unenforceable to any extent, that term will (to that extent only) be 'severed' from the remaining terms, which will continue to be valid to the fullest extent permitted by law.
        -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    2.  If we delay in exercising any rights under these Terms or by law, that shall not constitute a waiver of such right or prevent us from exercising that right at a later date.
        ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    3.  We may vary these Terms at any time (other than in relation to the fee to be charged).
        --------------------------------------------------------------------------------------

    4.  A person who is not party to these Terms shall not have any rights under or in connection with them under the Contracts (Rights of Third Parties) Act 1999.
        -----------------------------------------------------------------------------------------------------------------------------------------------------------

    5.  These Terms and any dispute or claim arising out of or in connection with them or their subject matter or formation (including non-contractual disputes or claims) shall be governed by English law and we both agree to the exclusive jurisdiction of the English court.
        -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

 {#section .list-paragraph}
