**© Kohd Group Limited 2026. These templates are covered under Kohd Group Limited's workshop license and may be used internally for the purposes authorized. Based on original work by Suzanne Dibble.**

**You will see lots of references in the Checklist to the GDPR Pack --
if you would like to purchase this, go to
www.suzannedibble.com/gdprpack**

**GDPR CHECKLIST**

+-----------------------+-------------------+-----------------------+
| **CONSIDERATION**     | **YOUR COMMENTS** | **CONSIDERED /        |
|                       |                   | COMPLETED**           |
+=======================+===================+=======================+
| **Does GDPR apply to  |                   |                       |
| me territorially?**   |                   |                       |
|                       |                   |                       |
| It does if you        |                   |                       |
| process personal data |                   |                       |
| about EU residents    |                   |                       |
| (even if you are      |                   |                       |
| based outside of the  |                   |                       |
| EU). If you have EU   |                   |                       |
| residents on your     |                   |                       |
| email list, as        |                   |                       |
| customers, as         |                   |                       |
| employees, as         |                   |                       |
| contractors, as       |                   |                       |
| service providers     |                   |                       |
| then it applies. If   |                   |                       |
| you are able to       |                   |                       |
| identify individuals  |                   |                       |
| from the EU through   |                   |                       |
| cookies or IP         |                   |                       |
| addresses then it     |                   |                       |
| applies to you.       |                   |                       |
+-----------------------+-------------------+-----------------------+
| **Do I process data   |                   |                       |
| that GDPR applies     |                   |                       |
| to?**                 |                   |                       |
|                       |                   |                       |
| If you process data   |                   |                       |
| that is capable of    |                   |                       |
| identifying an        |                   |                       |
| individual (including |                   |                       |
| cookies and IP        |                   |                       |
| addresses) wholly or  |                   |                       |
| partly through        |                   |                       |
| automated means or    |                   |                       |
| manually as part of a |                   |                       |
| filing system, then   |                   |                       |
| GDPR applies.         |                   |                       |
+-----------------------+-------------------+-----------------------+
| **What data do I      |                   |                       |
| process and for what  |                   |                       |
| purpose?**            |                   |                       |
|                       |                   |                       |
| Prepare a data        |                   |                       |
| inventory of the      |                   |                       |
| types of data you     |                   |                       |
| process (see the      |                   |                       |
| Privacy Notice for    |                   |                       |
| examples of data you  |                   |                       |
| may process) -- use   |                   |                       |
| the data inventory    |                   |                       |
| template in the GDPR  |                   |                       |
| pack. This inventory  |                   |                       |
| must be a dynamic     |                   |                       |
| inventory that is     |                   |                       |
| consistently updated  |                   |                       |
| for record keeping    |                   |                       |
| purposes.             |                   |                       |
+-----------------------+-------------------+-----------------------+
| **Do I process        |                   |                       |
| sensitive data?**     |                   |                       |
|                       |                   |                       |
| Sensitive data is     |                   |                       |
| data consisting of    |                   |                       |
| racial or ethnic      |                   |                       |
| origin, political     |                   |                       |
| opinions, religious   |                   |                       |
| or philosophical      |                   |                       |
| beliefs, or trade     |                   |                       |
| union membership,     |                   |                       |
| genetic **data**,     |                   |                       |
| biometric **data**    |                   |                       |
| , **data** concerning |                   |                       |
| health or **data**    |                   |                       |
| concerning a          |                   |                       |
| person\'s sex life or |                   |                       |
| sexual orientation    |                   |                       |
+-----------------------+-------------------+-----------------------+
| **What are my lawful  |                   |                       |
| grounds for each of   |                   |                       |
| the processing        |                   |                       |
| activities that I     |                   |                       |
| have identified?**    |                   |                       |
|                       |                   |                       |
| -   the data subject  |                   |                       |
|     has given consent |                   |                       |
|     to the processing |                   |                       |
|     of his or her     |                   |                       |
|     personal data for |                   |                       |
|     one or more       |                   |                       |
|     specific          |                   |                       |
|     purposes;         |                   |                       |
|                       |                   |                       |
| -   processing is     |                   |                       |
|     necessary for the |                   |                       |
|     performance of a  |                   |                       |
|     contract to which |                   |                       |
|     the data subject  |                   |                       |
|     is party or in    |                   |                       |
|     order to take     |                   |                       |
|     steps at the      |                   |                       |
|     request of the    |                   |                       |
|     data subject      |                   |                       |
|     prior to entering |                   |                       |
|     into a contract;  |                   |                       |
|                       |                   |                       |
| -   processing is     |                   |                       |
|     necessary for     |                   |                       |
|     compliance with a |                   |                       |
|     legal obligation  |                   |                       |
|     to which the      |                   |                       |
|     controller is     |                   |                       |
|     subject;          |                   |                       |
|                       |                   |                       |
| -   processing is     |                   |                       |
|     necessary in      |                   |                       |
|     order to protect  |                   |                       |
|     the vital         |                   |                       |
|     interests of the  |                   |                       |
|     data subject or   |                   |                       |
|     of another        |                   |                       |
|     natural person;   |                   |                       |
|                       |                   |                       |
| -   processing is     |                   |                       |
|     necessary for the |                   |                       |
|     performance of a  |                   |                       |
|     task carried out  |                   |                       |
|     in the public     |                   |                       |
|     interest or in    |                   |                       |
|     the exercise of   |                   |                       |
|     official          |                   |                       |
|     authority vested  |                   |                       |
|     in the            |                   |                       |
|     controller;       |                   |                       |
|                       |                   |                       |
| -   processing is     |                   |                       |
|     necessary for the |                   |                       |
|     purposes of the   |                   |                       |
|     legitimate        |                   |                       |
|     interests pursued |                   |                       |
|     by the controller |                   |                       |
|     or by a third     |                   |                       |
|     party, except     |                   |                       |
|     where such        |                   |                       |
|     interests are     |                   |                       |
|     overridden by the |                   |                       |
|     interests or      |                   |                       |
|     fundamental       |                   |                       |
|     rights and        |                   |                       |
|     freedoms of the   |                   |                       |
|     data subject      |                   |                       |
|     which require     |                   |                       |
|     protection of     |                   |                       |
|     personal data, in |                   |                       |
|     particular where  |                   |                       |
|     the data subject  |                   |                       |
|     is a child.       |                   |                       |
|                       |                   |                       |
| If one of your        |                   |                       |
| grounds is Legitimate |                   |                       |
| Interests, be sure to |                   |                       |
| carry out the         |                   |                       |
| Legitimate Interests  |                   |                       |
| Assessment -- see the |                   |                       |
| template for this in  |                   |                       |
| the GDPR Pack         |                   |                       |
+-----------------------+-------------------+-----------------------+
| **Have you identified |                   |                       |
| all transfers to      |                   |                       |
| third parties and     |                   |                       |
| what country the      |                   |                       |
| third party is in?**  |                   |                       |
|                       |                   |                       |
| There are strict      |                   |                       |
| rules on transfers to |                   |                       |
| third parties outside |                   |                       |
| of the EEA. Watch the |                   |                       |
| video on transfers    |                   |                       |
| outside of the EEA    |                   |                       |
| and check whether the |                   |                       |
| country has an        |                   |                       |
| adequacy finding or   |                   |                       |
| if it is in the       |                   |                       |
| United States it is   |                   |                       |
| certified under the   |                   |                       |
| Privacy Shield. You   |                   |                       |
| will also need this   |                   |                       |
| information to add to |                   |                       |
| your Privacy Notice.  |                   |                       |
| See the Data Transfer |                   |                       |
| Checklist in the GDPR |                   |                       |
| Pack.                 |                   |                       |
+-----------------------+-------------------+-----------------------+
| **Do I have a GDPR    |                   |                       |
| compliant Privacy     |                   |                       |
| Notice?**             |                   |                       |
|                       |                   |                       |
| Chances are that even |                   |                       |
| if you have a privacy |                   |                       |
| policy, it is not     |                   |                       |
| GDPR compliant as     |                   |                       |
| GDPR prescribes       |                   |                       |
| numerous things that  |                   |                       |
| need to be included   |                   |                       |
| in the privacy        |                   |                       |
| notice. See the       |                   |                       |
| template Privacy      |                   |                       |
| Notice in the GDPR    |                   |                       |
| pack and complete it. |                   |                       |
+-----------------------+-------------------+-----------------------+
| **Have I added my     |                   |                       |
| GDPR compliant        |                   |                       |
| Privacy Notice to my  |                   |                       |
| website?**            |                   |                       |
|                       |                   |                       |
| If you don't already  |                   |                       |
| have a link on the    |                   |                       |
| footer of your        |                   |                       |
| website to your       |                   |                       |
| privacy policy, add   |                   |                       |
| one in so that it     |                   |                       |
| appears on every page |                   |                       |
| of your website. If   |                   |                       |
| you do already have   |                   |                       |
| one, make sure that   |                   |                       |
| you replace the old   |                   |                       |
| privacy policy with   |                   |                       |
| the new privacy       |                   |                       |
| notice.               |                   |                       |
+-----------------------+-------------------+-----------------------+
| **Have I sent my GDPR |                   |                       |
| compliant Privacy     |                   |                       |
| Notice to my          |                   |                       |
| subscribers?**        |                   |                       |
|                       |                   |                       |
| GDPR requires you to  |                   |                       |
| send your Privacy     |                   |                       |
| Notice to your        |                   |                       |
| subscribers to        |                   |                       |
| confirm amongst other |                   |                       |
| things how you        |                   |                       |
| collect and process   |                   |                       |
| their personal data,  |                   |                       |
| for what purposes you |                   |                       |
| use their data, the   |                   |                       |
| legal grounds of      |                   |                       |
| processing such data, |                   |                       |
| how you keep their    |                   |                       |
| data secure and their |                   |                       |
| rights in relation to |                   |                       |
| such data. See the    |                   |                       |
| Email Sending Privacy |                   |                       |
| Notice template in    |                   |                       |
| the GDPR Pack.        |                   |                       |
+-----------------------+-------------------+-----------------------+
| **Have I added my Opt |                   |                       |
| In wording to my sign |                   |                       |
| up box?**             |                   |                       |
|                       |                   |                       |
| If you have a sign up |                   |                       |
| box on your website   |                   |                       |
| that collects email   |                   |                       |
| addresses etc in      |                   |                       |
| return for your       |                   |                       |
| newsletter or other   |                   |                       |
| free opt in, ensure   |                   |                       |
| that you have GDPR    |                   |                       |
| compliant opt in      |                   |                       |
| wording at the point  |                   |                       |
| of collection (ie     |                   |                       |
| underneath the sign   |                   |                       |
| up box) together with |                   |                       |
| a link to your        |                   |                       |
| Privacy Notice. See   |                   |                       |
| the template Opt In   |                   |                       |
| wording in the GDPR   |                   |                       |
| pack.                 |                   |                       |
+-----------------------+-------------------+-----------------------+
| **Have I obtained     |                   |                       |
| GDPR compliant        |                   |                       |
| consent for           |                   |                       |
| electronic marketing  |                   |                       |
| communications?**     |                   |                       |
|                       |                   |                       |
| See the ICO checklist |                   |                       |
| for compliant consent |                   |                       |
| in the GDPR pack. If  |                   |                       |
| you do not have       |                   |                       |
| compliant consent,    |                   |                       |
| email your list for   |                   |                       |
| fresh consent -- see  |                   |                       |
| the email for fresh   |                   |                       |
| consent template in   |                   |                       |
| the GDPR pack (and    |                   |                       |
| watch the video about |                   |                       |
| obtaining consent as  |                   |                       |
| part of a             |                   |                       |
| re-engagement         |                   |                       |
| campaign)             |                   |                       |
+-----------------------+-------------------+-----------------------+
| **Have I obtained     |                   |                       |
| GDPR compliant        |                   |                       |
| consent for           |                   |                       |
| processing sensitive  |                   |                       |
| data**                |                   |                       |
|                       |                   |                       |
| Processing sensitive  |                   |                       |
| data requires         |                   |                       |
| explicit consent --   |                   |                       |
| this could be by the  |                   |                       |
| data subject signing  |                   |                       |
| the form where data   |                   |                       |
| has been collected or |                   |                       |
| a double verification |                   |                       |
| process.              |                   |                       |
+-----------------------+-------------------+-----------------------+
| **Have I put in place |                   |                       |
| a procedure for       |                   |                       |
| recording consents    |                   |                       |
| including explicit    |                   |                       |
| consent for sensitive |                   |                       |
| data?**               |                   |                       |
|                       |                   |                       |
| GDPR requires this.   |                   |                       |
| Does your email       |                   |                       |
| marketing system      |                   |                       |
| track consents to opt |                   |                       |
| ins? Do you keep a    |                   |                       |
| filing system of hard |                   |                       |
| copy consent forms?   |                   |                       |
+-----------------------+-------------------+-----------------------+
| **Have I put in place |                   |                       |
| a system for managing |                   |                       |
| opt outs/ withdrawing |                   |                       |
| of consent?**         |                   |                       |
|                       |                   |                       |
| GDPR requires you to  |                   |                       |
| keep records of opt   |                   |                       |
| outs. Does your email |                   |                       |
| marketing system      |                   |                       |
| manage this for you?  |                   |                       |
+-----------------------+-------------------+-----------------------+
| **Have I put in place |                   |                       |
| GDPR compliant        |                   |                       |
| Processor Agreements  |                   |                       |
| with the third        |                   |                       |
| parties to whom I     |                   |                       |
| transfer personal     |                   |                       |
| data?**               |                   |                       |
|                       |                   |                       |
| Under GDPR it is      |                   |                       |
| mandatory to have a   |                   |                       |
| written agreement     |                   |                       |
| with your third party |                   |                       |
| processor (eg         |                   |                       |
| payroll, software     |                   |                       |
| providers etc). GDPR  |                   |                       |
| prescribes what must  |                   |                       |
| be included in that   |                   |                       |
| agreement. See the    |                   |                       |
| Processor Agreement   |                   |                       |
| template in the GDPR  |                   |                       |
| Pack.                 |                   |                       |
+-----------------------+-------------------+-----------------------+
| **Have I put in place |                   |                       |
| a system for data     |                   |                       |
| subject requests?**   |                   |                       |
|                       |                   |                       |
| As a general rule,    |                   |                       |
| you can no longer     |                   |                       |
| charge for data       |                   |                       |
| subject requests and  |                   |                       |
| you must respond      |                   |                       |
| within 30 days. See   |                   |                       |
| the video on this and |                   |                       |
| the Subject Access    |                   |                       |
| Record in the GDPR    |                   |                       |
| Pack.                 |                   |                       |
+-----------------------+-------------------+-----------------------+
| **Do I need to        |                   |                       |
| appoint a Data        |                   |                       |
| Protection Officer?** |                   |                       |
|                       |                   |                       |
| Certain businesses    |                   |                       |
| will need to appoint  |                   |                       |
| a Data Protection     |                   |                       |
| Officer. GDPR         |                   |                       |
| prescribes who this   |                   |                       |
| might be and what     |                   |                       |
| their duties are --   |                   |                       |
| see the video on DPOs |                   |                       |
| and the DPIA          |                   |                       |
| Checklist in the GDPR |                   |                       |
| Pack.                 |                   |                       |
+-----------------------+-------------------+-----------------------+
| **Do I need to carry  |                   |                       |
| out a Data Protection |                   |                       |
| Impact Assessment?**  |                   |                       |
|                       |                   |                       |
| A DPIA is required    |                   |                       |
| when the processing   |                   |                       |
| is likely to result   |                   |                       |
| in a high risk to the |                   |                       |
| rights and freedoms   |                   |                       |
| of natural persons.   |                   |                       |
| See the DPIA          |                   |                       |
| checklist in the GDPR |                   |                       |
| Pack.                 |                   |                       |
+-----------------------+-------------------+-----------------------+
| **Have I put in place |                   |                       |
| a system for data     |                   |                       |
| breach                |                   |                       |
| notification?**       |                   |                       |
|                       |                   |                       |
| A data breach occurs  |                   |                       |
| where there is a loss |                   |                       |
| alteration,           |                   |                       |
| unauthorised          |                   |                       |
| disclosure of or      |                   |                       |
| access to personal    |                   |                       |
| data AND there is a   |                   |                       |
| risk to the rights    |                   |                       |
| and freedoms of       |                   |                       |
| individuals. If there |                   |                       |
| is a data breach, you |                   |                       |
| must notify the ICO   |                   |                       |
| within 72 hours of    |                   |                       |
| the breach. See the   |                   |                       |
| Data Breach Checklist |                   |                       |
| and Data Breach       |                   |                       |
| Record in the GDPR    |                   |                       |
| Pack.                 |                   |                       |
+-----------------------+-------------------+-----------------------+
| **Is your insurance   |                   |                       |
| adequate?**           |                   |                       |
|                       |                   |                       |
| Contact your          |                   |                       |
| insurance broker to   |                   |                       |
| discuss any increased |                   |                       |
| liability due to GDPR |                   |                       |
| (eg increased fines   |                   |                       |
| or additional         |                   |                       |
| liability as a data   |                   |                       |
| processor) and ensure |                   |                       |
| that your insurance   |                   |                       |
| coverage is           |                   |                       |
| sufficient.           |                   |                       |
+-----------------------+-------------------+-----------------------+
| **Do I have a Data    |                   |                       |
| Retention Policy in   |                   |                       |
| place?**\             |                   |                       |
| If not, see the       |                   |                       |
| template in the GDPR  |                   |                       |
| Pack.                 |                   |                       |
+-----------------------+-------------------+-----------------------+
| **Have I reviewed the |                   |                       |
| security of my        |                   |                       |
| data?**               |                   |                       |
|                       |                   |                       |
| Watch out for a video |                   |                       |
| in the Facebook group |                   |                       |
| where I will be       |                   |                       |
| interviewing a data   |                   |                       |
| security expert.      |                   |                       |
+-----------------------+-------------------+-----------------------+
| **Do I need to pay    |                   |                       |
| for the Controller    |                   |                       |
| Charge?**             |                   |                       |
|                       |                   |                       |
| The obligation to     |                   |                       |
| register data         |                   |                       |
| processing activities |                   |                       |
| with the ICO is being |                   |                       |
| ended with GDPR.      |                   |                       |
| However, a Controller |                   |                       |
| Charge will be        |                   |                       |
| introduced ranging    |                   |                       |
| from £40 to £2900.    |                   |                       |
| See the video on this |                   |                       |
| for more details.     |                   |                       |
| Your existing         |                   |                       |
| registration with the |                   |                       |
| ICO will continue     |                   |                       |
| until the expiry at   |                   |                       |
| the end of its 12     |                   |                       |
| months and then you   |                   |                       |
| will need to pay the  |                   |                       |
| Controller Charge if  |                   |                       |
| it applies.           |                   |                       |
+-----------------------+-------------------+-----------------------+
| **If I have           |                   |                       |
| employees, have I     |                   |                       |
| worked out lawful     |                   |                       |
| grounds for           |                   |                       |
| processing and        |                   |                       |
| obtained signed       |                   |                       |
| copies of the         |                   |                       |
| employee Privacy      |                   |                       |
| Notice?**             |                   |                       |
|                       |                   |                       |
| Historically you may  |                   |                       |
| have relied on        |                   |                       |
| consent in an         |                   |                       |
| Employment Agreement  |                   |                       |
| to process employee   |                   |                       |
| data. Post GDPR you   |                   |                       |
| will need to work out |                   |                       |
| separate lawful       |                   |                       |
| grounds of processing |                   |                       |
| for each processing   |                   |                       |
| activity (eg payroll  |                   |                       |
| processing for        |                   |                       |
| contractual purposes, |                   |                       |
| social security       |                   |                       |
| processing for        |                   |                       |
| requirements of law   |                   |                       |
| etc). Grounds other   |                   |                       |
| than consent should   |                   |                       |
| be relied on where    |                   |                       |
| possible as consent   |                   |                       |
| can be withdrawn at   |                   |                       |
| any time. Where       |                   |                       |
| consent is necessary, |                   |                       |
| this should be in a   |                   |                       |
| separate document to  |                   |                       |
| the Employment        |                   |                       |
| Agreement. The        |                   |                       |
| Employee Privacy      |                   |                       |
| Notice template is in |                   |                       |
| the GDPR pack. See    |                   |                       |
| the Employee          |                   |                       |
| Checklist in the GDPR |                   |                       |
| Pack.                 |                   |                       |
+-----------------------+-------------------+-----------------------+
| **If I have           |                   |                       |
| employees, have I     |                   |                       |
| arranged for data     |                   |                       |
| protection training   |                   |                       |
| for them?**           |                   |                       |
|                       |                   |                       |
| Employees will need   |                   |                       |
| to be aware of how to |                   |                       |
| properly process      |                   |                       |
| data, record          |                   |                       |
| consents, how long to |                   |                       |
| store data, when to   |                   |                       |
| report data breaches, |                   |                       |
| how to respond to     |                   |                       |
| data subject          |                   |                       |
| requests. If you      |                   |                       |
| require training for  |                   |                       |
| your employees,       |                   |                       |
| please email us at    |                   |                       |
| suppo                 |                   |                       |
| rt\@suzannedibble.com |                   |                       |
+-----------------------+-------------------+-----------------------+
| **If I have           |                   |                       |
| employees, have I put |                   |                       |
| in place systems for  |                   |                       |
| employee subject      |                   |                       |
| access requests?**    |                   |                       |
|                       |                   |                       |
| Subject access        |                   |                       |
| requests are most     |                   |                       |
| commonly submitted    |                   |                       |
| from employees and    |                   |                       |
| often in the context  |                   |                       |
| of a dispute. Ensure  |                   |                       |
| that you have a       |                   |                       |
| process in place to   |                   |                       |
| deal with such        |                   |                       |
| requests and to have  |                   |                       |
| appropriate templates |                   |                       |
| for the employee to   |                   |                       |
| make the request and  |                   |                       |
| for your reply (such  |                   |                       |
| templates are in the  |                   |                       |
| GDPR Pack).           |                   |                       |
+-----------------------+-------------------+-----------------------+
