**© Kohd Group Limited 2026. These templates are covered under Kohd Group Limited's workshop license and may be used internally for the purposes authorized. Based on original work by Suzanne Dibble.**

**Email disclaimer and confidentiality wording**

People often ask me whether they need a disclaimer on their emails.

 

The short answer is, you don\'t have to have a disclaimer but it could
be helpful in certain situations.

 

If your computer system picked up a virus and this was passed to an
email recipient\'s system and caused damage, there is a risk that you
might be held liable for that loss for failing to detect the virus and
passing it on.

 

So a disclaimer you may like to add to the bottom of your email is:

 

*\"Please note that we cannot accept any responsibility for viruses and
it is your responsibility to scan or otherwise check this email and any
attachments.\"*

 

If you are providing information, guidance or advice in your emails, you
may also want to add:

 

*\"The information contained in this email is provided for information
purposes only. The contents of this email are not intended to amount to
advice and you should not rely on any of the contents of this email.
\[Professional advice should be obtained before taking or refraining
from taking any action as a result of the above contents of this
email\]. We disclaim all liability and responsibility arising from any
reliance placed on any of the contents of this email.\"*

 Here\'s a confidentiality notice you might want to include for your
more \'commercially sensitive/confidential\' emails:

 

*\"This email is confidential and intended solely for the use of the
individual to whom it is addressed. Any dissemination, distribution,
copying or use of this communication without prior permission of the
addressee is strictly prohibited. If you are not the intended recipient
you have received this email in error. Please accept our apologies,
notify the sender on the above address, and then delete all copies of
this email.\"*

 

In order to increase the chances of the notice being effective it should
appear at the top of your e-mail and should not be generated
automatically but only added to particularly sensitive emails.

 

You don\'t legally have to include a disclaimer or confidentiality
notice on your emails - these are for your protection and you can choose
whether to do so or not.

 

**But what you do need, by law, to include in every email is the
following:**

 

If you are trading through a company or an LLP, you must include the
following information on ALL business communications, including e-mails:

 

\* Your company's registered name.

\* The part of the UK in which your company is registered, for example,
England and Wales.

\* Your company's registered number.

\* Your company's registered office address.

 

If you are a member of a regulated profession (such as a financial
services company or a solicitor) you must also provide:

 

\* The details of any professional body or similar institution with
which you are registered.

\* Your professional title and the member state where that title has
been awarded.

\* A reference (ideally through a hyperlink) to the professional rules
applicable to you. If you can't add a hyperlink, you must explain how
such professional rules can be accessed.
