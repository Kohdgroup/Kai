**© Kohd Group Limited 2026. These templates are covered under Kohd Group Limited's workshop license and may be used internally for the purposes authorized. Based on original work by Suzanne Dibble.**

\[NOTE: THIS AGREEMENT IS DRAFTED IN FAVOUR OF THE CUSTOMER SO SHOULD
NOT BE USED IF YOU ARE PROVIDING WEBSITE DESIGN/DEVELOPMENT SERVICES\]

\[PRINT OUT ON YOUR LETTERHEAD\]

\[INSERT NAME OF WEBSITE DEVELOPER\]

**\[INSERT ADDRESS\]**

**\[INSERT DATE\]**

Dear \[**INSERT FIRST NAME OF WEBSITE DEVELOPER**\]

**Website Development Agreement**

Thank you for your quote for designing and developing the website for
our business \[**INSERT NAME OF YOUR BUSINESS**\] ("Website").

We would like to proceed on the following terms (which shall take
precedence over your terms and conditions or any course of dealing or
industry practice):

**Charges**

1.  You will design, develop and deliver the Website ("Services") in
    accordance with the Specification and Project Plan annexed to this
    letter \[**and host the Website from a server as agreed between us
    in writing in accordance with agreed service levels**\] \[**NOTE:
    DELETE THE PART OF THE SENTENCE IN SQUARE BRACKETS IF HOSTING IS NOT
    BEING PROVIDED**\] for the agreed fee of \[**INSERT TOTAL AGREED
    FEE**\] ("Charges").

2.  The Charges shall be payable as to 25% on commencement of the
    Services, 25% on our approval of the design of the Website and 50%
    on Project Completion (as defined below).

3.  The Charges are inclusive of VAT.

**Services**

4.  For the design of the Website, you will create designs for the
    look-and-feel, layout and functionality of the Website. Included in
    the agreed price is \[**two**\] main designs plus the opportunity
    for us to make up to two rounds of revisions. If we require further
    revisions over and above the two revisions that are included in the
    Charges, we understand that you will quote an additional amount
    which we must agree to before you proceed with such further
    revisions.

5.  You will perform the Services with all reasonable care and skill and
    in accordance with generally recognised commercial practices and
    standards and will comply with all laws and regulations applicable
    to the provision of the Services.

6.  You recognise that the timing of the delivery of our Website is
    crucial to our business and you agree to meet all dates, deadlines,
    milestones and timetables that are set out in the Specification
    and/or Project Plan and/or as agreed between us in writing
    (including over email) ("Deadlines") subject to us providing the
    required input materials by the due dates.

7.  \[You shall appoint a designated member of staff to work on the
    Project and shall use all reasonable endeavours to ensure that the
    same person acts as your contact throughout the Project.\]\[**NOTE:
    DELETE THIS PARAGRAPH WHERE THE DEVELOPER IS A ONE PERSON
    BUSINESS**\]

8.  You will test the Website on all current browsers and mobile devices
    to ensure that the Website has full functionality and that the look
    and feel is maintained on such browsers and mobile devices.

9.  On the Project Completion date, you shall (i) provide us with all
    relevant and appropriate user names passwords and keys to enable us
    to undertake any future alterations adjustments or changes to the
    Website and (ii) back up the Website.

10. You shall provide us with up to \[**10**\] email addresses with the
    suffix url being the same as the Website url for no additional
    charge.

11. \[You shall procure that the Website is hosted with a reputable
    third party hosting supplier. The fee for the first year's hosting
    of the Website is included in the fees agreed for the set out in the
    order form and the fee for subsequent years' hosting shall be
    £\[INSERT FEE\] plus VAT per annum.\]\[**NOTE: DELETE THIS PARAGRAPH
    IF YOUR WEBSITE DEVELOPER IS NOT PROVIDING HOSTING**\]

12. \[You will update the Website with content provided by us from time
    to time \[without charge\]/\[for the additional fees as agreed
    between us and evidenced in email correspondence\].\] **OR** \[You
    shall grant us access to the server on which the Website is hosted
    in order for us to update information held on the Website.\]
    \[**NOTE: AMEND THIS PARAGRAPH AS APPROPRIATE TO REFLECT WHAT HAS
    BEEN AGREED**\]

**Intellectual Property**

13. All Intellectual Property Rights in the Project Plan, the
    Specification and the Website (including in the look and feel of the
    Website, the content of the Website and any bespoke software that
    has been created as part of the Services) shall be our property, and
    you hereby assign all such Intellectual Property Rights to us and
    agree to execute all documents necessary to give effect to this
    paragraph.

14. You warrant that you have not copied any materials or infringed any
    third party's copyright or any other Intellectual Property Rights in
    providing the Services. If this is not the case and you have
    infringed a third party's Intellectual Property Rights and they
    bring a claim against us for such infringement, you agree to
    reimburse us fully for (or in legal terminology indemnify us and
    keep us indemnified against) all damages, costs, losses, expenses,
    fees (including reasonable professional fees) and any other
    liability arising as a result of any such action, claim of
    infringement.

15. Where elements of the Website include products that are licensed to
    you by a third party (such as images and third party software), you
    sublicense such products to us on a perpetual, royalty free,
    worldwide, non-exclusive basis. You warrant that you are duly
    authorised to sublicense such products. All licence fees for such
    third party products are included in the Charges and no additional
    fees are payable.

16. You shall not use or re-create the look and feel of the Website or
    anything substantially similar to it without our prior written
    consent.

17. All materials, equipment and tools, drawings, specifications and
    data supplied by us to you shall at all times be and remain our
    exclusive property, but shall be held by you in safe custody at your
    own risk and maintained and kept in good condition by you until
    returned to us at our request.

18. You will keep all information disclosed by us to you (which is not
    already in the public domain otherwise than by you actin gin breach
    of this paragraph) strictly confidential and shall not disclose it
    to any third party and shall use it only for the purpose of
    providing the Services.

**Liability and termination**

19. You shall, without further charge, undertake any work required to
    rectify any faults, defects, errors or bugs in the Website or
    non-compliance with the Specification that result from the work
    undertaken by you that are notified to you by us within the 12
    months following the date on which we are satisfied that the Website
    is completed in accordance with the Specification ("Project
    Completion").

20. Where we suffer any loss or liability as a result of downtime of the
    server on which the Website is hosted for whatever reason, you shall
    use every effort to recover all amounts possible under your
    agreements with the relevant third party hosting entity and shall
    within 7 days of your receipt, pass on to us all amounts recovered
    by you pursuant to such contracts.

21. If you fail to meet any Deadline, other than by reason of us not
    providing the necessary input materials, we may terminate the
    agreement between us on immediate notice to you and without any
    liability to pay any further charges. You may retain all payments
    that have been made to you up to such date but no further payments
    (including for your work in progress) shall be due.

22. If we are not happy with the design of the Website, we may terminate
    the agreement with immediate effect on notice to you and without any
    liability to pay any further charges. You may retain the 25% deposit
    already paid (except where the designs fail to meet the
    Specification or are not to a quality that would reasonably be
    expected of a competent, commercial website designer, in which case
    you will refund us all amounts paid to you within 7 days of our
    termination) but may not charge an additional amount.

23. We may terminate the agreement between us on immediate notice to you
    and without any further liability to pay any amount to you if:

    a.  You are in breach of this agreement in any material respect;

    b.  You are, in our reasonable opinion, incompetent or negligent in
        your provision of the Services;

    c.  You are declared bankrupt or make any arrangement with or for
        the benefit of your creditors or have a county court
        administration order made against you under the County Court Act
        1984;

    d.  You make a resolution for your winding up, make an arrangement
        or composition with your creditors or make an application to a
        court of competent jurisdiction for protection from your
        creditors or an administration or winding-up order is made or an
        administrator or receiver is appointed in relation to you; or

    e.  You are convicted of a criminal offence or commit any fraud or
        dishonesty or act in any manner which in our opinion brings or
        is likely to bring you or us into disrepute or is materially
        adverse to our interests.

24. Our rights to terminate as set out in these terms are without
    prejudice to any other rights that we might have at law to terminate
    the agreement between us or to accept any breach by you of this
    agreement as having brought the agreement to an end. Any delay by us
    in exercising our rights to terminate shall not constitute a waiver
    of these rights.

25. On any termination of the agreement between us, you will within 24
    hours of termination return to us all of our materials and all
    copies of the Specification and Project Plan and will provide us
    with an electronic copy of the Website (including all content on the
    Website) in its current form, whether complete or incomplete. You
    will provide (without charge) all assistance as we reasonably
    require in transferring the hosting of the Website to us or to
    another service provider.

**General provisions**

26. You may not assign the agreement between us but we may assign this
    agreement provided that we give you prior written notice.

27. These terms and conditions supersede and replace all prior
    agreements, understandings or arrangements between us (whether oral
    or in writing) relating to the Website and/or the Services.

28. The agreement between us is not intended to benefit, or be
    enforceable by, any other person.

29. Any variation to these terms and conditions needs to be in writing
    and signed by or on behalf of each of us for it to be effective.

30. The agreement between us is governed by the laws of England and we
    irrevocably agree that the courts of England have exclusive
    jurisdiction to settle any dispute or claim that arises out of or in
    connection with this agreement.

We look forward to working with you and should be grateful if you would
sign where indicated below to acknowledge your agreement to the terms
and conditions of this letter.

Yours sincerely

**\[INSERT YOUR NAME OR YOUR LIMITED COMPANY NAME\]**

I/we hereby agree to the terms of this letter

......................................................................

\[**INSERT NAME OF WEBSITE DEVELOPER OR THE LIMITED COMPANY**\]

Date.................................................................

Annex 1 Project plan

**\[Set out key dates eg:**

**Design submitted by \[insert date\]**

**Comments on design by \[insert date\]**

**Revisions of design by \[insert date\]**

**Further comments on design by \[insert date\]**

**Further revisions of design by \[insert date\]**

**Design agreed by \[insert date\]**

**Phase 1 of build delivered by \[insert date\]**

**Phase 1 of build approved by \[insert date\]**

**Phase 2 of build delivered by \[insert date\]**

**Phase 2 of build approved by \[insert date\]**

**Project Completion by \[insert date\]**

**Go live date by \[insert date\]**

Annex 2 Specification

**\[Set out the specification of the Website eg:**

**Look and feel**

**Type and number of template pages**

**Functionality**

**E-commerce**

**Content Management System**

**Images**

**Colour scheme**

**Layout**

**Page links**

**Footer**

**Header\]**
