**© Kohd Group Limited 2026. These templates are covered under Kohd Group Limited's workshop license and may be used internally for the purposes authorized. Based on original work by Suzanne Dibble.**

**Copyright Notice**

Copyright © \[**INSERT *YEAR(S) OF FIRST PUBLICATION, EG
\"2015-2021****\] \[**INSERT NAME OR OWNER OF COPYRIGHT**\]*

We are the owner of all intellectual property rights in this article
\[OR our website, and in the material published on it\]. These works are
protected by copyright laws and treaties around the world. We grant to
you a worldwide, non-exclusive, royalty-free, revocable licence to view
this article \[OR website and the material on this website\] on a
computer or mobile device via a web browser, to copy and store this
article \[OR website and the material on this website\] in your web
browser cache memory and to print pages from this website for your own
personal and non-commercial use. You may not reproduce in any format
(including on another website) any part of our website (including
content, images, designs, look and feel) without our prior written
consent. Other than the above, we do not grant you any other rights in
relation to this website or the material on this website and all other
rights are reserved. For the avoidance of doubt, you must not adapt,
edit, change, transform, publish, republish, distribute, redistribute,
broadcast, rebroadcast, or show or play in public this website or the
material on this website (in any form or media) without our prior
written permission. If you print off, reproduce, copy or download any
part of our site in breach of this notice, your right to use our website
will cease immediately and you must, at our option, return or destroy
any copies of the materials you have made.

We take the protection of our copyright very seriously. If we discover
that you have breached the terms of the above licence, we may bring
legal proceedings against you and seek monetary damages and/or an
injunction to stop you using our materials. You could also be ordered to
pay our legal costs.
