**© Kohd Group Limited 2026. These templates are covered under Kohd Group Limited's workshop license and may be used internally for the purposes authorized. Based on original work by Suzanne Dibble.**

**\[NOTE: THE ICO HAS PUBLISHED NEW GUIDANCE ON USING COOKIES: you can
no longer rely on a statement that 'by continuing to browse your
website, the user consents to the use of cookies' or similar. You need
to do is have an effective cookie consent mechanism that obtains opt-in
consent to the use of all non-essential cookies, prior to such cookies
being fired. When users first land on your site, you must use a cookie
consent mechanism that provides information about the cookies you are
using. You should also provide more detailed information about the
cookies that you use via your Cookie Policy (or Privacy Notice) and link
to this from within the cookie consent mechanism. You also need to add a
link to either the header or footer of your website, so that the link to
the Cookie Policy can be accessed from each page of your website. Rather
than just have a link that states "Cookie Policy", you should make it
clearer what this is about by using words such as "Find out more about
how our site works and how we put you in control." Banners, pop-ups etc
can still be used, but in order to achieve compliance, these tools must
make the position absolutely clear to users. In addition, you cannot
have cookies firing on the landing page or have users being able to go
to another part of the website where cookies are used without clicking
on a consent option. You should not have boxes that emphasise 'agree' or
'allow' (or presumably 'accept') cookies, as opposed to 'block' or
'reject' cookies, as this influences website users to consent to the use
of cookies.\]**

**NOTE: WE HOPE TO SHARE OUR SUGGESTED COOKIE CONSENT MECHANISM IN W/C
15 JULY 2019**

**COOKIE POLICY**

**[What\'s a cookie?]{.underline}**

•A \"cookie\" is a piece of information that is stored on your
computer\'s hard drive if you agree to this and which records how you
move your way around a website so that, when you revisit that website,
it can present tailored options based on the information stored about
your last visit. Cookies can also be used to analyse traffic and for
advertising and marketing purposes.

•Cookies are used by nearly all websites and do not harm your system.

We are required to obtain your consent for all non-essential cookies
used on our website. You can block cookies (including essential cookies)
at any time by activating the setting on your browser that allows you to
refuse the setting of all or some cookies. However, if you use your
browser settings to block essential cookies you may not be able to
access all or parts of our site.

**[How do we use cookies?]{.underline}**

•We use cookies to track your use of our website. This enables us to
understand how you use the site and track any patterns with regards how
you are using our website. This helps us to develop and improve our
website as well as products and / or services in response to what you
might need or want.

•Cookies are either:

\- Session cookies: these are only stored on your computer during your
web session and are automatically deleted when you close your browser --
they usually store an anonymous session ID allowing you to browse a
website without having to log in to each page but they do not collect
any personal data from your computer; or

\- Persistent cookies: a persistent cookie is stored as a file on your
computer and it remains there when you close your web browser. The
cookie can be read by the website that created it when you visit that
website again. \[We use persistent cookies for Google Analytics.\]
\[**PLEASE DELETE IF YOU DO NOT USE GOOGLE ANALYTICS**\]

•Cookies can also be categorised as follows:

\- Strictly necessary cookies: These cookies are essential to enable you
to use the website effectively, such as when buying a product and / or
service. Without these cookies, the services available to you on our
website cannot be provided. These cookies do not gather information
about you that could be used for marketing or remembering where you have
been on the internet.

\- Performance cookies: These cookies enable us to monitor and improve
the performance of our website. For example, they allow us to count
visits, identify traffic sources and see which parts of the site are
most popular.

\- Functionality cookies: These cookies allow our website to remember
choices you make and provide enhanced features. For instance, we may be
able to provide you with news or updates relevant to the services you
use. They may also be used to provide services you have requested such
as viewing a video or commenting on a blog. The information these
cookies collect is usually anonymised.

**-** Targeting cookies: These cookies record your visit to our website,
the pages you have visited and the links you have followed. We will use
this information to make our website and the advertising displayed on it
more relevant to your interests.

\- First and third party cookies: First party cookies are cookies set by
our website. Third party cookies are cookies on our website that are set
by a website other than our website, such as where we have adverts on
our website or use Facebook pixels so that we can show you relevant
content from us when you are on Facebook.

**\[We use only first party cookies on this website.\] / \[We use third
party cookies on our website and these are set out in the table below.\]
\[NOTE: DELETE AS APPROPRIATE\]**

You can find more information about the individual cookies we use and
the purposes for which we use them in the table below:

+----------------------------------+----------------------------------+
| **Cookie Title**                 | **Purpose**                      |
|                                  |                                  |
| **Cookie Name**                  |                                  |
+==================================+==================================+
| **\[INSERT COOKIE TITLE\]**      | \[**INSERT DESCRIPTION OF THE    |
|                                  | PURPOSE FOR WHICH THE COOKIE IS  |
| **\[INSERT COOKIE NAME\]**       | USED**\]                         |
|                                  |                                  |
|                                  | Examples of purposes for which a |
|                                  | cookie may be used:              |
|                                  |                                  |
|                                  | This cookie \[is essential for   |
|                                  | our site to **OR** enables us    |
|                                  | to\]:                            |
|                                  |                                  |
|                                  | \[(a) Estimate our audience size |
|                                  | and usage pattern.\]             |
|                                  |                                  |
|                                  | \[(b) Store information about    |
|                                  | your preferences, and so allow   |
|                                  | us to customise our site and to  |
|                                  | provide you with offers that are |
|                                  | targeted to your individual      |
|                                  | interests.\]                     |
|                                  |                                  |
|                                  | \[(c) Speed up your searches.\]  |
|                                  |                                  |
|                                  | \[(d) Recognise you when you     |
|                                  | return to our site.\]            |
|                                  |                                  |
|                                  | \[(e) Allow you to use our site  |
|                                  | in a way that makes your         |
|                                  | browsing experience more         |
|                                  | convenient, for example, by      |
|                                  | allowing you to store items in   |
|                                  | an electronic shopping basket    |
|                                  | between visits. If you register  |
|                                  | with us or complete our online   |
|                                  | forms, we will use cookies to    |
|                                  | remember your details during     |
|                                  | your current visit, and any      |
|                                  | future visits provided the       |
|                                  | cookie was not deleted in the    |
|                                  | interim.\]                       |
|                                  |                                  |
|                                  | \[(f) \[**INSERT OTHER           |
|                                  | PURPOSES**\].\]                  |
+----------------------------------+----------------------------------+
| **NOTE: THE FOLLOWING ARE        |                                  |
| EXAMPLES FROM THE ICO COOKIE     |                                  |
| POLICY -- DELETE THIS SECTION    |                                  |
| FROM YOUR COOKIE POLICY. IF YOU  |                                  |
| DON'T KNOW WHAT COOKIES YOU ARE  |                                  |
| USING, COOKIEBOT PROVIDES A FREE |                                  |
| SCAN FOR YOU. I MAKE NO          |                                  |
| ENDORSEMENT AS TO THE FITNESS    |                                  |
| FOR PURPOSE OF COOKIEBOT OR      |                                  |
| OTHERWISE AND YOU USE IT AT YOUR |                                  |
| OWN RISK.**                      |                                  |
+----------------------------------+----------------------------------+
| Universal Analytics (Google)     | These cookies are used to        |
|                                  | collect information about how    |
| \_ga\                            | visitors use our website. We use |
| \_gali\                          | the information to compile       |
| \_gat\                           | reports and to help us improve   |
| \_gid                            | the website. The cookies collect |
|                                  | information in an anonymous      |
|                                  | form, including the number of    |
|                                  | visitors to the website and      |
|                                  | blog, where visitors have come   |
|                                  | to the website from and the      |
|                                  | pages they visited.              |
+----------------------------------+----------------------------------+
| Application firewall cookie      | This cookie is set by a          |
|                                  | third-party web application      |
| \_zjc\*                          | firewall from Dyn to help        |
|                                  | maintain the security and        |
|                                  | performance of our website. Some |
|                                  | traffic may receive a challenge  |
|                                  | to check if it is genuine and if |
|                                  | it is, a cookie is set so the    |
|                                  | user isn't challenged again.     |
+----------------------------------+----------------------------------+
| Security breach notification     | This cookie is essential for the |
| form cookie                      | breach notification form -- the  |
|                                  | form that public electronic      |
| ASP.NET\_SessionId               | communications service providers |
|                                  | use to notify the ICO of a       |
|                                  | security breach -- to operate.   |
|                                  | It is set only for those people  |
|                                  | using the form. This cookie is   |
|                                  | deleted when you close your      |
|                                  | browser.                         |
+----------------------------------+----------------------------------+
| YouTube cookies                  | We embed videos from our         |
|                                  | official YouTube channel using   |
| PREF\*\                          | YouTube's privacy-enhanced mode. |
| VSC\*\                           | This mode may set cookies on     |
| VISITOR\_INFO1\_LIVE\*\          | your computer once you click on  |
| remote\_sid\*                    | the YouTube video player, but    |
|                                  | YouTube will not store           |
|                                  | personally-identifiable cookie   |
|                                  | information for playbacks of     |
|                                  | embedded videos using the        |
|                                  | privacy-enhanced mode.\          |
|                                  | Read more at [YouTube's          |
|                                  | embedding videos information     |
|                                  | page.](http://www.               |
|                                  | google.com/support/youtube/bin/a |
|                                  | nswer.py?hl=en-GB&answer=171780) |
|                                  |                                  |
|                                  | PREF - \* Expires after eight    |
|                                  | months\                          |
|                                  | VSC - \* expires at the end of   |
|                                  | your session\                    |
|                                  | VISITOR\_INFO1\_LIVE - \*expires |
|                                  | after eight months\              |
|                                  | remote\_sid - \* expires at the  |
|                                  | end of your session              |
+----------------------------------+----------------------------------+
|                                  |                                  |
+----------------------------------+----------------------------------+

You can alter your cookie preferences at any time by **\[INSERT YOUR
MECHANISM FOR DOING THIS EG BY CLICKING ON THE COOKIE ICON AND ADJUSTING
THE SLIDERS TO 'OFF' \]**. Please refresh your page to ensure that the
new settings have taken effect.

You can also control your cookie settings through your web browser.

You can opt out of being tracked by Google Analytics across all
websites, by going
to [[http://tools.google.com/dlpage/gaoptout]{.underline}](http://tools.google.com/dlpage/gaoptout).

Except for essential cookies, all cookies will expire after \[**INSERT
EXPIRY PERIOD**\].

If you have any questions about the cookies that we use, feel free to
email us at \[**INSERT YOUR EMAIL ADDRESS**\].
