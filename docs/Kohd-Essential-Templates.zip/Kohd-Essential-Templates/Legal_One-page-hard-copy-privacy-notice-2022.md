The personal data collected from you on this form shall be processed in
accordance with our Privacy Policy overleaf.

We may from time to time send you details of our goods or services that
we feel may interest you, including promotional offers (such as buy five
days consultancy to get one free) by email or post. You may opt out of
receiving such communications at any time. If you would NOT like to
receive such offers, please tick below:

by post

by email

.................................

SIGNATURE

...............................

PRINT NAME

..............................

DATE

**Privacy notice**

+----------------------------------+----------------------------------+
| 1.  **How we use your personal   | In certain circumstances you can |
|     data**                       | ask us to delete your data. See  |
|                                  | the section entitled 'your       |
| **We are committed to protecting | rights' below for more           |
| your personal data.**            | information.                     |
|                                  |                                  |
| **The only data we collect from  |                                  |
| you is as submitted by you on    |                                  |
| the form overleaf.**             | We may anonymise your personal   |
|                                  | data (so that you can no longer  |
| **We will use your non-sensitive | be identified from such data)    |
| personal data to (i) register    | for research or statistical      |
| you as a new client, (ii) manage | purposes in which case we may    |
| payment, (iii) collect and       | use this information             |
| recover monies owed to us (iv)   | indefinitely without further     |
| to manage our relationship with  | notice to you.                   |
| you, (v) send you details of our |                                  |
| goods and services.**            | 5.  **Data retention**           |
|                                  |                                  |
| **Our legal grounds for          | We will only keep your personal  |
| processing your data are in      | data for as long as is necessary |
| relation to points (i) to (iv)   | to fulfil the purposes for which |
| above are for performance of a   | we collected it. We may retain   |
| contract with you and in         | your data to satisfy any legal,  |
| relation to (iii) and (v)        | accounting, or reporting         |
| above,** necessary for our       | requirements so for example we   |
| legitimate interests to develop  | need to keep certain information |
| our products/services and grow   | about you for 6 years after you  |
| our business and to recover      | cease to be a client for tax     |
| monies owed**.**                 | purposes.                        |
|                                  |                                  |
| **We will not share your details | You have the right to ask us to  |
| with third parties for marketing | delete the personal data we hold |
| purposes except with your        | about you in certain             |
| express consent.**               | circumstances. See section 6     |
|                                  | below.                           |
|                                  |                                  |
|                                  | **6. Your rights**               |
|                                  |                                  |
|                                  | **You are able to exercise       |
|                                  | certain rights in relation to    |
|                                  | your personal data that we       |
|                                  | process. These are set out in    |
|                                  | more detail at**                 |
|                                  |                                  |
|                                  | https://ico.                     |
|                                  | org.uk/for-organisations/guide-t |
|                                  | o-the-general-data-protection-re |
|                                  | gulation-gdpr/individual-rights/ |
+----------------------------------+----------------------------------+
| 2.  **Disclosure of your         | **In relation to a Subject       |
|     personal data**              | Access Right request, you may    |
|                                  | request that we inform you of    |
| **We may have to share your      | the data we hold about you and   |
| personal data with (i) service   | how we process it. We will not   |
| providers who provide IT and     | charge a fee for responding to   |
| system administration support,   | this request unless** your       |
| (ii) professional advisors       | request is clearly unfounded,    |
| including lawyers, bankers,      | repetitive or excessive in which |
| auditors and insurers (iii) HMRC | case we may charge a reasonable  |
| and other regulatory authorities | fee or decline to respond.       |
| (iv) third parties to whom we    |                                  |
| sell, transfer or merge parts of | We will, in most cases, reply    |
| our business or our assets.**    | within one month of the date of  |
|                                  | the request unless your request  |
| **We require all of these third  | is complex or you have made a    |
| parties to whom we transfer your | large number of requests in      |
| data to respect the security of  | which case we will notify you of |
| your personal data and to treat  | any delay and will in any event  |
| it in accordance with the law.   | reply within 3 months.           |
| They are only allowed to process |                                  |
| your personal data on our        | If you wish to make a Subject    |
| instructions.**                  | Access Request, please send the  |
|                                  | request to Kohd Group Limited,   |
|                                  | The Enterprise Centre, 291-305   |
|                                  | Lytham Rd, Blackpool FY4 1EW or  |
|                                  | email admin\@kohdgroup.com       |
|                                  | marked for the attention of the  |
|                                  | Data Compliance Officer.         |
+----------------------------------+----------------------------------+
| 3.  **International transfers**  | 7.  **Keeping your data up to    |
|                                  |     date**                       |
| **Some of our third party        |                                  |
| providers are businesses outside | **We have a duty to keep your    |
| of the UK/EEA in countries which | personal data up to date and     |
| do not always offer the same     | accurate so from time to time we |
| levels of protection for your    | will contact you to ask you to   |
| personal data. We do our best to | confirm that your personal data  |
| ensure a similar degree of       | is still accurate and up to      |
| security by ensuring that        | date.**                          |
| contracts, code of conduct or    |                                  |
| certification are in place which | **If there are any changes to    |
| give your personal data the same | your personal data (such as a    |
| protection it has within the UK/ | change of address) please let us |
| EEA. If we are not able to do    | know as soon as possible by      |
| so, we will request your         | writing to or emailing the       |
| explicit consent to the transfer | addresses set out in section 6   |
| and you can withdraw this        | above.**                         |
| consent at any time.**           |                                  |
+----------------------------------+----------------------------------+
| 4.  **Data security**            | 8.  **Complaints**               |
|                                  |                                  |
| We have put in place security    | We are committed to protecting   |
| measures to prevent your         | your personal data but if for    |
| personal data from being         | some reason you are not happy    |
| accidentally lost, used or       | with any aspect of how we        |
| accessed in an unauthorised way, | collect and use your data, you   |
| altered or disclosed. We also    | have the right to complain to    |
| limit access to your personal    | the Information Commissioner's   |
| data to those employees, agents, | Office (ICO), the UK supervisory |
| contractors and other third      | authority for data protection    |
| parties who have a business need | issues                           |
| to know such data. They will     | ([*www.ico.or                    |
| only process your personal data  | g.uk*](http://www.ico.org.uk/)). |
| on our instructions and are      |                                  |
| subject to a duty of             | We should be grateful if you     |
| confidentiality. We have put in  | would contact us first if you do |
| place procedures to deal with    | have a complaint so that we can  |
| any suspected personal data      | try to resolve it for you.       |
| breaches and will notify you and |                                  |
| any applicable regulator where   |                                  |
| we are legally required to do    |                                  |
| so.                              |                                  |
+----------------------------------+----------------------------------+
