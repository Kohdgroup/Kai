**© Kohd Group Limited 2026. These templates are covered under Kohd Group Limited's workshop license and may be used internally for the purposes authorized. Based on original work by Suzanne Dibble.**

**\[NOTE: DELETE THE ABOVE COPYRIGHT NOTICE, ALL NOTES AND ALL SQUARE
BRACKETS WITHIN THE DOCUMENT BEFORE SENDINF THE EMAIL\]**

**Template email to send to content thief:**

It has come to my attention that you are using copyrighted and protected
material on your website/blog. I am the author and the owner of the
copyright in \[**INSERT NAME OF ARTICLE**\] article that I discovered on
your website/blog at \[**INSERT WEB ADDRESS**\]. This article has been
copied from my original article called \[**INSERT TITLE OF ARTICLE**\]
on my website/blog at \[**INSERT WEB ADDRESS**\]. Use of this copyright
protected material without my permission is illegal under copyright
laws.

Please confirm by reply to this email/letter that you will take the
following actions immediately:

-   \[Re-write the post to include excerpts of no more than
    \[**three**\] sentences with a link to the original content.\]

-   \[Credit the material specifically to me, as author, and my website
    \[**INSERT YOUR WEB ADDRESS**\]\]

-   \[Provide compensation for use of my copyright protected material of
    £\[**INSERT AMOUNT OF COMPENSATION REQUESTED**\] paid via \[**INSERT
    PAYMENT METHOD**\]

-   \[Remove the copied material immediately.\]\*

***\*choose the options you want to include and remove the square
brackets and this note***

You have \[**5**\] days from the date of this email/letter to provide
such confirmation and to perform the requested actions. If I don't hear
from you within that timescale, I will be taking this matter further
which could include me notifying your advertisers, requesting that your
website be taken down or disabled by your hosting company and/or issuing
proceedings against you.
