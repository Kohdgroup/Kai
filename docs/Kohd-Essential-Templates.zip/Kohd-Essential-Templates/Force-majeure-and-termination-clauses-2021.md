**Note: You may not copy or use this template for any purpose unless you
have purchased this template document from Suzanne Dibble. You may not
allow others to copy it or use it for any purpose. Your use of this
template document is subject to our terms and conditions.**

 

+----------------------------------------------------------------------+
| **NOTES:**                                                           |
|                                                                      |
|                                                                      |
|                                                                      |
| Read my article on Force Majeure clauses and Termination clauses at: |
|                                                                      |
| <https://suzannedibble.com/covid19businesssupport/>                  |
|                                                                      |
| You can also watch my training at:                                   |
|                                                                      |
| <htt                                                                 |
| ps://sblavideos.s3-eu-west-1.amazonaws.com/Forcemajeuretraining.mp4> |
|                                                                      |
| The purpose of a *force majeure* clause is to excuse a party from    |
| performance of the agreement following the occurrence of an event    |
| beyond the reasonable control of the party which has hindered        |
| performance or made it impossible. It will also determine whether    |
| the agreement continues, is suspended or is terminated.              |
|                                                                      |
|                                                                      |
|                                                                      |
| Because the term *force majeure* has no established meaning or       |
| consequences in English law, the agreement must define both, which   |
| will vary from one agreement to the next. As such, do not use words  |
| such as "usual force majeure clauses shall apply", which has been    |
| held void for uncertainty.                                           |
|                                                                      |
|                                                                      |
|                                                                      |
| The definition in these clauses focuses on events beyond a party's   |
| reasonable control. Some clauses also require that a force majeure   |
| event should not be reasonably foreseeable. For example, in some     |
| extreme climates, the weather is not controllable but is totally     |
| predictable; should it fall within the definition of *force          |
| majeure*?                                                            |
|                                                                      |
|                                                                      |
|                                                                      |
| **Express reference to certain events**                              |
|                                                                      |
|                                                                      |
|                                                                      |
| Express inclusion or exclusion of events may be necessary when       |
| drafting and negotiating the clause, particularly if there is any    |
| doubt about whether specific events of particular importance in the  |
| context of the proposed transaction are included or excluded.        |
|                                                                      |
|                                                                      |
|                                                                      |
| From the point of view of the party that is most likely to invoke    |
| the *force majeure* clause, examples of events which may warrant     |
| express inclusion are:                                               |
|                                                                      |
|                                                                      |
|                                                                      |
| 1.  **Industrial action.** In the absence of a specific provision, a |
|     customer may argue that the supplier could have avoided the      |
|     industrial action by giving in to wage demands.                  |
|                                                                      |
| ```{=html}                                                           |
| <!-- -->                                                             |
| ```                                                                  |
| 1.  **Default of subcontractors or third party suppliers.** In the   |
|     absence of a specific provision, the customer may argue such     |
|     persons would not have defaulted if they had been more           |
|     diligently supervised or better paid by the supplier.            |
|                                                                      |
| Conversely, the party less likely to invoke the *force majeure*      |
| clause may wish to ensure that events such as these are expressly    |
| omitted. Such party may wish to agree only a very tightly defined    |
| clause, listing only certain acts, events, accidents or omissions as |
| *force majeure*, and excluding all other possibilities.              |
|                                                                      |
|                                                                      |
|                                                                      |
| **Rules against unfair terms**                                       |
|                                                                      |
|                                                                      |
|                                                                      |
|                                                                      |
|                                                                      |
| 1.  In the case of standard terms of business                        |
|     (business-to-business), a *force majeure* clause will be subject |
|     to UCTA and must be reasonable. Including events that are        |
|     actually within your control in a list of force majeure events   |
|     would be unreasonable.                                           |
|                                                                      |
| ```{=html}                                                           |
| <!-- -->                                                             |
| ```                                                                  |
| 1.  In a consumer contract made on or after 1 October 2015, the CRA  |
|     will apply to a *force majeure* clause. This means that clauses  |
|     must be fair and transparent so don't refer to force majeure     |
|     events but rather to circumstances outside of your control.      |
|                                                                      |
|                                                                      |
|                                                                      |
| **Other considerations**                                             |
|                                                                      |
|                                                                      |
|                                                                      |
| Always review and adapt a *force majeure* clause to fit the          |
| circumstances of a transaction. Consider the following:              |
|                                                                      |
|                                                                      |
|                                                                      |
| 1.  Should the *force majeure* clause apply to both parties to the   |
|     agreement?                                                       |
|                                                                      |
| ```{=html}                                                           |
| <!-- -->                                                             |
| ```                                                                  |
| 1.  Are there any specific events relevant to the circumstances of   |
|     the transaction which should be set out expressly to avoid any   |
|     future dispute?                                                  |
|                                                                      |
| ```{=html}                                                           |
| <!-- -->                                                             |
| ```                                                                  |
| 1.  What is the effect of the *force majeure* clause? Is it to       |
|     release the parties from their obligations, or suspend those     |
|     obligations? Will one party or both have the right to terminate? |
|                                                                      |
| ```{=html}                                                           |
| <!-- -->                                                             |
| ```                                                                  |
| 1.  Should the party relying on the *force majeure* event have the   |
|     right to determine that such an event has occurred? Or, would it |
|     be appropriate to have an independent determination if, for      |
|     example, the obligations are very technical?                     |
|                                                                      |
| ```{=html}                                                           |
| <!-- -->                                                             |
| ```                                                                  |
| 1.  If the parties disagree on the nature of the event, should       |
|     determination of a *force majeure* event be linked to a dispute  |
|     resolution procedure?                                            |
|                                                                      |
| Depending on the type of arrangement, the supplier may be required   |
| to implement a disaster recovery or business continuity plan. A      |
| *force majeure* clause should not affect the supplier's specific     |
| obligation to provide business continuity and disaster recovery      |
| services.                                                            |
+----------------------------------------------------------------------+

**1.**  **FORCE MAJEURE (LONG FORM -- suitable for more complex
arrangements, scroll down for a clause to insert in more simple
contracts)**

 

**1.1**  **Force Majeure Event** means any circumstance not within a
party's reasonable control including, without *limitation:*

 

**(a)**  acts of God, flood, drought, earthquake or other natural
disaster;

**(b)**  epidemic or pandemic;

 

 

+----------------------------------------------------------------------+
| **Epidemic or pandemic**                                             |
|                                                                      |
|                                                                      |
|                                                                      |
| According to the Oxford English Dictionary, an epidemic is a         |
| widespread local outbreak of infectious disease; a pandemic is a     |
| disease prevalent over a whole country or the world.                 |
+----------------------------------------------------------------------+

**(c)**  terrorist attack, civil war, civil commotion or riots, war,
threat of or preparation for war, armed conflict, imposition of
sanctions, embargo, or breaking off of diplomatic relations;

**(d)**  nuclear, chemical or biological contamination or sonic boom;

**(e)**  any law or any action taken by a government or public
authority, including without limitation imposing an export or import
restriction, quota or prohibition\[, or failing to grant a necessary
licence or consent\];

 **(f)**  collapse of buildings, fire, explosion or accident; \[and\]

**(g)**  \[any labour or trade dispute, strikes, industrial action or
lockouts \[(other than in each case by the party seeking to rely on this
clause, or companies in the same group as that party)\];\]

 

+----------------------------------------------------------------------+
| **Strikes and industrial action (optional clause)**                  |
|                                                                      |
|                                                                      |
|                                                                      |
| Including industrial action as a *force majeure* event is likely to  |
| involve negotiation. This is because there may be an argument        |
| between the parties about whether industrial action by the affected  |
| party's own employees is really beyond its reasonable control. The   |
| additional wording in brackets ensures that industrial action by a   |
| party's own employees would be carved out of the *force majeure*     |
| event. A customer will include the last part of (g) that is in       |
| square brackets and a supplier will remove these words.              |
+----------------------------------------------------------------------+

**(h)**  \[non-performance by suppliers or subcontractors \[(other than
by companies in the same group as the party seeking to rely on this
clause)\]; and\]

 

+----------------------------------------------------------------------+
| **Non-performance by third parties (optional clause)**               |
|                                                                      |
|                                                                      |
|                                                                      |
| Including non-performance by third parties as a *force majeure*      |
| event is likely to involve negotiation. This is because there may be |
| an argument between the parties about whether the non-performance by |
| third parties appointed by the affected party is really beyond its   |
| reasonable control. The additional wording in brackets ensures that  |
| non-performance by group companies would be carved out of the *force |
| majeure* event. A customer will include the last part of (h) that is |
| in square brackets and a supplier will remove these words.           |
+----------------------------------------------------------------------+

**(i)**  interruption or failure of utility service.

**1.2**  Provided it has complied with clause 1.4 if a party is
prevented, hindered or delayed in or from performing any of its
obligations under this agreement by a Force Majeure Event (**Affected
Party**), the Affected Party shall not be in breach of this agreement or
otherwise liable for any such failure or delay in the performance of
such obligations. The time for performance of such obligations shall be
extended accordingly.

 

 

+----------------------------------------------------------------------+
| **Relying on force majeure**                                         |
|                                                                      |
|                                                                      |
|                                                                      |
| The words used here are "prevent", "hinder" and "delay", to ensure   |
| that the triggers are sufficiently wide:                             |
|                                                                      |
|                                                                      |
|                                                                      |
| 1.  **"Prevent"**. To prove that an event "prevents" performance,    |
|     the party relying on the clause must demonstrate that            |
|     performance is legally or physically impossible, not just        |
|     difficult or unprofitable.                                       |
|                                                                      |
| ```{=html}                                                           |
| <!-- -->                                                             |
| ```                                                                  |
| 1.  **"Hinder" and "delay"**. These words have a wider scope and     |
|     will generally be satisfied if performance has been made         |
|     substantially more onerous. A mere increase in the cost of       |
|     performing the contract, however, would still be unlikely to be  |
|     enough to qualify.                                               |
+----------------------------------------------------------------------+

**1.3**  \[The corresponding obligations of the other party will be
suspended, and its time for performance of such obligations extended, to
the same extent as those of the Affected Party.\]

**1.4**  The Affected Party shall:

 

**(a)**  as soon as reasonably practicable after the start of the Force
Majeure Event\[ but no later than \[**INSERT NUMBER**\] days from its
start\], notify the other party \[in writing\] of the Force Majeure
Event, the date on which it started, its likely or potential duration,
and the effect of the Force Majeure Event on its ability to perform any
of its obligations under the agreement; and

 

 

+----------------------------------------------------------------------+
| **Written notice and duty to mitigate**                              |
|                                                                      |
|                                                                      |
|                                                                      |
| This clause 1.4 requires the affected party to give (written) notice |
| to the other, and to mitigate the results of the event, before it    |
| can rely on clause 1.2. It is therefore a condition for the affected |
| party to comply with before it can rely on the force majeure         |
| provision. If the affected party ceases in its reasonable efforts to |
| mitigate the results, its performance obligations could revive.      |
+----------------------------------------------------------------------+

**(b)**  use all reasonable endeavours to mitigate the effect of the
Force Majeure Event on the performance of its obligations.

 

 

+----------------------------------------------------------------------+
| **Implied duty to mitigate**                                         |
|                                                                      |
|                                                                      |
|                                                                      |
| The obligation to mitigate the effects of the *force majeure* event  |
| may be implied. The Court of Appeal has said that any clause which   |
| included language referring to events "beyond the control of the     |
| relevant party" could only be relied on if that party had taken all  |
| reasonable steps to avoid its operation or mitigate its results.     |
|                                                                      |
|                                                                      |
|                                                                      |
| Nevertheless, this clause expressly imposes on the affected party an |
| express duty to mitigate the effects of the *force majeure* event to |
| avoid any doubt.                                                     |
+----------------------------------------------------------------------+

**1.5**  If the Force Majeure Event prevents, hinders or delays the
Affected Party's performance of its obligations for a continuous period
of more than \[**INSERT NUMBER**\] \[weeks\], the party not affected by
the Force Majeure Event may terminate this agreement by giving
\[**INSERT NUMBER**\] \[weeks'\] written notice to the Affected Party.

 

 

+----------------------------------------------------------------------+
| **Termination right**                                                |
|                                                                      |
|                                                                      |
|                                                                      |
| Under clause 1.5, the unaffected party has the right to serve notice |
| terminating the agreement after a specified period of                |
| non-performance by the affected party due to the force majeure       |
| event.                                                               |
|                                                                      |
|                                                                      |
|                                                                      |
| Consider how long the period of suspension should last before the    |
| right to terminate arises. There is no hard and fast rule, and much  |
| will depend on the nature of the arrangement and affected            |
| obligation. Should a termination right be a last resort?             |
+----------------------------------------------------------------------+

**2.**  **FORCE MAJEURE (SHORT FORM -- suitable for more simple
arrangements)**

 

 

Neither party shall be in breach of this agreement nor liable for delay
in performing, or failure to perform, any of its obligations under this
agreement if such delay or failure result from events, circumstances or
causes beyond its reasonable control. In such circumstances \[the time
for performance shall be extended by a period equivalent to the period
during which performance of the obligation has been delayed or failed to
be performed **OR** the affected party shall be entitled to a reasonable
extension of the time for performing such obligations\]. If the period
of delay or non-performance continues for \[**INSERT NUMBER**\] \[weeks
**OR** months\], the party not affected may terminate this agreement by
giving \[**INSERT NUMBER**\] \[days'\] written notice to the affected
party.

 

**TERMINATION CLAUSES**

**1.**  **TERMINATION**  

**1.1**  Without affecting any other right or remedy available to it,
either party may terminate this agreement with immediate effect by
giving \[written\] notice to the other party if:

**(a)**  \[the other party fails to pay any amount due under this
agreement on the due date for payment and remains in default not less
than \[**INSERT NUMBER**\] days after being notified \[in writing\] to
make such payment;\] **\[DELETE THIS IF YOU ARE THE CUSTOMER/CLIENT AND
RETAIN IF YOU ARE THE SUPPLIER\]**

**(b)**  the other party commits a material breach of any term of this
agreement which breach is irremediable or (if such breach is remediable)
fails to remedy that breach within a period of \[**INSERT NUMBER EG
7**\] days after being notified \[in writing\] to do so;

 

**(c)**  \[the other party repeatedly breaches any of the terms of this
agreement in such a manner as to reasonably justify the opinion that its
conduct is inconsistent with it having the intention or ability to give
effect to the terms of this agreement;\]

**(d)**  the other party suspends, or threatens to suspend, payment of
its debts or is unable to pay its debts as they fall due or admits
inability to pay its debts or \[(being a company or limited liability
partnership) is deemed unable to pay its debts within the meaning of
section 123 of the Insolvency Act 1986 (**IA 1986**) as if the words "it
is proved to the satisfaction of the court" did not appear in sections
123(1)(e) or 123(2) of the IA 1986\] **OR** \[(being an individual) is
deemed either unable to pay its debts or as having no reasonable
prospect of so doing, in either case, within the meaning of section 268
of the IA 1986\] **OR** \[(being a partnership) has any partner to whom
any of the foregoing apply\];

 

**(e)**  The other party commences negotiations with all or any class of
its creditors with a view to rescheduling any of its debts, or makes a
proposal for or enters into any compromise or arrangement with any of
its creditors \[other than (being a company) for the sole purpose of a
scheme for a solvent amalgamation of that other party with one or more
other companies or the solvent reconstruction of that other party\];

 

**(f)**  a petition is filed, a notice is given, a resolution is passed,
or an order is made, for or in connection with the winding up of the
other party (being a company, limited liability partnership or
partnership) \[other than for the sole purpose of a scheme for a solvent
amalgamation of that other party with one or more other companies or the
solvent reconstruction of that other party\];

 

**(g)**  an application is made to court, or an order is made, for the
appointment of an administrator, or a notice of intention to appoint an
administrator is given or an administrator is appointed, over the other
party (being a company);

**(h)**  the holder of a qualifying floating charge over the assets of
that other party (being a company) has become entitled to appoint or has
appointed an administrative receiver;

**(i)**  a person becomes entitled to appoint a receiver over all or any
of the assets of the other party or a receiver is appointed over all or
any of the assets of the other party;

**(j)**  \[the other party (being an individual) is the subject of a
bankruptcy petition, application or order;\]

**(k)**  a creditor or encumbrancer of the other party attaches or takes
possession of, or a distress, execution, sequestration or other such
process is levied or enforced on or sued against, the whole or any part
of the other party's assets and such attachment or process is not
discharged within \[14\] days;

**(l)**  any event occurs, or proceeding is taken, with respect to the
other party in any jurisdiction to which it is subject that has an
effect equivalent or similar to any of the events mentioned in clauses
(d) to (k) above (inclusive);

 

**(m)**  the other party suspends or ceases, or threatens to suspend or
cease, carrying on all or a substantial part of its business; \[or\]

**(n)**  \[the other party (being an individual) dies or, by reason of
illness or incapacity (whether mental or physical), is incapable of
managing their own affairs or becomes a patient under any mental health
legislation\[; or\]\]

**(o)**  \[there is a change of control of the other party\[ (within the
meaning of section 1124 of the Corporation Tax Act 2010)\]\[; or\]\]

**(p)**  \[any warranty given by the other party in clause \[NUMBER\] of
this agreement is found to be untrue or misleading.\]

**1.2**  For the purposes of this clause **material breach** means a
breach (including an anticipatory breach) that is serious in the widest
sense of having a serious effect on the benefit which the terminating
party would otherwise derive from:

**(a)**  a substantial portion of this agreement; or

**(b)**  any of the obligations set out in clauses \[NUMBERS\],

over \[the term of this agreement **OR** any \[NUMBER\]-month period
during the term of this agreement\]. In deciding whether any breach is
material no regard shall be had to whether it occurs by some accident,
mishap, mistake or misunderstanding.\]

**1.3**  Without affecting any other right or remedy available to it,
\[either party **OR** \[Party 1\]\] may terminate this agreement on
giving not less than \[NUMBER\] months' \[written\] notice to the
\[other party **OR** \[Party 2\]\].
