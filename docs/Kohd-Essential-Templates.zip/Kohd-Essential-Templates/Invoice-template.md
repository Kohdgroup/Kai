**© Kohd Group Limited 2026. These templates are covered under Kohd Group Limited's workshop license and may be used internally for the purposes authorized. Based on original work by Suzanne Dibble.**

**\[INSERT YOUR ADDRESS\]**

**\[INSERT YOUR VAT registration number\]**

Invoice Date: **\[INSERT DATE\]**

Invoice No: **\[INSERT NUMBER\]**

To: **\[INSERT NAME OF PERSON/COMPANY BEING INVOICED\]**

**\[INSERT ADDRESS\]**

+----------------+----------------+----------------+----------------+
| **Details**    | **Fees**       | **VAT**        | **Total**      |
+----------------+----------------+----------------+----------------+
| **\[INSERT     | £\[INSERT      | £\[INSERT      | []{.underline} |
| DESCRIPTION OF | AMOUNT\]       | AMOUNT OF      |                |
| PRODUC         |                | VAT\]          | []{.underline} |
| T/SERVICES\]** |                |                |                |
|                |                |                | []{.underline} |
| **Total Due**  |                |                |                |
|                |                |                | []{.underline} |
|                |                |                |                |
|                |                |                | []{.underline} |
|                |                |                |                |
|                |                |                | **[£\[INSERT   |
|                |                |                | TOTAL\]]       |
|                |                |                | {.underline}** |
|                |                |                |                |
|                |                |                | []{.underline} |
+----------------+----------------+----------------+----------------+

[Please quote the invoice number with your payment.]{.underline}

[]{.underline}

This invoice is payable on presentation \[OR within 30 days of the date
of this invoice\]

Please remit the monies to:

Bank: \[**INSERT NAME OF BANK**\]

Account Name: \[**INSERT ACCOUNT NAME**\]

Sort Code: \[**INSERT SORT CODE**\]

Account No: \[**INSERT ACCOUNT NUMBER**\]

Please make all cheques payable to **\[INSERT NAME**\] and send them to
\[**INSERT ADDRESS**\].

\[\[**INSERT NAME OF COMPANY**\] is a company incorporated in England
and Wales with company registration number \[**INSERT COMPANY NUMBER**\]
and registered office \[**INSERT REGISTERED OFFICE**\] \[**NOTE: DELETE
THIS SECTION IF YOU ARE NOT TRADING THROUGH A LIMITED COMPANY**\]
