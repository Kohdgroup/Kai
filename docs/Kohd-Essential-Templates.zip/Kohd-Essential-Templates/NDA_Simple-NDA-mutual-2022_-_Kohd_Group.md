**[INSERT RECIPIENT NAME AND ADDRESS]**

**[INSERT DATE]**

Dear Tomer

**CONFIDENTIALITY AGREEMENT**

Before we each disclose certain Confidential Information (as defined
below) to the other as part of negotiations about you partnering with
our business ("Purpose"), we would like you to sign and return this
letter to us as evidence of your agreement to the terms and conditions
of this Confidentiality Agreement.

In consideration of each of us disclosing our Confidential Information
to the other, we each agree:

1.  to keep the other party's Confidential Information confidential and not use or exploit such Confidential Information in any way except for the Purpose.
    -------------------------------------------------------------------------------------------------------------------------------------------------------

2.  to not disclose or make available the other party's Confidential Information to any third party, except to (i) your employees, officers, agents and professional advisors who need to know such Confidential Information for the Purpose and who have been informed of the confidential nature of such Confidential Information or (ii) any governmental or other regulatory authority or a court to the extent that such disclosure is required by law and provided that, to the extent legally permissible you provide us with as much notice of such disclosure as possible.
    -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

3.  to not copy, write down or otherwise record the other party's Confidential Information except as strictly necessary for the Purpose.
    ------------------------------------------------------------------------------------------------------------------------------------

4.  that we each are liable for the actions or omissions of those persons that either of us have disclosed the Confidential Information to pursuant to paragraph 2 above.
    ---------------------------------------------------------------------------------------------------------------------------------------------------------------------

5.  at the request of the owner of the Confidential Information, to destroy or return to the owner all documents and materials (and any copies) containing, reflecting, incorporating, or based on such Confidential Information and to erase all such Confidential Information from your computer systems.
    -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

6.  that we each reserve all rights in our respective Confidential Information and that we each make no warranty or representation concerning our respective Confidential Information or the accuracy or completeness of such Confidential Information.
    ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

7.  that the disclosure of our respective Confidential Information does not form any offer by either of us to enter into any further agreement in relation to the Purpose or the development or supply of any product or service to which such Confidential Information relates.
    ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

8.  that damages alone would not be an adequate remedy for the breach of any of the provisions of this agreement and that each of us shall be entitled to the granting of equitable relief (including without limitation injunctive relief) concerning any threatened or actual breach of any of the provisions of this agreement.
    ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

9.  to reimburse to the relevant party on a pound for pound basis (legally known as an indemnity) all liabilities, costs (including legal costs), expenses, damages and losses including any direct, indirect or consequential losses, loss of profit, loss of reputation and all interest, penalties and other costs and expenses suffered or incurred by the relevant party arising from the other party's breach of this agreement or from the actions or omissions of any persons the other party has disclosed the Confidential Information to pursuant to paragraph 2 above.
    ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

10. that either party's failure to exercise, or any delay in exercising, any right or remedy won't constitute a waiver of that or any other right or remedy, nor preclude or restrict any further exercise of that or any other right or remedy.
    --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

11. that neither of us may assign, sub-contract or deal in any way with,
    any of our respective rights or obligations under this agreement.

12. that this agreement is not intended to benefit, or be enforceable by, anyone else other than us and you.
    --------------------------------------------------------------------------------------------------------

13. that no variation of this agreement will be effective unless it is in writing and signed by each of us.
    -------------------------------------------------------------------------------------------------------

14. that this agreement and any dispute or claim arising out of or in connection with it or its subject matter or formation (including non-contractual disputes or claims) shall be governed by and construed in accordance with the law of England and Wales.
    ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

15. that we each irrevocably agree that the courts of England and Wales shall have exclusive jurisdiction to settle any dispute or claim that arises out of or in connection with this agreement or its subject matter or formation (including non-contractual disputes or claims).
    -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

16. that "Confidential Information" where used in this agreement shall have the following meaning:
    ----------------------------------------------------------------------------------------------

**Confidential Information:** all information (however recorded or preserved and whether in whole or in part) disclosed or made available, directly or indirectly, by either party or such party's employees, officers, representatives or advisers to the other party (or to the other party's employees, officers, representatives or advisers) including but not limited to: {#confidential-information-all-information-however-recorded-or-preserved-and-whether-in-whole-or-in-part-disclosed-or-made-available-directly-or-indirectly-by-either-party-or-such-partys-employees-officers-representatives-or-advisers-to-the-other-party-or-to-the-other-partys-employees-officers-representatives-or-advisers-including-but-not-limited-to .list-paragraph}
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

a.  ### the fact that discussions and negotiations are taking place concerning the Purpose and the status of those discussions and negotiations;

b.  ### any information that would be regarded as confidential by a reasonable business person relating to: 

    i.  #### either party's business, affairs, customers, clients, suppliers, plans, intentions, or market opportunities, and

    ii. #### either party's operations, processes, product information, know-how, designs, trade secrets or software;

c.  ### any information or analysis derived from the Confidential Information; 

but not including any information that:

d.  ### is or becomes generally available to the public (other than as a result of its disclosure by the receiving party or its employees, officers, representatives or advisers) except that any compilation of otherwise public information in a form not publicly known shall nevertheless be treated as Confidential Information; or

e.  ### was lawfully in the receiving party's possession before the information was disclosed by the disclosing party, as evidenced by written records; or

f.  ### we each agree in writing is not confidential or may be disclosed.

Please sign where indicated below to confirm your acknowledgement of and
acceptance of the terms and conditions of this agreement.

Yours sincerely

![](media/image1.png){width="1.0763888888888888in"
height="0.4583333333333333in"}

NEIL RILEY ON BEHALF OF KOHD GROUP LIMITED

I/we hereby agree to the terms and conditions of this agreement:

..................................................................................................

**Mr Tomer Mann**

Dated
.......................................................................

  -- --
     
     
  -- --
