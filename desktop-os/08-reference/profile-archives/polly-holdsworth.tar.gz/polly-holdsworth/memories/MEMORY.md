KOHD Multi-Node Dispatch: 60.10 (Rai dispatcher + kanban.db) + nodes 01-09 (profiles: mai-architect, laura-orchestrator, kai-validator, quinn-support, amelia-comms). Kanban spawns named actors, posts results as OAuth identity. Native v0.18.0 only.
§
USER: Cost-conscious, rapid decision cycles, emphatic about APIs ("REMEMBER THIS"), demands REAL data before design (queries Linear GraphQL directly). VP-level operator building autonomous 24/7 production systems (80% hands-off). Rejects speculation; expects direct answers. Values IP protection + reusable patterns (Node-RED flows, GHL snapshots). Work style: native Hermes v0.18.0 only, no custom workarounds.
§
KANBAN HEARTBEAT: Workers call kanban_heartbeat() hourly (optional note). Dispatcher auto-reclaims >4h stale with no heartbeat in last 1h. Task back to ready, progress lost. Native v0.18.0.
§
LINEAR API TOKEN: lin_api_7XIXcPMdMhxCAy9gvdqXhuSFSNEEZ5TgWYp8Ppjc. User emphatic: use this for all workspace queries. HARD BLOCKER: 1 Linear license on Enterprise plan; Rai reads/updates, profiles execute via Hermes kanban only (no Linear seats). Kanban assignee field is native (profile name). Never mutate Linear assignee field; leave unassigned or shared team account only.
§
ECOPUK QUOTE WORKFLOW: 5-phase flow (Quote via DHL → Acceptance chasing → 2-hr slots LOCKED → Execution → Invoice). Node-RED DHL webhook → GHL Estimate (2-line: product + shipping margin 30%) → PATCH EST custom field. See skill:go-high-level§ghl-shipping-quote-workflow.md. Critical: EST field key must be verified in GHL Admin (not UI label).
§
ECOPUK QUOTE: GHL env var ghl_ecopuk_key (token), locationId=cCqp6W8M6Bb4BBQjE9XS. FlowFuse Node-RED use env.get() not process.env. Product: IHS-SignPlate £62.94 (0.3kg/unit), shipping margin +30%. Estimate: 2 lines (product+qty, shipping total). contactDetails needs name/email/phoneNo; businessDetails required; frequencySettings="one-time". All money: parseFloat(toFixed(2)). EST custom field = estimate ref number.
§
User treats Aardvark and EcoPUK as separate projects; for Aardvark, prefer business-centric, presentation-ready flowcharts/PDFs.