User has Linear OAuth actor labels: Laura Bennett, Maya Khan, Quinn Graham, Thomas Advani, Amelia Cross, Joseph Webb, Eve Sterling, Rai Matsuda, Kai Matsuda, and Mai Matsuda; do not store or repeat their secrets/tokens.
§
For Linear actor-mode comments, use the appropriate human worker for the workstream rather than a fixed default.
§
Linear actor mapping: Mai=platform/admin/integrations; Kai=pre-prod/validation; Rai=production/incidents.
§
For Linear actor-mode comments and ownership, use the relevant OAuth human/app identity; do not use the personal API-key identity.
§
KOHD FINAL (2026-07-03): Linear=intake only (Rai reads/updates, 1 seat). Kanban.db (60.10, NFS→nodes 01-09)=true dispatch. Profiles execute via Kanban(NO Linear seats). Enterprise blocker resolved: assignee field=1 seat each, so Kanban assignment replaces Linear. Rai polls Linear 1min→creates kanban task→dispatch→completion→updates Linear.
USER STYLE: Demands native verification before design. Rejects speculation. Values direct 'no context' over guesses. Decisive pivots. Cost-conscious (rejected 80-seat model instantly).
§
User prefers direct, verification-first answers; Aardvark flowcharts should stay business-facing with optional click-to-reveal technical detail, clear legends, and generous padding.