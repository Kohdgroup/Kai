---
name: flowfuse
description: Use when a project depends on FlowFuse for Node-RED style flows, edge automations, deployed flows, or reusable integration logic. Standardize the workspace, deployment path, and validation loop so future projects can reuse the same pattern.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [flowfuse, node-red, flows, automation, edge, integration, reusable]
    related_skills: [adf-platform-dependency-framework, linear-native-operating-model, linear-accurate-updates]
---

# FlowFuse

## Overview

Use this skill when a project depends on FlowFuse for deployed flows, Node-RED style automations, edge logic, or reusable integration pipelines.

The goal is to make FlowFuse predictable as a platform dependency: know what instance is in use, what flows are deployed, what environment they live in, and how the flow is validated before it is considered ready.

## When to Use

- The project uses FlowFuse to host or deploy flows
- You need to manage Node-RED style automation logic as a reusable platform component
- A project needs an edge or integration runtime that should be standardized across future work
- You need a repeatable framework for deployed flows, not a one-off flow edit

## Workflow

### 1) Identify the FlowFuse role in the project
Classify FlowFuse before writing or changing anything:

- **Runtime / deployment layer** — hosts deployed flows
- **Automation layer** — executes integrations, transforms, or event handling
- **Edge layer** — runs local / edge-connected logic
- **Reporting / observability layer** — surfaces runtime state or flow health

### 2) Record the minimum reusable inputs
Capture the workspace details that future projects need:

- FlowFuse instance / workspace name
- Node-RED project or flow set name
- target environment (dev / test / prod)
- deployment owner
- trigger source
- downstream system(s) touched by the flow

### 3) Validate the flow lifecycle
A FlowFuse setup is only useful if the lifecycle is visible:

- confirm the correct flow is selected
- deploy the flow to the intended environment
- validate the trigger fires
- confirm the downstream effect or output
- confirm the deployment state is what you expect

### 4) Keep Linear current
Use Linear to capture:

- what FlowFuse is responsible for
- what flow is deployed
- what environment is active
- what validation was run
- what remains blocked

## Pitfalls

- Do not confuse a saved flow with a deployed flow.
- Do not let environment drift go unrecorded.
- Do not assume Node-RED conventions are identical across all FlowFuse deployments.
- Do not mark the platform ready without validating the runtime path.

## Verification Checklist

- [ ] FlowFuse’s role is classified
- [ ] Workspace and environment are identified
- [ ] The deployed flow set is known
- [ ] A trigger-to-output validation was completed
- [ ] The current state was written back into Linear
