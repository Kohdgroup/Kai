# Linear MCP connection notes

Use Linear as an MCP server in Hermes.

## Connection

```bash
hermes mcp add linear --url https://mcp.linear.app/sse
hermes mcp configure linear
```

## Authentication

- The docs expose `LINEAR_API_KEY` as the relevant environment variable for Linear API-key-based access.
- For MCP usage, the server URL is `https://mcp.linear.app/sse`.

## Practical note

If the user asks how to "connect to Linear," prefer the MCP path first, then mention the API key only if they need direct token-based access.
