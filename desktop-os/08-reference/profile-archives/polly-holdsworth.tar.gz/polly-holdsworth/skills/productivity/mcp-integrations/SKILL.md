---
name: mcp-integrations
description: "Connect Hermes to external SaaS tools and hosted services via MCP and related auth flows."
version: 1.0.0
author: Hermes Agent + Nous Research
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [mcp, integrations, oauth, linear, jira, asana, github, external-tools]
---

# MCP Integrations

Use this skill when the task is to connect Hermes to an external service through Model Context Protocol (MCP), especially hosted SaaS tools that expose a remote MCP endpoint and require OAuth or API-key-backed access.

## When to Use

- The user asks how to connect Hermes to Linear, Sentry, Atlassian, Asana, Figma, or similar hosted tools.
- A service provides an MCP URL and Hermes should discover tools from it.
- The task is to add, configure, test, or update an MCP server in Hermes.
- The user is unsure whether they need an MCP server or a direct API key.

## Core Rule

Prefer MCP first when a service offers it. Only fall back to direct API-key usage when the user explicitly needs non-MCP access or the service does not expose MCP.

## Standard Workflow

1. Identify the service name and whether it has a hosted MCP endpoint.
2. Add the server with `hermes mcp add <name> --url <endpoint>`.
3. Configure tool selection with `hermes mcp configure <name>`.
4. If the service also supports direct API access, document the relevant env var separately.
5. Verify with `hermes mcp list` or `hermes mcp test <name>` when available.

## Common Linear Pattern

- Linear’s hosted MCP endpoint is typically used for Hermes integration.
- After adding it, run the configure step so Hermes exposes the right tools.
- If the user only needs token-based access, note the `LINEAR_API_KEY` env var.

## Pitfalls

- Don’t assume “connect to X” means API key only; many SaaS services are better integrated through MCP.
- Don’t stop after adding the server if tool selection is required; configuration is part of the connection.
- Don’t confuse remote OAuth/MCP setup with local plugin installation.

## Verification

- The service appears in `hermes mcp list`.
- Hermes can configure the server without errors.
- The expected service tools show up in the tool-selection UI or configuration.

## Reference Notes

- See `references/linear-mcp.md` for the Linear-specific connection pattern.
