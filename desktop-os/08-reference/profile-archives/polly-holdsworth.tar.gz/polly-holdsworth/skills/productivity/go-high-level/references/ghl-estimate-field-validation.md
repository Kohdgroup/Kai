# GHL Estimate v3 API Field Validation & Schema

**Source**: https://marketplace.gohighlevel.com/docs/ghl/invoices/create-new-estimate  
**Endpoint**: `POST https://services.leadconnectorhq.com/invoices/estimate`  
**Version**: v3  
**Last Verified**: 2026-07-03

## Critical Pitfalls (Resolved via User Correction)

### Marketplace Example vs. Actual API
**Problem**: GHL marketplace provides curl example showing `businessDetails.address` as a STRING:
```json
"businessDetails": {
  "address": "9931 Beechwood, TX"
}
```

**Reality**: The actual API v3 spec requires `address` as an OBJECT:
```json
"businessDetails": {
  "address": {
    "addressLine1": "9931 Beechwood",
    "city": "Houston",
    "state": "TX",
    "countryCode": "US",
    "postalCode": "12345"
  }
}
```

**Fix**: Always check the actual schema docs, not just the example. When stuck on 422 errors, load the spec directly from https://marketplace.gohighlevel.com/docs/ghl/invoices/create-new-estimate and verify field structure.

### Phone Format
- **Required**: E.164 international format, NO SPACES
- **Correct**: `+441234567890`
- **Wrong**: `+44 1234 567890` (causes validation error)
- **Implementation**: `.replace(/\s/g, "")` to strip spaces

### Currency Amounts
- **Required**: Exactly 2 decimal places
- **Correct**: `parseFloat((62.94).toFixed(2))`, `parseFloat(quote.totalWithMargin.toFixed(2))`
- **Wrong**: `62.9` or `62.900`

## Mandatory Fields (Must All Be Present)

| Field | Type | Notes |
|-------|------|-----|
| `altId` | string | Location or Agency ID |
| `altType` | string | Value: `"location"` |
| `name` | string | Estimate name (e.g., "EST-{opportunityId}") |
| `currency` | string | Code, e.g., "GBP" |
| `businessDetails` | object | See structure below |
| `items` | array | At least 1 item required |
| `discount` | object | Can be `{type: "percentage", value: 0}` |
| `frequencySettings` | object | For one-time: use `{}` or `{enabled: false}` |

## businessDetails Structure (REQUIRED = OBJECT)

```json
"businessDetails": {
  "name": "string",
  "phoneNo": "+E.164format",
  "address": {
    "addressLine1": "string",
    "addressLine2": "string (optional)",
    "city": "string",
    "state": "string",
    "countryCode": "string (2-char, e.g., GB, US)",
    "postalCode": "string"
  },
  "website": "string (optional)"
}
```

## contactDetails Structure

```json
"contactDetails": {
  "id": "string (required)",
  "name": "string",
  "email": "string",
  "phoneNo": "+E.164format",
  "address": {
    "addressLine1": "string (optional)",
    "city": "string (optional)",
    "countryCode": "string (optional)"
  }
}
```

## Items Array

```json
"items": [
  {
    "name": "string",
    "description": "string (optional)",
    "productId": "string",
    "priceId": "string",
    "currency": "string",
    "amount": 99.99,
    "qty": 1,
    "taxInclusive": true,
    "type": "one_time"
  }
]
```

## Common 422 Validation Errors & Fixes

| Error | Root Cause | Fix |
|-------|-----------|-----|
| `businessDetails should not be empty` | `businessDetails` missing or null | Include full object with name, address, phoneNo |
| `businessDetails.address.each value...must be either object or array` | `address` is a string instead of object | Change to nested object: `{addressLine1: "...", city: "...", ...}` |
| `frequencySettings should not be empty` | `frequencySettings` missing | Set to `{}` for one-time |
| `items.1.amount must be upto 2 decimal` | Amount like `232.100` or `62.9` | Use `parseFloat(val.toFixed(2))` |
| `contactDetails.phoneNo must be in E.164 format` | Spaces or + prefix inconsistent | Use `"+441234567890"` (no spaces, leading +) |
| `contactDetails.email should not be empty` | Email extraction failed | Check multiple payload paths: `payload.email` → `payload.customData.email` → `payload.user.email` |

## Email Extraction Pattern

```javascript
const contactEmail = payload.email 
  || payload.customData?.email 
  || payload.user?.email 
  || payload.contact?.email 
  || "fallback@ecopuk.com";
```

## Working Example (EcoPUK IHS Quote → Estimate)

**Items**: 2-line estimate (product + logistics)
- IHS - Sign Plate: £62.94 × qty
- Customs & Logistics: £{calculated_with_margin} × 1

**businessDetails**: EcoPUK location info  
**contactDetails**: Customer contact from GHL webhook  
**frequencySettings**: `{}` (one-time)  
**Dates**: issueDate = today, expiryDate = today + 30 days  

See `ghl-shipping-quote-workflow.md` for the complete Node-RED + DHL → GHL flow template.

## Key Learnings

1. **Always request live examples**: Documentation examples can mislead. Ask the user for a working curl example + response before writing code.
2. **Verify against actual spec**, not marketplace docs. The API spec on https://marketplace.gohighlevel.com/docs/ is authoritative; examples may lag.
3. **422 errors = schema mismatch**: When validation fails, load this file and check the field matrix (section: Common 422 Validation Errors) before iterating blind.
4. **Correction = Workflow Signal**: When a user says "did you check before you gave me that?", it means the next session needs a verification step. Embed it in the skill as a pitfall/comment.
