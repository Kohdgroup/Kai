# GHL Estimate Workflow Notes

## Create Estimate (v3)
- Endpoint: `POST https://services.leadconnectorhq.com/invoices/estimate`
- Required header: `Version: v3`
- Required top-level fields observed in docs/validation: `altId`, `altType`, `name`, `businessDetails`, `currency`, `items`, `discount`, `frequencySettings`
- `liveMode: true` is also expected in working requests.

### Business details shape
```json
{
  "name": "EcoPUK",
  "phoneNo": "+441253734733",
  "address": {
    "addressLine1": "The Enterprise Centre",
    "addressLine2": "291-305 Lytham Rd",
    "city": "Blackpool",
    "state": "Lancashire",
    "countryCode": "GB",
    "postalCode": "FY4 1EW"
  },
  "website": "https://ecopuk.com"
}
```
- `businessDetails.address` is an **object**, not a string.

### Contact details shape
- `contactDetails.id`, `name`, `email`, `phoneNo` were required by validation.
- `phoneNo` must be E.164 (`+1234567890` style) with no spaces or masks.

### Items shape
- Use product-linked items when possible:
  - `productId`
  - `priceId`
  - `name`
  - `description`
  - `currency`
  - `amount`
  - `qty`
  - `taxInclusive: true`
  - `type: "one_time"`

### Frequency settings
- Empty `{}` was rejected.
- Working minimal shape used in-session:
```json
{
  "enabled": false,
  "schedule": { "executeAt": "2026-07-03" }
}
```
- If validation changes, expand this first before changing unrelated fields.

### Create response shape
- The estimate identifier needed for sending was `msg.payload._id`.
- `estimateNumber` is a separate human-visible reference.
- Do **not** use `estimateNumber` as the send URL id.

### Send Estimate
- Endpoint: `POST https://services.leadconnectorhq.com/invoices/estimate/:estimateId/send`
- Required header: `Version: v3`
- Required body fields observed:
  - `altId`
  - `altType`
  - `action`
  - `liveMode`
  - `userId`
  - `sentFrom`
- `estimateName` is optional but useful.
- `estimateId` must come from create response `_id`.

### Practical workflow
1. Build estimate payload.
2. POST create estimate.
3. Extract `msg.payload._id` -> `msg.estimateId`.
4. POST send to `/invoices/estimate/${msg.estimateId}/send`.
5. PATCH the Opportunity EST field with `estimateNumber`.

### Pitfalls
- Do not send the masked placeholder phone; normalize to real E.164.
- Do not put pricing breakdown in terms notes if the user asked for a clean customer-facing note.
- Do not assume `estimateId === estimateNumber`.
- If `frequencySettings` 422s, test a minimal non-empty object before changing other fields.
- Use `payload.opportunityName` and `payload.customData.delivery_address` when the upstream webhook provides them.
