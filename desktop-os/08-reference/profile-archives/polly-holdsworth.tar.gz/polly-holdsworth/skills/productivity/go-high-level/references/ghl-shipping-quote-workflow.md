# GHL Shipping Quote Workflow (DHL + Node-RED + GHL Estimates)

## Context
When a quote request arrives in GHL (via webhook), calculate shipping costs from an external provider (e.g., DHL), create a multi-line estimate in GHL, and link it back to the Opportunity via a custom field.

## Payload Structures

### GHL Opportunity Webhook (Inbound)
```json
{
  "contact_id": "29BWcuEhzvl8MGjSPJav",
  "first_name": "Neil",
  "email": "neil.riley@kohd.ai",
  "customData": {
    "qty": "26",
    "delivery_address": "SS14-10 & SS14-12, Level 14, Stellar Suites, Jalan Puteri 4/7, Bandar Puteri, 47100 Puchong, Selangor Malaysia",
    "contact.id": "29BWcuEhzvl8MGjSPJav",
    "opportunity.id": "bFFVBVJM3N0stVaELUqN",
    "opportunity.name": "Neil Riley - dev001"
  },
  "id": "bFFVBVJM3N0stVaELUqN",
  "workflow": {
    "id": "b30e7644-0355-4755-8f57-6b29481a3321",
    "name": "22M-IHS - Quote - PPD"
  }
}
```

### DHL Shipping Quote Response (from DHL API)
```json
{
  "opportunityId": "bFFVBVJM3N0stVaELUqN",
  "shippingCost": 232.10,
  "shippingCostBase": 178.54,
  "shippingMargin": 53.56,
  "chargeableWeight": 7.8,
  "estimatedDeliveryDate": "5 July",
  "transitDays": 2,
  "incoterms": "DDP",
  "currency": "GBP",
  "qty": "26",
  "charges": {
    "baseCharge": 85.50,
    "dutiesAndTaxes": 16.89,
    "goGreenPlusCarbonReduced": 0.07,
    "fuelSurcharge": 26.08,
    "shipmentInsurance": 33.77,
    "subtotal": 162.31,
    "tax": 16.23
  }
}
```

### GHL Estimate POST Request (to `/invoices/estimate`)
```json
{
  "altId": "cCqp6W8M6Bb4BBQjE9XS",
  "altType": "location",
  "name": "Shipping Estimate - bFFVBVJM3N0stVaELUqN",
  "title": "ESTIMATE",
  "currency": "GBP",
  "liveMode": true,
  "issueDate": "2026-07-03",
  "expiryDate": "2026-08-02",
  "contactDetails": { "id": "29BWcuEhzvl8MGjSPJav" },
  "items": [
    {
      "name": "IHS - Sign Plate",
      "currency": "GBP",
      "amount": 62.94,
      "qty": 26
    },
    {
      "name": "DHL Express Worldwide Shipping",
      "currency": "GBP",
      "amount": 232.10,
      "qty": 1
    }
  ],
  "discount": { "type": "percentage", "value": 0 },
  "termsNotes": "DHL EXPRESS WORLDWIDE — 22M-IHS - Quote - PPD (bFFVBVJM3N0stVaELUqN)\nBase £85.50 | Fuel £26.08 | Insurance £33.77 | Duties £16.89\n..."
}
```

### GHL Estimate POST Response (201 Created)
```json
{
  "success": true,
  "data": {
    "id": "est_ABC123XYZ",
    "estimateNumber": "EST-001421",
    "total": 1868.54,
    "estimatedSentDate": "2026-07-03T14:22:05Z",
    "status": "draft"
  }
}
```

### GHL Opportunity PATCH Request (Update EST Custom Field)
```http
PATCH https://services.leadconnectorhq.com/opportunities/bFFVBVJM3N0stVaELUqN
Authorization: Bearer <GHL_PIT_TOKEN>
Content-Type: application/json

{
  "customFields": [
    {
      "key": "EST",
      "value": "EST-001421"
    }
  ]
}
```

## Node-RED Flow Pattern

### Key Nodes (Sequence)

1. **HTTP IN** → `/dhl/quote` (POST)
   - Receives GHL webhook

2. **Normalize Payload**
   - Safe extraction: `msg.payload.qty ?? msg.payload.customData.qty`
   - Fallbacks for: `contact_id`, `opportunity_id`, `opportunity_name`, `delivery_address`

3. **Calculate Weight** (Product → Shipment)
   - Qty × unit_weight = chargeable_weight

4. **Build DHL Request**
   - Parses delivery address (string → {city, postalCode, countryCode})
   - Constructs shipment details, origin, destination

5. **Pricing Lookup** (DHL Rates or Internal Table)
   - Chargeable weight → tier lookup
   - Apply charges: base + fuel % + insurance % + duties % + tax %

6. **Apply Margin** (30% on shipping)
   - `final_price = (dhl_total) × 1.30`

7. **Build GHL Estimate Request**
   - 2-line items: product + shipping
   - Extract: `estimateNumber` from response
   - Construct: termsNotes (charge breakdown)

8. **HTTP Request** → `/invoices/estimate`
   - Method: POST
   - Auth: `Bearer <GHL_PIT_TOKEN>`
   - Response: HTTP 201 with estimate data

9. **Update Opportunity Custom Field**
   - Method: PATCH
   - URL: `/opportunities/{opportunityId}`
   - Body: `{ "customFields": [{ "key": "EST", "value": estimateNumber }] }`

10. **HTTP Response** → Webhook source
    - Return 200 with quote summary

## Critical Setup

- **GHL_PIT** env var = Active Private Integration Token (rotated)
- **GHL_LOCATION_ID** = Sub-account / location ID
- **EST custom field key** = Verify in GHL Admin → Opportunities → Custom Fields (not just the UI label)
- **Webhook auth** = Validate GHL webhook token in inbound headers if required

## Common Issues

| Issue | Root Cause | Fix |
|-------|-----------|-----|
| Estimate creation fails (400/422) | Invalid schema, missing `altId`, or missing `contactDetails.id` | Check GHL plan tier; validate all required fields |
| Custom field not updating | Wrong custom field API key (using UI label "EST" instead of actual key) | Get key from GHL Admin, query API docs |
| Webhook payload missing values | GHL sends custom fields in `customData` nested object | Use safe extraction with fallbacks |
| DHL quotes differ between runs | Tiering logic or fuel surcharge % incorrect | Validate pricing tiers against DHL current rates |
| Estimate response missing `estimateNumber` | GHL plan doesn't include Estimates | Confirm Estimates module is enabled in GHL workspace |

## Reusability Notes

This pattern scales to any external quote engine (Shopify, custom API, etc.):
- Replace DHL nodes with API call to your quote provider
- Adjust line items (product name, unit price) to match your offering
- Margin % is configurable (30% used here; adjust as needed)
- Custom field key is parameterizable via env var or config

For EcoPUK: EST field tracks the GHL estimate ID; quotes flow into the `Pricing` stage of the `Sales Pipeline`.
