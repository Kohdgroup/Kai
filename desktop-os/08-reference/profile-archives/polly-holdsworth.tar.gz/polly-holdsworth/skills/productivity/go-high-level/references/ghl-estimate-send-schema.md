# GHL Estimate & Send API Notes (EcoPUK validation)

## Validated create-estimate payload shape
The following fields were required/validated during EcoPUK estimate creation against the GHL v3 invoices endpoint:

- `Version: v3` header is required.
- `altId`, `altType`, `name`, `currency`, `businessDetails`, `items`, `discount`, `frequencySettings` are required.
- `liveMode`, `contactDetails`, `issueDate`, `expiryDate`, `sentTo`, and `title` should be provided for a complete business workflow.

### Business details
- `businessDetails` is an object.
- `businessDetails.address` is an object with:
  - `addressLine1`
  - `addressLine2`
  - `city`
  - `state`
  - `countryCode`
  - `postalCode`
- `businessDetails.phoneNo` must be E.164.

### Contact details
- `contactDetails.id`, `name`, `email`, `phoneNo` are expected.
- `contactDetails.phoneNo` must be E.164.

### Items
- Each item should include `name`, `description`, `productId`, `priceId`, `currency`, `amount`, `qty`, `taxInclusive`, and `type`.
- Amounts must be rounded to 2 decimals.

### frequencySettings
- Empty object `{}` was rejected in practice.
- A minimal one-time shape that worked was:
  - `enabled: false`
  - `schedule.executeAt: <date>`
- If GHL rejects the minimal form in another workspace, use the nearest documented recurring structure and test again.

## Send-estimate endpoint
- Send endpoint: `POST /invoices/estimate/:estimateId/send`
- Required headers include `Version: v3`.
- Required body fields include `altId`, `altType`, `action`, `liveMode`, `userId`, and `sentFrom`.
- `estimateId` comes from the create response `_id` in this workspace, not `estimateNumber`.
- `userId` must be a valid GHL user ID (or similarly authorized personnel ID in the current sub-account).

## Response mapping
- Create response may include:
  - `_id` = estimate ID used for send endpoint
  - `estimateNumber` = customer-facing estimate number used for Opportunity custom field updates
- Update the Opportunity `EST` custom field with `estimateNumber`, not `_id`.

## Pitfalls
- Do not confuse `estimateId` (`_id`) with `estimateNumber`.
- Do not omit the `Version: v3` header.
- Do not rely on a masked placeholder phone number; normalize to a real E.164 value.
- Do not show pricing in customer-facing Ts&Cs unless the business has explicitly asked for it.
- Preserve delivery address in the line item description when requested, and keep Ts&Cs aligned with the customer-review version.
