---
name: linear-api-integration
description: Query Linear via GraphQL for backlog analysis, bulk extraction, team/project hierarchy, and automation routing decisions.
trigger: |
  You need to query Linear programmatically: pull issues, teams, projects, statuses,
  custom fields, or analyze backlog structure. Or: extract data for reporting,
  automation routing decisions, or system design based on real work patterns.
  Covers: GraphQL queries, team/project hierarchy, pagination, error handling,
  bulk data extraction, parsing complex Linear schemas.
---

# Linear API Integration via GraphQL

**Purpose**: Fetch, analyze, and route based on real Linear backlog data.

## Prerequisites

- Linear API token (generate from workspace settings)
- `requests` library (Python) or `curl` with `jq`
- Familiarity with GraphQL syntax

## Core Workflow

### 1. Connect to Linear GraphQL

```python
import requests
import json

LINEAR_API_KEY = "lin_api_..."  # From workspace settings
LINEAR_GRAPHQL = "https://api.linear.app/graphql"

headers = {
    "Authorization": LINEAR_API_KEY,
    "Content-Type": "application/json"
}

def query_linear(query_string):
    """Execute GraphQL query and return parsed JSON."""
    response = requests.post(
        LINEAR_GRAPHQL,
        json={"query": query_string},
        headers=headers,
        timeout=10
    )
    result = response.json()
    
    if "errors" in result:
        print(f"GraphQL Error: {result['errors'][0]['message']}")
        return None
    
    return result["data"]
```

### 2. Fetch All Issues (Paginated)

```python
def get_all_issues(limit=500):
    """Retrieve all issues with key fields."""
    query = """
    {
      issues(first: """ + str(limit) + """) {
        edges {
          node {
            id
            identifier
            title
            state { name }
            priority
            team { name }
            assignee { name displayName }
            createdAt
            updatedAt
          }
        }
      }
    }
    """
    
    data = query_linear(query)
    if data:
        return data["issues"]["edges"]
    return []
```

### 3. Fetch Issues by Team

```python
def get_team_issues(team_key, limit=500):
    """Get all issues for a specific team (CD, KS, etc)."""
    query = """
    {
      issues(first: """ + str(limit) + """) {
        edges {
          node {
            identifier
            title
            state { name }
            team { key name }
            priority
          }
        }
      }
    }
    """
    
    data = query_linear(query)
    if not data:
        return []
    
    # Filter for team_key
    team_issues = [
        edge["node"]
        for edge in data["issues"]["edges"]
        if edge["node"]["team"]["key"] == team_key
    ]
    return team_issues
```

### 4. Analyze Backlog Structure

```python
from collections import defaultdict

def analyze_backlog(issues):
    """Categorize issues by team, status, and priority."""
    analysis = {
        "by_team": defaultdict(lambda: defaultdict(int)),
        "by_status": defaultdict(int),
        "by_priority": defaultdict(int),
    }
    
    for issue in issues:
        team = issue["team"]["name"]
        status = issue["state"]["name"]
        priority = issue.get("priority", 0)
        
        analysis["by_team"][team][status] += 1
        analysis["by_status"][status] += 1
        analysis["by_priority"][priority] += 1
    
    return analysis
```

## Common Patterns

### Get Custom Fields for an Issue

```python
def get_issue_details(identifier):
    """Fetch issue with custom fields."""
    query = """
    {
      issue(id: "{identifier}") {{
        id
        title
        description
        state {{ name }}
        priority
        estimate
        cycle {{ name }}
        customFieldValues {{
          edges {{
            node {{
              field {{ name }}
              value
            }}
          }}
        }}
      }}
    }
    """
    
    data = query_linear(query.format(identifier=identifier))
    return data.get("issue")
```

### Fetch Projects

```python
def get_projects():
    """List all projects in workspace."""
    query = """
    {
      projects(first: 100) {
        edges {
          node {
            id
            name
            key
            team { name }
          }
        }
      }
    }
    """
    
    data = query_linear(query)
    if data:
        return [edge["node"] for edge in data["projects"]["edges"]]
    return []
```

### Fetch Teams

```python
def get_teams():
    """List all teams."""
    query = """
    {
      teams(first: 50) {
        edges {
          node {
            id
            name
            key
          }
        }
      }
    }
    """
    
    data = query_linear(query)
    if data:
        return [edge["node"] for edge in data["teams"]["edges"]]
    return []
```

## Error Handling

**Common errors:**

| Error | Cause | Fix |
|-------|-------|-----|
| `Argument Validation Error` | Malformed query or invalid field name | Validate field names in Linear schema (use `first:` not `limit:`) |
| `Cannot query field X` | Field doesn't exist on that type | Check Linear GraphQL schema for available fields |
| `Unauthorized` | Bad API token | Regenerate token from workspace settings |
| `Too many requests` | Rate limiting | Add exponential backoff + cache results |

**Retry pattern:**

```python
import time

def query_with_retry(query_fn, max_retries=3):
    """Retry query with exponential backoff."""
    for attempt in range(max_retries):
        try:
            return query_fn()
        except Exception as e:
            if attempt < max_retries - 1:
                wait = 2 ** attempt
                print(f"Retrying in {wait}s after: {e}")
                time.sleep(wait)
            else:
                raise
```

## Pitfalls

1. **Pagination**: Linear GraphQL uses `first:` (not `limit:`), `after:` cursor tokens. Always handle `endCursor` for large result sets.

2. **Rate limiting**: Linear has rate limits. Cache results and avoid repeated identical queries within seconds.

3. **Field availability**: Not all fields exist on all types. Test queries on smaller result sets first.

4. **Team/Project IDs**: Use `key` (e.g., "CD", "KS") for human-readable filtering when possible; `id` is a UUID.

5. **Status names**: Status names vary per workspace. Query once to discover available statuses; don't hardcode ("Backlog" vs "Waiting" vs "Triage").

6. **Custom fields**: Custom fields are workspace-specific. Query `customFieldValues` for each issue type, not global definitions.

## When to Use This

- ✅ Bulk backlog analysis (analyze patterns, then design routing)
- ✅ Autonomous issue routing (query issues matching criteria, route to profiles)
- ✅ Evidence generation (pull issue data to verify work completion)
- ✅ Reporting (aggregate status/priority/team data)
- ❌ Real-time updates (use webhooks instead for streaming)
- ❌ Sensitive field access (GraphQL queries are scoped to token perms)

## See Also

- `linear-dispatch-architecture` — Use results to design routing rules
- `linear-accurate-updates` — Mutation patterns (POST/PUT)
