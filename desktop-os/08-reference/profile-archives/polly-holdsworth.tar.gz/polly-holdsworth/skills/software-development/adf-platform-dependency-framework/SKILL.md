---
name: adf-platform-dependency-framework
description: Use when a Linear project depends on external platforms and needs a reusable platform-by-platform operating framework. Identify the dependency set, map each platform to an existing or new skill, and keep the result reusable across future projects.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [linear, platforms, dependencies, skills, framework, reusable, ADF]
    related_skills: [linear-native-operating-model, linear-accurate-updates, linear-freshness-guard, mcp-integrations, google-workspace, himalaya]
---

# ADF Platform Dependency Framework

## Overview

Use this skill when a Linear project is really a multi-platform operating model in disguise. The goal is to identify the external platforms the project depends on, decide whether Hermes already has a reusable skill for each one, and then build or patch the missing pieces so later projects can reuse the same framework.

This skill is intentionally cross-platform: it does not replace the platform-specific skills. It sits above them and answers three questions:

1. Which platforms does this project depend on?
2. Which existing skill already covers each platform?
3. What new skill or patch is needed so the pattern can be reused?

## When to Use

- A project mentions multiple external tools, services, or systems of record
- You need to turn a single project into a reusable ADF operating framework
- Laura, Mai, Eve, or another actor needs a repeatable platform-by-platform workflow
- You want to avoid hand-crafted one-off instructions for every project
- A new dependency appears and should become a permanent skill instead of a session-only workaround

## Workflow

### 1) Identify the dependency set
Read the live Linear project description, content, comments, and related issues. Classify every dependency into one of these buckets:

- **System of record** — where authoritative work truth lives
- **Comms / mailbox** — where replies, escalations, or notifications happen
- **Collaboration / docs** — where notes, docs, sheets, and planning live
- **Auth / integration layer** — MCP, OAuth, or API access that connects Hermes to the platform
- **Reporting surface** — dashboards, exports, or structured reporting destinations
- **External execution system** — a platform that actually carries out work outside Linear

### 2) Map each platform to an existing skill
Before writing anything new, check whether a skill already covers the platform.

Current common matches in this workspace:

- **Linear** → `linear-native-operating-model`, `linear-accurate-updates`, `linear-freshness-guard`
- **MCP connection layer** → `mcp-integrations`
- **Google Workspace** → `google-workspace`
- **Mailbox ops / SMTP-IMAP style email** → `himalaya`

If an existing skill already covers the need, reuse it. If it is close but incomplete, patch it.

### 3) Create only the missing platform skill
If no existing skill covers the dependency, create a new one with this structure:

- Overview
- When to Use
- Setup / Authentication
- Core Operations
- Pitfalls
- Verification Checklist

Keep the skill focused on one platform or one platform class. Do not mix unrelated platforms into the same skill unless the integration is inseparable.

### 4) Record the project-specific inventory
For the current project, write down:
- platform name
- why it matters
- existing skill to reuse
- auth / access model
- the first validation step
- the failure mode to watch for

This becomes the project’s reusable platform inventory for later projects.

### 5) Validate the framework
A good platform framework is only real if it can be applied immediately:

- each dependency maps to a skill
- each skill has a clear trigger
- each skill has a validation step
- the project can be handed to the delivery lead without custom explanation every time

## Current project dependency inventory

For `KOHD ADF Operating Model`, the current live dependency set is:

- **Linear** — system of record for project structure, updates, comments, and delivery truth
- **Himalaya** — mailbox operations and customer-response handling
- **Google Workspace** — calendar, docs, sheets, drive, and escalation/reporting support when needed
- **Go High Level** — CRM, pipelines, automations, and client communication workflow
- **FlowFuse** — deployed flows, Node-RED-style automation runtime, and edge/integration execution
- **MCP integrations** — connection layer used when Hermes needs to reach hosted platforms through MCP rather than direct API calls

## Solution blueprint companion

Pair this framework with `adf-solution-blueprint` for the live architecture document and `adf-project-handoff-template` for the Laura handoff artifact. The blueprint is the durable integration/dataflow/auth reference; the handoff template is the sprint-start wrapper.
## Pitfalls

- Do not invent a new skill when an existing one already covers the platform.
- Do not bury the dependency inventory inside a long project note where it will drift.
- Do not make the platform framework depend on milestones or other temporary scaffolding.
- Do not blend system-of-record logic with comms or docs logic unless the platform truly spans both.
- Do not mark a platform “covered” until its skill has a validation step and a failure mode.

## Verification Checklist

- [ ] The project’s external platforms are listed explicitly
- [ ] Each platform maps to an existing or newly created skill
- [ ] Any missing skill has been created or patched
- [ ] The framework is reusable for the next project without rewriting the whole approach
- [ ] The delivery lead can use the framework without learning hidden platform rules
