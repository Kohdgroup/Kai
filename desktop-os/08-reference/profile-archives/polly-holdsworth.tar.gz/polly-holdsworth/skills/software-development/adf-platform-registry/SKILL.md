---
name: adf-platform-registry
description: Use when a KOHD/ADF project needs a canonical registry of external platforms, their owners, skills, auth models, dependencies, and live status so future projects can reuse the same inventory pattern.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [ADF, registry, platforms, inventory, ownership, auth, dependencies, reusable]
    related_skills: [adf-platform-dependency-framework, adf-solution-blueprint, adf-project-handoff-template, linear-accurate-updates]
---

# ADF Platform Registry

## Overview

Use this skill to maintain the canonical platform registry for KOHD and other ADF projects. The registry is the authoritative inventory of every dependent platform: what it does, who owns it, which skill covers it, how it authenticates, what it depends on, and whether it is ready, blocked, or in discovery.

The registry is the index that ties together the solution blueprint, the platform matrix, and the Linear issue structure.

## When to Use

- A project depends on multiple external platforms
- You need a single canonical inventory of platform dependencies
- You want to track ownership, auth, validation, and live status in one place
- Laura needs a reliable platform index before sprint slicing begins
- You want future projects to reuse the same platform inventory format

## Registry Fields

For each platform record:
- platform name
- role in the system
- owner or responsible actor/team
- reusable skill name
- auth / access model
- primary integrations
- upstream dependencies
- downstream consumers
- first validation step
- current status
- failure mode / recovery note
- Linear issue link
- blueprint reference

## Workflow

### 1) Seed the registry
Start from the known platform set and add one row per platform. Do not merge unrelated platforms into one row.

### 2) Validate ownership
Every platform must have a current owner or workstream. If ownership is unknown, mark it as discovery rather than guessing.

### 3) Link to the companion artifacts
The registry should point at the live solution blueprint for architectural detail, the platform matrix for quick reference, and the operating-model index as the canonical landing page.

### 4) Link to Linear
Every registry row should map to a live Linear issue or workstream so status can be updated without hunting through notes. Where review gates exist, include the review-path issue in the row or notes so the approval path is visible.

### 5) Keep status live
Update the registry when:
- auth changes
- an integration changes
- validation passes or fails
- ownership changes
- a platform is retired or added
- review gates or workstream ownership changes

## Suggested KOHD registry rows

- Linear
- Himalaya
- Google Workspace
- Go High Level
- FlowFuse
- MCP integrations where needed

## Pitfalls

- Do not let the registry drift into a static spreadsheet with stale status.
- Do not duplicate the full architecture narrative; that belongs in the blueprint.
- Do not leave ownership blank unless the platform is genuinely in discovery.
- Do not store secrets in the registry.

## Verification Checklist

- [ ] Every platform has a row
- [ ] Ownership is recorded
- [ ] Skill mapping is recorded
- [ ] Auth model is recorded
- [ ] Linear link exists
- [ ] Blueprint link exists
- [ ] First validation step is recorded
- [ ] Status is current
