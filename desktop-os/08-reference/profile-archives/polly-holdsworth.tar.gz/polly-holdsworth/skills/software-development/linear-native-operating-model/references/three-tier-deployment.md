# Three-Tier Deployment Architecture for ADF Implementation

## Model Overview

The native Hermes operating model for ADF uses three independent tiers, all coordinated through Linear + Telegram:

### Tier 1: Your Laptop (Neil - Digital Twin)
- **State**: Awake ONLY when actively in use; sleeps immediately when closed
- **Role**: Thinking partner, decision-maker, work creator
- **Capability**: Chat through problems, explore, think, create Linear issues from decisions
- **Coordination**: Posts decisions/issues to Linear, receives async approvals on Telegram
- **Autonomy**: None (user-driven, fully interactive, zero background execution)
- **Key**: NOT a background system. No processes when closed.

### Tier 2: Desktop PC (Laura's Workforce - Always-On 24/7)
- **State**: Permanently running, continuous availability
- **Profiles**: Laura (orchestrator), Mai (architect/writer), Kai (validator/tester), Rai (ops), extensible
- **Role**: Autonomous execution of assigned work from Linear
- **Capability**: Reads Linear continuously, executes tasks via any available skill, posts evidence/results
- **Coordination**: Watches Linear for issues with ready status → executes → posts results
- **Autonomy**: High (no human loop for execution; reads Linear → runs task → updates Linear)
- **CRITICAL**: Profiles are NOT domain-locked
  - Mai is not "just architecture" — Mai executes blog posts, design docs, strategy work, anything available
  - Kai is not "just testing" — Kai executes code review, QA, validation, anything available
  - Profile identity ≠ task type. Skill availability determines what work can be done.

### Tier 3: Control Plane (Rai - 100% Autonomous Operations)
- **State**: Permanently running, continuous availability
- **Profile**: Rai (production/operations authority only)
- **Role**: Autonomous ops, readiness checks, production deployment
- **Capability**: Watches Linear for "Ready" status → runs smoke tests → collects evidence → posts verification
- **Coordination**: Pure operations read → execute → report; zero human interaction needed
- **Autonomy**: Complete (fully automated, no wait loops, no human approval in ops path)

## Data Flow

```
USER CREATES → DESKTOP EXECUTES → CONTROL PLANE OPERATES → RESULTS POSTED
     ↓              ↓                    ↓                       ↓
  (Laptop)     (Reads Linear)      (Reads Linear)          (Back to Linear)
   Think        Execute skills      Run ops checks         You read results
  Decide        (any profile)        Post evidence         on laptop when
  Create        Coordinate           Autonomous           you're awake
  Issue         via Laura
                Post results

All three tiers watch the same LINEAR instance
All approvals/decisions flow via TELEGRAM (async, you stay mobile)
```

## Workflow Pattern (Detailed Example)

**Monday 10am - You (Laptop Awake)**:
```
Chat with Neil:
  You: "If we sync rosters across 5000 clubs and one club's API fails mid-sync,
       what happens to the others?"
  
  Neil: "[Think through failure modes]
        - Risk 1: If we don't circuit-break, failure cascades
        - Risk 2: If we don't have rollback, partial state persists
        - Risk 3: If we block on one club, queue backs up
        
        Pattern: circuit breaker + per-club timeouts + async retry"

You: "Got it, create Linear issue for this architecture decision"

Neil posts to Linear:
  MBLK-2401: Circuit Breaker Pattern for Multi-Club Sync
  Assignment: mai-architecture
  Tags: architecture-decision, ready-for-design
```

**Monday 3pm - You (Laptop Closed, Hermes Sleeps)**:
- Your Hermes profile: offline
- Nothing runs on your laptop

**Monday 11am-Tuesday 11pm - Desktop PC (Always Awake)**:
```
Laura (constantly reading Linear):
  Sees MBLK-2401 "Ready for Design"
  Posts to Telegram: "@Neil: Architecture decision posted. Mai analyzing."

Mai (reads Linear):
  Sees MBLK-2401 assigned to her
  Executes: design-architecture skill → writes technical spec
  Posts comment: "Circuit breaker design ready. 2 failure modes covered, 1 needs input."
  
Kai (reads Linear):
  Sees Mai completed design review
  Laura posts: "@Kai: Validate Mai's failure mode coverage"
  Executes: validation skill → tests circuit breaker logic
  Posts comment: "✅ All 3 modes validated. Spec is sound."

Laura (sees Kai's validation):
  Updates MBLK-2401 status: "Design Review" → "Ready for Implementation"
  Posts to Telegram: "@Neil: Architecture ready, Kai validated. Your decision?"
```

**Tuesday 9am - You (Laptop Awake)**:
```
Neil shows you summary: "Here's what Desktop did while you were offline"
You read:
  - Mai's design spec (in Linear)
  - Kai's validation (in Linear)
  - Laura's orchestration updates (in Telegram)

You type comment: "Approved for Phase 1. Move to implementation."

Neil posts to Linear and Telegram.
```

**Tuesday 10am-5pm - Desktop PC (Still Awake)**:
```
Laura reads your approval comment
Laura: "Mai, write implementation spec" + "Kai, design test suite"

Mai executes: spec-writing skill → posts implementation doc
Kai executes: test-design skill → posts test plan

Both complete before you close your laptop.
All results in Linear.
```

**Whenever Status = "Ready for Deployment"**:
```
Control Plane (Rai):
  Reads Linear
  Spawns 9-node smoke tests
  Collects evidence: docker logs, timestamps, outputs
  Posts comments: "✅ Node-01 ready", "✅ Node-02 ready", etc.
  Once all pass: "✅ ALL SYSTEMS READY. Evidence trail: [links]"
  Updates status: "Deployed"
  
Zero human interaction in ops phase.
```

## Key Principles

1. **Laptop = You**
   - Sleeps when closed (no background processes ever)
   - Think partner when open (chat, explore, decide)
   - Creates LINEAR work, not executes it

2. **Desktop = Team**
   - Always working, 24/7
   - Any profile can do any task (skills determine capability, not role)
   - Autonomous (reads Linear → executes → posts; no wait loops)

3. **Control Plane = Guardian**
   - Watches for "Ready" work
   - Executes ops completely autonomously
   - Posts evidence, zero human loop

4. **LINEAR = System of Record**
   - All work tracked here
   - All decisions logged here
   - All evidence stored here
   - All three tiers read/write the same issues

5. **TELEGRAM = Approval Channel**
   - You stay connected on your phone
   - Desktop posts: "Architecture ready, approve?"
   - You reply: "Approved" (async, no need to be at laptop)
   - Desktop reads your reply and proceeds

6. **Profiles as Agents, Not Roles**
   - Mai is not locked to "architecture"
   - Kai is not locked to "testing"
   - Each profile is a capable agent who can execute whatever skills are loaded
   - Skill availability = task possibility
   - Laura assigns based on capacity + relevance

## Scaling Pattern

This model scales beyond ADF implementation:

**Week 1**: AI implementation + validation
- Desktop runs ADF platform integration skills

**Week 2**: Same Desktop + content creation
- New profile: content-director
- Laura assigns: "Write blog series on new platform features"
- Same Desktop now does implementation + content

**Week 3**: Same Desktop + support operations
- New profile: support-lead
- Laura assigns: "Triage club questions from Telegram"
- Same Desktop now does implementation + content + support

**Month 2**: Same Desktop + analytics
- New profile: analyst
- Laura assigns: "Generate weekly club metrics reports"
- Same Desktop scales to any domain

The operating model is domain-agnostic. The Desktop is a unified workforce. Profiles are agents. Skills are tasks. Linear is the contract.

## Webhook Integration (External Triggers)

For recurring tasks (~1 per week), external systems trigger via webhook:

```
External: Spond detects roster change
  POST /webhook/adf-sync
  payload: {"club_id": "5042", "type": "spond_roster_update"}

Control Plane webhook handler:
  Validates signature
  Creates Linear issue: "MBLK-1042: Sync rosters for Club 5042"
  Status: "Ready"
  
Desktop (Laura):
  Sees issue ready
  Assigns to Kai or Rai
  "Execute spond-sync skill for Club 5042"
  
They execute, post evidence to Linear
Same dispatch flow as manual issues
```

## Implementation Checklist

To operationalize this model:

- [ ] Laptop: Neil profile (sleep-wake, thinking partner, issue creation)
- [ ] Desktop: Laura profile (always-on orchestrator, Linear reader, assignments)
- [ ] Desktop: Mai profile (architecture, design, content execution)
- [ ] Desktop: Kai profile (validation, testing, QA execution)
- [ ] Desktop: Rai profile (deployed to Control Plane; ops-only)
- [ ] Telegram: Gateway connected, Desktop can post approvals/alerts
- [ ] Linear: Tags for work routing (ready-for-design, ready-for-testing, ready-for-ops)
- [ ] Skills: Both tiers loaded with implementation skills + content + validation skills
- [ ] Evidence model: All work posts Linear comments with structured evidence
- [ ] Onboarding: Laura's skill for continuously reading Linear + assigning work

## This is NOT:

- Daemon polling (no cron loops watching for work 24/7)
- Custom control plane (native Hermes patterns only)
- Faceless-only workers (profiles are named, attributed, skill-based)
- Always-on laptop (your laptop sleeps; you stay mobile via Telegram)
- Hybrid planning (Linear is the only coordination surface)

This is a **complete, domain-independent operating model** for AI-assisted autonomous work.
