# Project clean-sweep pattern

Use this when a project is being prepared for Laura to take over sprint planning autonomously.

## Goal
Remove legacy planning scaffolding so the project reads as a clean delivery surface.

## Checklist
1. Delete obsolete milestones if they are only historical markers.
2. Delete obsolete project updates/comments if they are stale or misleading.
3. Remove phase/scaffolding language from the project description and content.
4. Re-read the project and verify the live text no longer references the retired model.
5. Keep only the planning language Laura needs: current work, dependencies, readiness, and delivery slices.

## Verification
- `projectMilestones` should be empty unless a milestone is actively used.
- Project description/content should not refer to retired phases or milestones.
- The remaining project text should tell Laura how to plan, not how to preserve old structure.

## Handoff note
When the project is clean, post a short Linear project update giving Laura the go-ahead to begin autonomous sprint planning from live slices and dependencies.