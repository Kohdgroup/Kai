---
name: linear-native-operating-model
description: Linear-first planning, deployment, and validation for control-plane architectures that use named orchestrators plus faceless worker fleets with minimal custom glue.
---

# Linear-native operating model

Use this skill when the task is to design, rewrite, deploy, or validate a control-plane / worker-fleet operating model, especially when the user wants:

- Linear as the system of record
- native platform integrations with minimal custom work
- version-controlled documentation first
- named control-plane actors and faceless execution workers
- evidence-based completion before marking work done

## Core principles

1. **Linear is the source of truth.**
   - Requirements, sprint scope, comments, blockers, approvals, and final sign-off belong in Linear.
   - Do not create a parallel truth layer unless the user explicitly asks for one.

2. **Use native platforms first.**
   - Prefer built-in Linear workflows, standard Docker/container patterns, Redis for ephemeral orchestration state, and direct Telegram notifications over bespoke glue.
   - Avoid custom queues or custom abstractions when a standard platform mechanism is good enough.

3. **Separate governance from execution.**
   - Keep named roles on the control plane for orchestration, delivery gating, and escalation.
   - Keep workers faceless when they only execute work.
   - Do not over-assign persona/identity to worker nodes.

4. **Treat completion as evidence-based.**
   - “Done” only means something when acceptance criteria are testable and validation is real.
   - Post evidence back into Linear before closure.

5. **Prefer version-controlled documentation.**
   - When a new operating model is being introduced, start with a target-state architecture spec in a repo.
   - Keep deployment runbooks, validation steps, and assumptions alongside the code/docs.

6. **Ask one clarification question at a time.**
   - When scope or architecture is ambiguous, avoid multi-question bundles.
   - Ask the smallest question that actually changes the design.

## Recommended workflow

1. **Reconcile current state.**
   - Review the authoritative source(s) first: Linear, release notes, existing deployment docs, or live infra when relevant.
   - Check whether a new release changes the baseline before reusing older design assumptions.

2. **Write the target-state architecture first.**
   - Capture the operating model, roles, scope gates, validation rules, and expansion path.
   - Keep it concise enough to stay maintainable.

3. **Define the Linear workflow.**
   - Sprint membership should usually define scope.
   - Use issue status for readiness/dispatch gating.
   - Keep actor-based comments and blocker escalation in Linear.
   - If the user needs reporting, make releases, milestones, story points, and token metrics first-class fields rather than afterthoughts.

4. **Use minimal operational state.**
   - Redis is appropriate for heartbeats, leases, retries, drain flags, and in-flight coordination.
   - Do not store durable business truth in Redis.

5. **Deploy and validate iteratively.**
   - Verify control plane first, then worker nodes, then Linear comment/write-back, then completion evidence.
   - Close only after the evidence loop succeeds.

6. **Respect Linear API throughput.**
   - Batch writeback at the work-unit level when possible: one issue per unit and one consolidated comment per unit.
   - Add retry/backoff for transient 429 and 5xx responses.
   - Throttle bursts between work items.
   - Keep payloads minimal and audit-friendly.
   - Use the live token mode exactly as granted; validate mutation shape before adding optional fields.

7. **Plan for expansion without redesign.**
   - Separate the current node count from the future expansion path.
   - Design the control plane so more workers can be added without changing the operating model.

8. **Make reporting usable by the named operator.**
   - When Mai owns setup and Eve owns dashboards, prefer a model that lets Eve report directly from Linear without manual reconstruction.
   - Keep the workflow simple enough for Laura to operate while preserving the fields Eve needs for reporting.

9. **Capture production configuration quirks explicitly.**
   - If a mutation accepts both a default-template flag and an explicit template id, test the combination before assuming it is valid.
   - If Linear rejects custom release stages, check whether the pipeline only permits the default stage shape for the requested stage type.
   - If a test view is created more than once, delete the duplicates immediately and keep a single canonical shared view.
   - If milestones are acting as historical scaffolding rather than active sprint-planning primitives, remove them and verify the project still reads cleanly for Laura’s sprint breakdown.
   - A cleanup pass is not complete until the visible project text also stops referencing the retired milestone/phase model.

10. **Keep production config notes in a reference file.**
   - Session-specific Linear schema quirks, validated IDs, cleanup patterns, stage limitations, and team-splitting decisions belong in `references/linear-production-config-notes.md`.
   - Update the reference when a live mutation succeeds or fails in a way that changes the recommended workflow.
   - Record when milestone or phase cleanup is the preferred path for a project so future items start from a clean sprint-planning surface.
   - See `references/project-clean-sweep-pattern.md` for the project-level cleanup checklist used before handing autonomous sprint planning to Laura.

11. **Use the right handoff channel for autonomous planning.**
   - When Laura is being given the go-ahead to plan autonomously, write a concise project update that states the authorization, the planning scope, and the things she must not rely on.
   - Keep the update in Linear so the handoff is auditable.
   - Prefer project updates over ad hoc comments when the message is a project-wide operating instruction.

10. **Split backlog grooming from delivery execution when the backlog is large.**
   - Create a dedicated backlog team with triage enabled, estimation disabled, and a grooming template when current delivery work should stay clean.
   - Use the delivery team only for ready work and sprint planning.
   - Keep the backlog team as the intake/grooming funnel rather than a second delivery lane.
   - See `references/backlog-delivery-partition.md` for the current KOHD partition pattern.

11. **Keep review gates separate from execution issues when the project team is fixed.**
   - Use BIZOPS (or the designated review team) for sign-off and approval gates.
   - Use MBLK (or the designated backlog team) for platform discovery, registry, blueprint, and execution workstreams.
   - If Linear rejects a review issue because the project belongs to another team, create the review issue without the project link and connect it back with a project update or explicit issue relation instead of forcing an invalid team/project combination.

12. **Keep the workflow reusable across future projects.**
   - Capture the cross-team partition, registry, blueprint, and review-gate pattern in a small reference file rather than re-deriving it every session.
   - Point future handoffs at the reference file so the next project can reuse the same structure immediately.
   - Record the review team and execution team explicitly in the registry and blueprint so the approval path remains visible even when direct links are unavailable.

## Pitfalls

- **Do not** make a local queue the system of record when Linear should own the work truth.
- **Do not** introduce custom labels or states unless a real gap appears in the native workflow.
- **Do not** default to many clarification questions; one good question is better.
- **Do not** keep named identities on workers when shared faceless workers are sufficient.
- **Do not** mark work done without test/validation evidence and a Linear audit trail.
- **Do not** skip the target-state spec and jump straight to deployment when the architecture itself is still shifting.
- **Do not** force cross-team review gates into a project/team combination that Linear rejects; instead keep the review issue in the review team and connect it back by update or relation.

## References

- See `references/operating-model-baseline.md` for the current v2026.7.1-aligned decisions, role split, and rollout assumptions.
- See `references/linear-writeback-throughput.md` for the control-plane Linear writeback batching, retry, and throttling pattern.
- See `references/linear-adf-reporting-blueprint.md` for the session-derived ADF reporting schema and dashboard layout.
- See `references/linear-production-config-notes.md` for live cleanup decisions, including when milestones were removed to keep sprint planning clean.
