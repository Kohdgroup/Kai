# KOHD Cross-Team Review-Gate Pattern

Session note: when the project’s review lane lives in a different Linear team than the execution lane, keep the teams separate and make the approval path visible in the docs/registry instead of forcing an invalid project/team combination.

## Pattern
- **MBLK** owns platform discovery, registry, blueprint, matrix, and execution workstreams.
- **BIZOPS** owns review gates and approval/sign-off.
- If Linear rejects a review issue because the project belongs to another team, create the review issue in the review team without the invalid project association and connect it back by a project update, registry note, or explicit issue relation when the API scope allows it.
- Record the review team and execution team in the registry and blueprint so the approval path remains visible even when direct links are blocked.

## Why it matters
- Keeps delivery work clean.
- Prevents forced invalid team/project pairings.
- Gives Laura a clear starting point while preserving governance separation.
