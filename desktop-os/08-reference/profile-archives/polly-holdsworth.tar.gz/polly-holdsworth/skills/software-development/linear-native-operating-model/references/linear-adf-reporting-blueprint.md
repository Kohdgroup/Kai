# Linear ADF Reporting Blueprint

Session-derived guidance for KOHD's Linear operating model.

## Reporting-first requirements
- The business requirement is that Eve can report on delivery without manual reconstruction.
- Reporting must cover: releases, milestones, story points, sprint references, estimated tokens, actual tokens, and variance.
- Mai owns setup and schema integrity; Laura executes delivery; Eve consumes dashboards and data.

## Suggested object hierarchy
- KOHD / portfolio view
- Project or initiative
- Release
- Milestone
- Sprint
- Issue / sub-issue

## Required issue fields
- Owner
- Status
- Story points
- Sprint reference
- Release reference
- Milestone reference
- Estimated tokens
- Actual tokens
- Token variance
- Reporting domain / KOHD area

## Dashboard set
- Executive delivery view: release progress, milestone status, blockers.
- Sprint view: planned vs completed points, carryover.
- Token view: estimated vs actual tokens, variance, efficiency trend.
- Data quality view: missing fields, stale items, unowned issues.

## Simplified ADF workflow
Use a compact workflow unless a stronger gate is needed:
- Backlog
- Ready
- In progress
- Blocked
- Review
- Done

## Template expectation
Every reportable issue should be created from a template that prompts for the required fields above.

## Pitfall
Do not let dashboards depend on tribal knowledge or one-off manual reconciliation; if Eve cannot read it directly from Linear, it is not yet reportable.