# Operating model baseline

## Current baseline decisions

- **Authoritative release baseline:** Hermes Agent `v2026.7.1` / `0.18.0`.
- **Linear is the system of record** for all work.
- **All issue comments must be written back to Linear.**
- **Issue completion requires testable business requirements and real validation.**
- **Named control-plane actors:**
  - Rai = orchestrator
  - Laura = Scrum Master / delivery gate
  - Eve = escalation / risk / metrics
  - Domain leads only when they still map to active Linear ownership
- **Worker topology:**
  - 9 worker nodes now
  - expand later as hardware arrives
  - workers are faceless shared execution nodes
- **Operational state:** Redis is the preferred lightweight coordination layer for:
  - worker heartbeats
  - leases / dispatch locks
  - retries / backoff
  - drain coordination
  - in-flight task tracking
  - idempotency keys
- **Documentation:** new architecture should be captured in a version-controlled repo before deployment.
- **Workflow preference:** ask one clarification question at a time when the architecture is still being refined.

## Notes from this session

- The user rejected a fully named-worker model and preferred faceless worker nodes.
- The user prefers native platform integration and minimal custom work.
- The user wants future cleanup work to audit old/outdated artifacts before deletion.
- The user wants the target-state architecture spec written first, then control-plane validation/deployment.
- The user specifically wants Linear to support sprint-based scope and actor-based comments, with real blockers surfaced in Telegram daily standup.
