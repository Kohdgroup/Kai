# Backlog / Delivery Partition (session note)

Use this as the current operating pattern for KOHD Linear work.

## Partition
- **Master Backlog (MBLK):** raw intake, grooming, grouping, dependency mapping, registry, blueprint, and readiness triage.
- **BIZOPS:** review-only team for sign-off and approval gates.

## Rules learned in session
- Keep BIZOPS clear when you want a clean sprint board.
- Move backlog fragments, duplicate themes, and non-ready project work into MBLK.
- Leave delivery projects in BIZOPS only when they are intentionally live delivery containers.
- If a project still owns issues on a team, remove or move those issues first before trying to remove that team from the project.
- If a review gate belongs in BIZOPS but the project is owned by MBLK, create the review issue **without** the project link and connect it back through a project update or explicit relation. Do not force an invalid team/project combination just to preserve one link.

## Reusable integration pattern
- Shared platform integration work should live in a reusable framework project or equivalent shared object.
- Delivery projects should reference the framework instead of recreating connector/auth/retry/payload logic per project.
- Use a dedicated project label or dependency marker for shared integrations when the project relation cannot be expressed directly.

## Review lane pattern
- Use BIZOPS for approval gates such as blueprint sign-off, registry sign-off, and sprint-cut approval.
- Use MBLK for platform discovery, registry, blueprint, matrix, and execution workstreams.
- Keep review gates auditable through Linear project updates even when the review issue cannot be attached to the project.

## Verified examples from this session
- `Master Backlog` team created for grooming.
- `KOHD ADF Operating Model` moved out of BIZOPS and into MBLK while it was being groomed.
- `CD__ecopuk` moved to BIZOPS for active delivery.
- `Platform Integrations Framework` created as a reusable BIZOPS project.
- `Platform Integrations` project label created for shared dependency work.
- `BIZOPS-103` and `BIZOPS-104` created as review gates separate from the MBLK project work.
