# Linear writeback throughput notes

## What we learned in this session

- Use the **control plane** as the only writer to Linear.
- The current flow works best when it creates **one issue per node/work unit** and posts **one consolidated comment per node/work unit**.
- For evidence-heavy runs, keep the Linear body short and structured; avoid dumping redundant logs into multiple comments.
- Add **retry/backoff** for transient HTTP 429/500/502/503/504 responses.
- Add a small **inter-item throttle** between Linear writes when iterating across many nodes.

## Token / mutation quirks

- The Linear token for this workflow is used as a **raw token** in the Authorization header.
- `issueCreate` works with the team/title/description payload.
- `commentCreate` works with `issueId` and `body`.
- Do **not** assume actor-style fields like `createAsUser` are valid for this token mode; confirm against the live schema and the token’s auth mode.

## Validation pattern

1. Confirm the token works with a simple `viewer { id name }` query.
2. Confirm `issueCreate` with a minimal payload.
3. Confirm `commentCreate` with a minimal payload.
4. Only then run the full suite with retries and throttling enabled.

## Failure handling

- If the writeback path returns a 400, first test a minimal mutation before changing the rest of the suite.
- If the writeback path returns a 502, retry the request before rewriting the workflow.
- If a noisy run looks stalled, inspect the live output for whether the failure is actually a rate-limit or payload-shape issue.
