# Linear production config notes

Session-derived notes for the KOHD ADF operating model.

## Team split
- **BIZOPS / Business Operations** is the delivery team.
- **MBLK / Master Backlog** is the grooming and intake team.
- Keep delivery clean by moving only ready work into BIZOPS.

## BIZOPS configuration
- Cycles enabled: yes
- Cycle duration: 2 weeks
- Estimation type: linear
- Default issue template: `KOHD ADF Delivery Standard`
- Use this team for sprint planning and execution, not raw grooming.

## Master Backlog configuration
- Cycles enabled: no
- Triage enabled: yes
- Estimation type: notUsed
- Default issue template: `Master Backlog Grooming Standard`
- Use this team for raw intake, grouping, dependency mapping, and readiness checks.

## Production objects created
- Project: `KOHD ADF Operating Model`
- Project milestones: `ADF Setup Complete`, `ADF Reporting Live`
- Shared views: `KOHD ADF Reporting`, `KOHD ADF Pipeline View`, `Master Backlog Queue`
- Release scaffold: `KOHD ADF Releases`

## Notes on live mutation behavior
- Team creation worked with the minimal `TeamCreateInput` shape using `name` and `key`.
- `TeamUpdateInput` accepted default-template updates for the new backlog team.
- Team update input can be picky about scalar typing; prefer re-reading the schema or trying the smallest working payload when a field rejects a boolean-like value.
- Custom release-stage creation can be restricted by Linear’s stage-type rules; if a stage creation fails, read the validation message instead of forcing a bespoke pipeline shape.
- Duplicate test views should be deleted immediately, leaving one canonical shared view.

## Grooming rule of thumb
- If an item is not ready for sprint planning, keep it in MBLK.
- If Laura can plan it now, move it to BIZOPS.
- Do not let backlog grooming pollute sprint execution.
