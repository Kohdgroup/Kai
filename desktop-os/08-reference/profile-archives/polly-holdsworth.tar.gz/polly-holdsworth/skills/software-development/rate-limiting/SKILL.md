---
name: rate-limiting
description: Use when a service can reject bursts, enforce quotas, or return 429/5xx. Defines per-platform throttling, retry/backoff, batching, and idempotent write habits.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [rate-limiting, retries, throttling, quotas, 429, backoff, batching]
    related_skills: [linear-accurate-updates, linear-freshness-guard, google-workspace, himalaya, mcp-integrations]
---

# Rate limiting

## Overview
Use this skill when a workflow touches a platform that can slow down, deny, or partially accept requests due to quotas, burst protection, per-user limits, per-project limits, or provider-side throttling.

The goal is not just to “retry on error.” The goal is to keep writes safe, keep reads efficient, and prevent duplicate side effects when a platform is under pressure.

## When to Use
- A SaaS/API starts returning 429, 403 quota messages, or transient 5xx errors
- A workflow performs many writes in a row and can be throttled
- A service has separate per-user, per-project, per-mailbox, or per-workspace limits
- A task needs backoff, batching, jitter, or a queue instead of direct burst writes
- You need to understand the correct pacing rules for a specific platform before automating it

## Core Policy
1. **Classify the operation.** Separate reads, idempotent writes, and side-effecting writes.
2. **Prefer fewer calls.** Batch reads, consolidate writes, and cache repeated lookups.
3. **Throttle writes.** Insert a small delay between writes when iterating over many objects.
4. **Retry only safe failures.** Retry 429 and transient 5xx with exponential backoff + jitter. Be cautious with 403s unless the platform explicitly labels them as quota/rate-limit failures.
5. **Protect against duplicates.** If the platform can partially succeed, assume a retry may repeat side effects unless you confirm idempotency.
6. **Stop after a budget.** Cap attempts and escalate rather than looping forever.

## Platform Notes

### Linear
- Treat Linear GraphQL/API calls as quota-sensitive.
- Expect 429 and transient 5xx under bursty writeback.
- Use small batches, short structured comments, and an inter-item throttle when writing many issues or comments.
- Validate with a minimal `viewer` query and a minimal mutation before running a larger write sequence.
- Prefer one consolidated comment over many small comments when the intent is a single status update.

### Google Workspace
- Quotas are API- and account-dependent; assume per-project and per-user limits exist.
- Batch reads when possible and avoid rapid-fire writes to Gmail, Calendar, Docs, Sheets, or Drive.
- For Calendar and Gmail automation, pace create/send actions and avoid duplicate retries that could create duplicate meetings or emails.
- If a write fails after a side effect may already have occurred, verify the result before retrying.

### Himalaya / email via terminal
- IMAP/SMTP providers can throttle bursts, and SMTP retries can create duplicate mail if the first send actually landed.
- Keep sending deliberate and sparse.
- Prefer queued or piped composition over interactive repeated sends.
- If a send fails, confirm whether the message may already have been accepted before re-running it.

### MCP-backed SaaS tools
- Each MCP service has its own quota model; do not assume the tool itself is “free.”
- Prefer cached reads over repeated list/search calls.
- Avoid hammering a remote MCP endpoint with the same query in a loop.
- If the service returns throttling signals, back off at the client layer first.

### Generic REST / GraphQL services
- Use exponential backoff with jitter for 429 and transient 5xx.
- Respect `Retry-After` headers when present.
- Keep mutation payloads minimal when diagnosing failures.
- If a platform has no documented idempotency key, design one in your own workflow before automating writes.

## Practical Retry Ladder
1. Retry once after a short delay.
2. Retry again with a longer delay plus jitter.
3. Reduce batch size or stop writing.
4. Verify current state before any further write.
5. Escalate to a human if the platform remains constrained.
6. If a mutation/query shape fails, inspect the returned validation error, query the schema for the exact input/type shape, and adjust the payload rather than abandoning the workflow.
7. Re-read the live object after any workaround so the recovery is grounded in actual state.
8. If one object update fails in a batch, continue with unaffected objects after isolating the failure, rather than stopping the whole run.

## Common Pitfalls
1. **Blind retries on side-effecting writes.** This can duplicate emails, comments, meetings, or records.
2. **Treating every 403 as permission failure.** Some APIs use 403 for quota or org policy issues; inspect the payload.
3. **Large write bursts.** The fastest way to trigger throttling is often a long loop of mutations with no pause.
4. **No readback verification.** If the platform may have partially succeeded, verify the written object before attempting it again.
5. **Ignoring platform-specific limits.** Linear, Google, email providers, and MCP services each fail differently.

## Verification Checklist
- [ ] I know whether the operation is read-only, idempotent, or side-effecting
- [ ] I know the platform’s likely quota/throttle shape for this task
- [ ] Reads are batched where possible
- [ ] Writes are paced and consolidated
- [ ] Retry logic is limited to safe failures
- [ ] A duplicate write would not corrupt the result
- [ ] Verification happens before repeating a failed side effect

## Platform Register
Use this section to record discovered limits or provider-specific behavior as you learn them in live work. Keep it short and current.

- Platform:
  - Limit / throttle shape:
  - Safe retry conditions:
  - Unsafe retry conditions:
  - Notes:
