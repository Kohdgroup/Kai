---
name: linear-freshness-guard
description: Use when maintaining Linear progress for Hermes across multiple human actors and sub-issues. Prevent semi-stale state by forcing live verification, synchronizing parent and child issues, and rewriting resolved blockers instead of leaving outdated status language behind.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [linear, freshness, stale-state, verification, progress, actors]
    related_skills: [linear-accurate-updates, hermes-agent]
---

# Linear Freshness Guard

## Overview
Use this skill when Linear is being used as the live operating record for a multi-actor Hermes deployment. Its purpose is to prevent semi-stale state: progress claims, blocker labels, and sub-issues that are technically true at one moment but misleading a short time later.

The rule is simple: if a status line, blocker title, or sub-issue description is not grounded in a fresh verification, it should not be written as current truth.

## When to Use
- Updating parent issues and child issues in a live deployment thread
- Rewriting blocker tickets that were resolved but still read as open
- Preparing comments for Mai, Kai, Rai, Laura, Eve, Quinn, Maya, Thomas, Amelia, or Joseph
- Keeping KS-3048 or any anchor issue current while work continues
- Preventing the system from reporting progress that is accurate in spirit but stale in detail

## Freshness Rules
1. **Verify before you write.** A Linear update should be based on a live check from the control plane, the worker nodes, or the relevant source of truth.
2. **Anchor truth to one canonical checkpoint.** Maintain a parent issue that reflects the latest verified state, and make sure child issues do not contradict it.
3. **Retire stale blocker language immediately.** If a blocker is resolved, rename it and rewrite the description so it cannot be mistaken for an active blocker.
4. **Separate historical context from current state.** Historical notes are allowed only if clearly labeled as historical or resolved.
5. **Do not let placeholder issues masquerade as requirements.** If a ticket is still a scaffold, say so explicitly and keep it from being used as evidence of completion.
6. **Prefer short, fresh comments over long, drifting summaries.** Update often enough that each comment stays true when the next person reads it.
7. **Treat reboot and container-exit events as freshness boundaries.** If node01 reboots or a worker container exits, re-check runtime state, restart policy, and logs before resuming the checklist.
8. **Prefer step-wise timeouts over long monolithic runs.** If a validation chain can stall, break it into per-step checks so one hung stage does not hide later failures.

## Update Pattern
1. Check the live source of truth.
2. Identify whether the issue is current, resolved, or still placeholder.
3. Rewrite titles and descriptions to match the current state.
4. Post a short actor-based comment with the latest checkpoint.
5. Re-read the issue after the update if possible.

## Bad Patterns to Avoid
- Leaving a ticket titled like an open blocker after the blocker is gone
- Writing a progress percentage that no longer matches the issue trail
- Keeping stale sub-issues visible without clarifying they are historical
- Treating a placeholder test issue as if it already contains full business requirements
- Updating the parent issue but forgetting the children

## Verification Checklist
- [ ] Every issue title matches the current truth
- [ ] Every blocker title is either active or explicitly resolved
- [ ] The parent anchor issue reflects the latest checkpoint
- [ ] Child issues do not contradict the parent state
- [ ] Historical notes are labeled as historical or resolved
- [ ] No semi-stale progress language remains in active tickets
