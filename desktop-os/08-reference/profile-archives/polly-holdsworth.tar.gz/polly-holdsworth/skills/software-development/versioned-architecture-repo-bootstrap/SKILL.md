---
name: versioned-architecture-repo-bootstrap
description: "Bootstrap a new version-controlled repo for target-state architecture, deployment runbooks, and operating-model docs."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos]
metadata:
  hermes:
    tags: [git, github, repository, architecture, documentation, linear, deployment]
    related_skills: [github-auth, github-repo-management, github-pr-workflow, linear-workflow-governance]
---

# Versioned Architecture Repo Bootstrap

Use this skill when a user wants a clean, version-controlled repository for a new operating model, deployment target-state, or architecture spec.

## Trigger conditions
- User asks to start a new repo for architecture / deployment docs
- User wants documentation to be version controlled before deployment begins
- User wants a greenfield repo rather than editing an existing pile of notes
- User wants a future Linear audit or deprecation pass instead of deleting ad hoc

## Operating principles
- Prefer a **local scaffold first** when remote repo creation is blocked by auth or org policy.
- Keep the repo narrow and intentional: architecture spec, deployment runbook, Linear operating model, validation notes.
- Keep the target-state doc as the canonical source of truth for the upcoming deployment.
- Treat a `401 Unauthorized` on org repo creation as an auth/scoping/SSO problem first, not a naming problem.
- Do not waste time guessing repo names or retrying the same org call without fixing auth.

## Recommended workflow
1. Create a local repo scaffold and initial commit.
2. Add a canonical architecture doc.
3. Add a deployment runbook.
4. Add a Linear operating model doc.
5. Once GitHub auth is confirmed, create/push the remote repository.
6. Keep future cleanup/deprecation work as a separate Linear issue or project.

## Pitfalls
- **Don’t block versioning on GitHub auth.** If org repo creation is blocked, preserve the work locally first.
- **Don’t mix live deployment steps into the architecture spec.** Keep the design doc and runbook separate.
- **Don’t treat the repo as a scratchpad.** It should be the durable, versioned reference for the operating model.
- **Don’t delete legacy material immediately.** Plan an explicit Linear audit task to classify outdated assets before removal.

## Verification checklist
- Repo exists locally and is initialized on `main`
- Initial commit is present
- Docs are split into:
  - `README.md`
  - `docs/target-state-architecture.md`
  - `docs/deployment-runbook.md`
  - `docs/linear-operating-model.md`
- Target-state doc clearly states the canonical operating model
- Remote GitHub creation is only attempted after auth is known-good
