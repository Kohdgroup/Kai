---
name: linear-dispatch-architecture
description: "Use when designing or revising Hermes control-plane, worker, and governance architecture around Linear as the system of record. Keeps the model aligned to current release behavior, native-first deployment choices, actor-based Linear comments, and evidence-backed completion."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [linear, dispatch, orchestration, workers, governance, deployment, architecture]
    related_skills: [hermes-agent, plan, requesting-code-review]
---

# Linear-Driven Hermes Dispatch Architecture

## Overview

Use this skill when the user is shaping the Hermes operating model around Linear, control-plane governance, worker execution, and evidence-backed completion.

This skill favors the smallest native-first design that matches the latest Hermes release behavior and the user's live Linear reality. It is especially relevant when the user wants to avoid over-engineering, keep Linear as the source of truth, and design for both current worker capacity and near-term expansion.

## When to Use

- The user asks how to structure Hermes control-plane orchestration around Linear
- The user wants a greenfield or refactored deployment aligned to the latest Hermes release
- The user needs actor-based comments, blocker escalation, or daily standup routing
- The user is deciding between named profiles and faceless workers
- The user wants a deployment that can grow from a smaller worker pool to a larger one without a rewrite
- The user explicitly says Linear is the system of record

## Core Model

- **Linear is the system of record** for work intake, status, comments, blockers, and completion evidence.
- **Rai** is the orchestrator (control plane), not the worker.
- **Profiles are the workers** — each spawned profile is a **named actor** with its own OAuth credentials, identity, and audit trail. Not faceless execution nodes.
- **Each profile writes as itself** — when mai-architect executes work, she posts evidence comments as mai-architect (not masked through Rai).
- **Comments and blockers** must be written back into Linear so the record stays complete.
- **Done means proven**: an issue is only complete when the business requirement and validation evidence are satisfied.

## The Native Hermes Dispatch Methods

### Method 1: Kanban + Named Profiles (High-Volume, Fully Automatic)

**Profiles are the workers.** Each spawned worker is a **named actor** (mai-architect, laura-orchestrator, kai-validator, quinn-support, amelia-comms) with its own identity and credentials. The documented native dispatch pattern in Hermes v0.18.0 (2026.7.1) is:

1. **Kanban is the dispatcher** — Located at `~/.hermes/kanban.db`. Can be centralized on control plane or distributed. Not a side tool; it IS the work-routing system.

2. **Workers are full OS processes** — Each worker is spawned via `terminal(background=true)` as an independent **named profile**. Not in-process subagents. Each has its own config, OAuth credentials, and identity.

3. **Dispatcher runs in the gateway** — `kanban.dispatch_in_gateway: true` (default). It watches stale claims, promotes ready tasks, atomically claims work, and spawns the assigned **profile** as a worker process. Auto-blocks on repeated failure.

4. **Workers interact through `kanban_*` tools** — `kanban_show`, `kanban_complete`, `kanban_comment`, `kanban_heartbeat`, etc. NOT through shell-outs to `hermes kanban`.

7. **Each profile writes as itself** — mai-architect posts evidence as mai-architect, kai-validator as herself, etc. Each worker profile has its own `.env` with the correct OAuth actor token. When it calls `kanban_comment`, the comment appears in Linear under that identity — no masking.

8. **Multi-node topology** — Kanban.db can live on the dispatcher node (control plane). Worker nodes (01-09, etc.) each run their own Hermes instance. All nodes share access to the same kanban.db (NFS mount or replicated). When the dispatcher spawns a worker, it triggers that worker node's Hermes instance to claim and execute the task.

9. **Kanban `assignee` field is NATIVE and profile-name-based** — Tasks are assigned by profile name only: `kanban_create(assignee="jane-designer", ...)`. The Kanban dispatcher routes to that exact profile. This does NOT consume a Linear seat, and it is NOT a Linear assignee mutation. The assignee field lives only in kanban.db. See `references/linear-licensing-blocker-kanban-only-solution.md` for why this solves the Enterprise licensing blocker (1000+ issues, 80+ profiles).

**This is the ONLY documented way to scale from a small worker pool to many.**

See `references/kanban-dispatch-native-pattern.md` for the full architecture and integration recipe.

**NEW (Multi-Node Topology)**: See `references/kanban-multinode-topology.md` for Kanban + Named Profiles deployed across 9+ distributed worker nodes with centralized dispatcher (e.g., 60.10 + nodes 01-09). Includes profile distribution, failure handling, and scaling patterns.

**NEW (Multi-Project SaaS Provisioning, 2026-07-03)**: See `references/multi-project-saas-provisioning-pattern.md` for Rai orchestrator coordinating KOHD + Aardvark + EcoPUK delivery. Covers intake → approval gate (Telegram) → dispatch sequence (freddy-frontend / kai-backend / rai-sre) → provisioning (GHL snapshots + MariaDB schemas) → live. Includes credential vault, dispatch priority (60-70% KOHD, 20-30% EcoPUK, 10-20% Aardvark), load balancing, and production-phase (80% autonomous) workflows.

**NEW (GHL Snapshots + FlowFuse IP Protection, 2026-07-03)**: See `references/ghl-snapshots-flowfuse-ip-protection.md` for the architecture that enables repeatable deployment while hiding proprietary logic. Covers per-project snapshots (KOHD, EcoPUK, Aardvark), multi-tenancy via parameterization (tenant_id routing in Node-RED), credential flow (parent key for provisioning, sub-account keys per club, no keys for Node-RED), and full deployment sequence.

**NEW (Team-Centric Scaling to 80+ Profiles)**: The Kanban + Named Profiles model scales to many profiles via **team abstractions**, not individual profile-to-node mappings. Use Linear custom fields (`assigned_team`, `assigned_node`) as the routing source. Rai polls Linear every 1 minute, reads custom fields, maps team to node, and dispatches any available profile from that team. Team-level accountability in Linear comments; executor details in logs. See `references/team-centric-routing-linear-custom-fields.md` for the full pattern. **Blocker unblocked (2026-07-03)**: Linear custom fields are CONFIRMED supported. Ready for Rai cron implementation.

### Method 2: Linear-First Cron (Human-Initiated, Async Approvals)

An alternative pattern where profiles are always-on Linear watchers (not Kanban subscribers):

- Profiles run cron jobs that detect work via Linear status/assignee signals
- Laura is the orchestrator (routes between profiles)
- Mai/Kai/Rai execute skills and post evidence comments
- Telegram approval gates are async (Neil decides; profiles proceed when approved)
- Evidence trail lives entirely in Linear comments
- Setup is simpler (no Kanban board) but less automatic

**Use this when:**
- Work is primarily human-created (not mass webhooks)
- Approval gates must be async (Telegram, not blocking)
- Single Linear license with OAuth actors
- Evidence must live in Linear (not separate audit plane)

**Do not use this when:**
- Work volume is high (10+ tasks/hour)
- All stages must be automatic (no human approval gate)
- Worker pool scales beyond ~20 profiles

See `references/linear-first-cron-pattern.md` for the full pattern with club signup example.

## Release-Alignment Rule

Before using an older architecture document, reconcile it against the current Hermes release notes and baseline release behavior.

Default assumptions for v2026.7.1-era planning:
- MoA / mixture-of-agents is a first-class option
- verification and completion contracts matter
- background fan-out is supported
- scale-to-zero and drain coordination are intended behaviors
- `/learn` and `/journey` are part of the self-improvement loop

Do not let an older plan overrule these unless the user explicitly wants legacy behavior preserved.

## Architecture Heuristics

### Prefer native over custom
Choose the simplest native Hermes / Docker / Linear path that meets the need.

Good:
- Hermetic Docker deployment
- Native Hermes release image pinned to the release tag
- Linear API integration for intake and comments
- Simple worker containers with shared execution identity

Avoid by default:
- Custom orchestration layers that duplicate Linear
- Complex identity-per-worker schemes when faceless workers are enough
- Local queues that become a second source of truth
- Over-engineered profile sprawl across dozens of identities

### Separate identity from execution
**When using Kanban + Profiles (the native method), there is no separation.** Each spawned worker **IS** a named actor with its own identity and credentials. Profiles execute under their own name with full audit trail.

This is intentional: accountability and identity matter. mai-architect's work appears as mai-architect's. If you need shared faceless execution nodes, use Method 2 (Linear-First Cron with a single shared worker identity) — but that trades both accountability and auto-scaling.

The 7-profile suite (mai-architect, laura-orchestrator, kai-validator, quinn-support, amelia-comms, neil-digital-twin, rai-ops) IS the identity model. Each profile spawns as a worker when assigned a task. No faceless nodes; each task is owned by a named actor who posts evidence under their own name.

### Design for expansion without redesign
If the user says the pool may grow, design the deployment so a 9-node baseline can expand cleanly to a larger pool later.

That means:
- stable naming conventions
- node lists or inventories that are easy to extend
- worker configuration that is templated, not hand-crafted per node
- no coupling that assumes the pool size is forever fixed

## Questioning Style

When the operating model is still being shaped, ask **one question at a time**.

This matters because:
- multi-part clarification grids trigger premature design commitments
- the user often wants the next highest-value decision, not a long menu
- it keeps the architecture converging instead of re-litigating the whole stack

Use one focused question until the next key decision is clear.

## Critical Rule: Always Use the Linear API

**When the user says ALL this detail is in Linear or just use GraphQL, they mean it literally.**

Do NOT:
- Speculate about workspace structure
- Design in abstract without seeing real workspace data
- Ask the user to describe structure when you can query it
- Continue designing in the next turn if you forgot the API token from a prior session

DO:
- Immediately request the Linear API token (save it to memory with explicit REMEMBER THIS)
- Query projects, issues, custom fields, team structure directly
- Base all architecture decisions on the REAL workspace organization
- Refer to actual issue hierarchies, labels, and patterns in the workspace
- Use the token proactively across future sessions (it is persistent memory)

This session: User said OMG... YOU ALREADY HAVE THE API - told you this at least 10 times.. use GraphQL + REMEMBER THIS!!!!! (emphatic). They had 1000+ issues across 3 projects (KOHD, Aardvark, EcoPUK), organized as epics→subtasks→skills. Entire architecture was different from speculative model until I queried Linear directly. **The workspace IS the source of truth, not your imagination.**

**Pitfall**: Designing delivery orchestration (Rai, dispatch, priorities, provisioning) without seeing the Linear project structure is a high-risk mistake. Always query first, design second.

## Linear Commenting Pattern

When the user wants actor-based comments in Linear:

- write comments in the voice of the right actor
- include the business meaning of the update
- capture real blockers explicitly
- include evidence links or validation outputs when available
- distinguish approval, clarification, escalation, and completion comments
- for start-of-work situations, pair the comment with the native dispatch signal and kickoff child issue so the lead can actually act in Linear

A good comment should make the issue state legible without needing the chat thread.

## Standup / Blocker Escalation Pattern

When the user wants blockers raised via Telegram daily standup:

- keep the standup short and action-oriented
- only escalate what the user actually needs to unblock
- include the issue identifier, blocker type, and next action
- do not bury urgent blockers in a long progress recap

## Common Pitfalls

1. **Assuming the older V3 architecture is still authoritative.**
   Check the latest release behavior first.

2. **Turning workers into identity-heavy actors.**
   Shared faceless execution nodes are usually better when the work is mechanical and repeatable.

3. **Creating a second work-tracking system.**
   If Linear is the source of truth, keep it that way.

4. **Marking work done without evidence.**
   The finish line is business validation, not just successful execution.

5. **Asking too many questions at once.**
   Ask the single decision that unlocks the next design step.

6. **Assuming Kanban does skill-based load-balancing between profiles with the same skill.**
   **It does not.** Kanban assigns to profile names only (`assignee="jane-designer"`). If you have 2+ profiles with the same skill, Rai must implement the routing logic (query capacity, pick least-loaded, assign explicitly). See `references/kanban-native-limitations-v0.18.0.md` for the full native vs. custom boundary.

## Verification Checklist

- [ ] Linear remains the source of truth
- [ ] Control-plane actors are only named where identity matters
- [ ] Worker nodes remain faceless shared execution nodes
- [ ] Comments and blockers are written back to Linear
## Reference Material

See `references/kanban-dispatch-native-pattern.md` for the authoritative Hermes Kanban + Profiles dispatch architecture: the three layers, identity model, dispatcher behavior, and integration recipe. Answers the hybrid vs faceless question definitively.

**NEW (2026-07-03, CRITICAL BLOCKER RESOLVED):** See `references/linear-licensing-blocker-kanban-only-solution.md` for Enterprise Linear licensing blocker and the kanban-only solution. Every Linear assignee = 1 paid seat (cost-prohibitive for 80+ profiles). Solution: Kanban task assignee only (profile names, not Linear seats) + Team Leads as OAuth actors for comments. Includes field allowlist for excluding Linear assignee mutations, audit trail pattern (dual-layer: Linear + Kanban), and cost model. **This unblocks the entire 1000+ issue, multi-project architecture.**

**NEW (2026-07-03, RAI WORKFLOW COORDINATOR):** See `references/rai-workflow-coordinator-pattern.md` for Rai dispatcher cron design. Rai is NOT a single API request; it is a mini workflow coordinator running every 60s with three phases: intake (Linear query), dispatch (route + kanban create), completion detection (kanban done → Linear update). Includes full pseudo-code, load-balancing logic, heartbeat sync, metadata flow, and edge case handling. Ready for implementation as a Hermes skill.

**NEW (Kanban Dashboard UI - UNVERIFIED):** See `references/rai-workflow-coordinator-pattern.md` § Kanban Dashboard UI for open question: Does Hermes v0.18.0 provide native web UI for manual kanban task creation? Affects whether humans can bypass Rai automation for urgent work.

See `references/kanban-native-limitations-v0.18.0.md` for the hard boundary between NATIVE Kanban capabilities and YOUR responsibility (Rai). Clarifies that Kanban assigns to **profile names only**, NOT skills, and does NOT auto-load-balance between profiles with the same skill. Explains Option A (Rai custom routing logic), Option B (decomposer), and Option C (hybrid). Includes the unresolved Linear licensing blocker for 80-profile scaling. **Now resolved via kanban-only solution (see above).**

**NEW (KOHD Pattern)**: See `references/linear-first-cron-pattern.md` for the LINEAR-FIRST async dispatch pattern used in KOHD: profiles as always-on Linear watchers, cron-based detection, async Telegram approval gates, evidence in Linear comments. Use this when the user needs human approval between stages and evidence must live in Linear (not Kanban separate). Full club-signup-to-live example included.

**NEW (KOHD Schema)**: See `references/kohd-linear-schema.md` for the complete KOHD ADF Linear workspace schema including status workflow, custom fields, tags, issue templates, evidence format, OAuth setup, and audit trail rules. Use this to set up the workspace and ensure all profiles follow the same structure.

See `references/linear-dispatch-architecture.md` for session-specific decisions, release-alignment notes, and current open topology choices.

See `references/native-dispatch-start-signal.md` for the KOHD native dispatch pattern: visible start signal, kickoff child issue, and what counts as actually underway.

**NEW (Project-Scoped Delivery Model, 2026-07-03)**: See `references/project-scoped-delivery-model.md` for the critical distinction between **generic task dispatch** and **project-scoped epic delivery**. The KOHD workspace is organized as epics (KS-2999 Programme Control 29 subtasks, KS-3048 Platform Readiness 9 subtasks) not random issues. Laura is the sprint orchestrator deciding which epic to deliver; Rai reads Laura's signal, dispatches only that epic's issues by skill, orchestrates parallel execution, and triggers deploy at epic boundaries. Includes Rai implementation pattern, skill induction strategy, Laura's role, unattended execution (24/7), and open questions before Rai cron implementation.

**NEW (KOHD Workspace Discovery, 2026-07-03)**: See `references/kohd-workspace-discovery-2026-07-03.md` for the live Linear workspace structure as discovered via GraphQL. Includes teams, 50+ projects, the KOHD Heritage project (61 issues, 2 main epics), custom field recommendations, status workflow, and sample GraphQL queries for discovery. Use this as the baseline reference for all KOHD architecture decisions. Update after significant Linear schema changes.

**NEW (Team-Centric Routing)**: See `references/team-centric-routing-linear-custom-fields.md` for scaling Kanban + Profiles dispatch to 80+ profiles via 8–10 team abstractions. Uses Linear custom fields (`assigned_team`, `assigned_node`) as routing source, Rai as custom field poller, and team-level accountability for audit. Blocker unblocked: Linear custom fields are CONFIRMED supported (GraphQL `issueFields` API + UI). Ready for Rai cron implementation.

