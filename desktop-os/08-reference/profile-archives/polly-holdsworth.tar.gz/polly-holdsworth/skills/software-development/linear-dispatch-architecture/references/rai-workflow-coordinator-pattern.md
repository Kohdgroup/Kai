# Rai Dispatcher Cron: Workflow Coordinator Pattern (2026-07-03)

## What Rai Actually Does

**Rai is NOT a single API request. It is a MINI WORKFLOW COORDINATOR that runs every 60 seconds.**

Each cycle (60s):

```
Phase 1: INTAKE
├─ Query Linear: GET all issues with Status="Ready for dispatch"
├─ Log count: "Found N ready issues"
└─ Continue...

Phase 2: ROUTE & DISPATCH (for each ready issue)
├─ Read custom field: Business Unit = "Design" | "Marketing" | "Eng"
├─ Query kanban.db: SELECT profiles WHERE skill MATCHES business_unit AND heartbeat < 1h
├─ Query kanban.db: SELECT COUNT(*) per profile WHERE assignee="jane-designer" AND status="running"
├─ Load-balance: Find least-loaded profile = min(running_count)
├─ kanban_create(assignee=least_loaded, title=issue.title, body=issue.description, metadata={"linear_issue_id": issue.id})
├─ Linear comment (as Rai): "Dispatched to jane-designer on {timestamp}"
└─ Mark Linear issue as Status="Assigned" (optional, for visibility)

Phase 3: COMPLETION DETECTION
├─ Query kanban.db: SELECT tasks WHERE status="done" AND updated > 1min_ago
├─ FOR each completed task:
│  ├─ Retrieve metadata: linear_issue_id, executor, summary
│  ├─ Linear mutation: state="Done", clear any temporary fields
│  ├─ Linear comment (as Team Lead OAuth actor): "Done. Summary: {result}"
│  └─ kanban task → archived
└─ Continue to next cycle

Sleep 60s → repeat
```

## Why It's a Workflow, Not a Single API Call

1. **Multi-phase coordination**: Takes Linear data, transforms via capacity logic, coordinates with Kanban dispatcher, monitors completion, writes back to Linear. Each phase depends on prior phase output.

2. **State machines**: Tasks move through states (Ready → Assigned → Running → Done → Closed in Linear; ready → claimed → running → done in Kanban). Rai watches both state machines and synchronizes them.

3. **Continuous polling**: Runs forever every 60 seconds. Not triggered once; continuously monitors.

4. **Resilience logic** (not shown above, but implicit):
   - If kanban_create fails → log error, don't advance Linear status
   - If Linear query times out → skip that cycle, try next 60s
   - If profile heartbeat stale (>1h no signal) → don't dispatch new work to it; mark as unavailable

## Implementation Shape

```python
# Rai cron job (ONE cron, not decomposed into child tasks)
def rai_dispatch_cycle():
    # Phase 1
    try:
        ready_issues = query_linear("status='Ready for dispatch'")
    except LinearAPIError as e:
        log.error(f"Linear query failed: {e}. Skipping cycle.")
        return

    # Phase 2
    for issue in ready_issues:
        biz_unit = issue.custom_fields["Business Unit"]
        
        # Query kanban capacity
        profiles = query_kanban(f"skill='{biz_unit}' AND heartbeat < 1h")
        if not profiles:
            log.warn(f"No available profiles for {biz_unit}. Skipping {issue.id}.")
            continue
        
        least_loaded = find_least_loaded(profiles)
        
        # Create kanban task
        task = kanban_create(
            assignee=least_loaded,
            title=issue.title,
            body=issue.description,
            metadata={"linear_issue_id": issue.id}
        )
        
        # Update Linear with dispatch signal
        linear_comment(issue.id, f"Dispatched to {least_loaded} on {now()}")
    
    # Phase 3
    done_tasks = query_kanban("status='done' AND updated > 1min_ago")
    for task in done_tasks:
        linear_issue = get_linear_issue(task.metadata["linear_issue_id"])
        update_linear(linear_issue.id, state="Done", summary=task.summary)
        kanban_archive(task.id)

# Schedule this ONE cron to run forever every 60s
cronjob(schedule="every 1m", action=rai_dispatch_cycle, deliver="origin")
```

## Kanban Dashboard UI (UNVERIFIED)

**Question**: Does Hermes v0.18.0 provide a native web dashboard for manually creating/viewing kanban tasks?

**Current status**: Not yet verified in this session. User asked "what is the native approach for kanban as you can just call up dashboard and manually create an entry?"

**If YES (dashboard exists):**
- Humans can manually create kanban tasks without Rai automation
- Manual entry would show in dispatcher's queue (status=ready, waiting for profile to claim)
- Useful for ad-hoc work or urgent requests

**If NO (no dashboard):**
- All kanban entry must be programmatic (Rai creates tasks)
- Humans interact via Linear UI only (create issue, set Status=Ready, Rai does the rest)

**Next step**: Check Hermes v0.18.0 docs or test in session to confirm.

## Load-Balancing Logic: Least-Loaded Profile

**Rai's capacity query:**

```sql
SELECT assignee, COUNT(*) as running_count 
FROM kanban_tasks 
WHERE assignee LIKE '%designer' 
  AND status='running'
GROUP BY assignee
ORDER BY running_count ASC
```

**Example result:**
```
freddy-designer: 3 tasks (max_concurrent=3, at capacity)
jane-designer:   1 task  (max_concurrent=3, 2 slots free) ← PICK THIS
alex-designer:   0 tasks (max_concurrent=3, 3 slots free)
```

**Rai's decision**: Assign to jane-designer (least-loaded among available).

**Fallback**: If jane hits max_concurrent during task execution, her next heartbeat will fail, and Rai won't dispatch new work until her count drops.

## Heartbeat Synchronization

Profiles call `kanban_heartbeat()` hourly (or more frequently during long work):

```python
# In profile's task execution loop:
while task_in_progress:
    do_work()
    if time_since_last_heartbeat() > 30min:
        kanban_heartbeat(note=f"Executing {task.title}, {progress}% done")
```

**What Hermes dispatcher does with heartbeat:**
- Records timestamp in kanban.db: `task.last_heartbeat = now()`
- If task running + no heartbeat for 4h+ → dispatcher reclaims task, marks as "stale", back to ready
- Rai sees task back in ready state, re-dispatches (possibly to different profile)

**This is 100% native v0.18.0 behavior.** Profiles don't need to do anything special; just call the tool regularly.

## Metadata Flow: Linear ↔ Kanban ↔ Execution

**When Rai creates kanban task:**

```python
kanban_create(
    assignee="jane-designer",
    title="Build payment API",
    body="Stripe integration endpoint for recurring billing",
    metadata={
        "linear_issue_id": "ENG-427",
        "business_unit": "Engineering",
        "dispatch_time": "2026-07-03T15:00:00Z"
    }
)
```

**When profile executes:**

```python
task = kanban_show()
print(f"Linear issue: {task.metadata['linear_issue_id']}")
print(f"Business unit: {task.metadata['business_unit']}")

# Execute work...
kanban_comment("jane-designer", "Draft implementation in #branch-payment-api")

kanban_complete(
    summary="Stripe webhook endpoint live. Tests: 15/15 passing. Ready for QA.",
    metadata={
        "executor": "jane-designer",
        "node": "node-06",
        "execution_time": "27 minutes",
        "branch": "feature/stripe-webhook"
    }
)
```

**When Rai detects completion:**

```python
task = query_kanban("id='t_abcd'")
linear_issue_id = task.metadata["linear_issue_id"]
executor = task.metadata["executor"]

update_linear(
    linear_issue_id,
    state="Done",
    comment=f"Done by {executor}. Summary: {task.summary}"
)
```

**Audit trail is complete**: Linear has the issue state + team comment, Kanban has execution detail.

## Edge Cases & Error Handling

### Dispatched but profile never claimed

```
Scenario: Rai dispatches task to jane-designer, but jane's node is down
Status: Task sits in kanban.db as status=ready, assignee=jane-designer
Rai detects: No heartbeat from jane after 1h
Action: Rai re-queries capacity, picks different profile, creates NEW kanban task
Result: Original task never runs; new task replaces it
```

**Better approach**: Rai should check profile liveness (heartbeat < 30min) before dispatching, not after.

### Kanban task completes but Linear is unreachable

```
Scenario: Profile finishes work, calls kanban_complete(), but Linear API is down
Status: Task in kanban.db as status=done, waiting for Rai acknowledgment
Rai's next cycle: Detects done task, retries Linear update 3 times, then logs alert
Result: Task stays done in Kanban; Linear issue stays in prior state (Assigned)
```

**Recovery**: Human manually updates Linear, or retry next cycle if Linear recovers.

### Rai crashes mid-cycle

```
Scenario: Rai process dies after dispatching 5 tasks but before completion detection
Status: 5 tasks in kanban.db as status=ready+claimed, waiting for execution
Next Rai restart: See 5 tasks already claimed, pick up completion detection
Result: No duplicate dispatch, no lost work
```

**Resilience**: Kanban dispatcher is atomic per task. Rai crashing doesn't break the queue.
