# Autonomous Dispatch Framework — Linear Schema Design

**Session**: 2026-07-03 KOHD Implementation  
**Approach**: Design automation schema by analyzing actual backlog structure, then fit profiles to patterns

## Core Principle

**Before automating, understand the actual work patterns.**

Don't invent a workflow. Query Linear, count statuses/teams/priorities, discover the real transitions, then design routing rules that match reality.

## Analysis Phase

### What to Extract

From backlog, find:
1. **Team breakdown** — How many teams? Which are urgent (CD_Client_Delivery)?
2. **Status workflow** — What statuses do issues actually use? (Backlog → Triage → Todo → In Progress → Done?)
3. **Priority distribution** — Is everything urgent or is there natural grouping?
4. **Work types** — Patterns in issue titles? (design, testing, communications, deployment)
5. **Bottlenecks** — Where do issues get stuck? (Triage queue? Approval gate?)

### Example Results (KOHD)

```
Teams:
  CD_Client_Delivery (urgent):     3 projects, 3-5 active issues
  KS_Kohd_Systems (general):       55 projects, 100+ issues
  BIZOPS:                           8 issues (orchestration)
  MBLK:                             8 issues (master backlog, Triage)
  ARC:                              9 issues (governance)

Status Workflow:
  Backlog → Triage → Todo → In Progress → Done
  
  Key observation: Triage is the routing gate
  (Laura watches here, decides next step)

Work Types:
  • Architecture/Design (WS01-WS05, etc.) → mai-architect
  • Testing/Validation → kai-validator
  • Communications/Marketing → amelia-comms
  • Support/Triage → quinn-support
  • Deployment/Ops → rai-ops
```

## Design Phase

### Step 1: Define Status Workflow

**Based on actual statuses found in backlog:**

```
Backlog
  Definition: Planning phase, not yet assigned work
  Who watches: Laura (orchestrator)
  Action: Triage & route to appropriate profile
  
Triage
  Definition: Laura has reviewed, decided routing
  Who watches: Target profile
  Action: Accept assignment, move to Todo
  
Todo
  Definition: Ready for execution
  Who watches: Assigned profile
  Action: Execute, post evidence
  
In Progress
  Definition: Work is active
  Who watches: Profile executing, then next phase
  
Ready for Review
  Definition: Execution complete, waiting for validation
  Who watches: Next profile (e.g., kai-validator)
  
Ready for Approval
  Definition: Validated, waiting for Neil decision
  Who watches: Laura (posts Telegram)
  
Ready for Deployment
  Definition: Approved, ready for operations
  Who watches: rai-ops
  
Deployed / Done
  Definition: Complete
```

### Step 2: Define Routing Rules

**Each profile watches for its specific signals:**

```
Laura (every 2 min):
  Watch: Status in (Backlog, Triage, Ready for Review)
         AND Assignee = laura-orchestrator
  Action:
    • Parse issue tags (#architecture, #testing, #comms, etc.)
    • Route to appropriate profile
    • Update Status → Todo
    • Update Assignee → [profile]
    • Post routing comment
    
Mai (every 5 min):
  Watch: Assignee = mai-architect
         AND Status = Todo
  Action:
    • Execute design/architecture task
    • Update Status → In Progress
    • Post evidence comment
    • When done: Status → Ready for Review, Assignee → [next]
    
Kai (every 5 min):
  Watch: Assignee = kai-validator
         AND Status in (Todo, Ready for Review)
  Action:
    • Test/validate work
    • Post results comment
    • When done: Status → Ready for Approval, Assignee → [next]
    
Amelia (every 10 min):
  Watch: Assignee = amelia-comms
         AND Status = Todo
  Action:
    • Send emails via Himalaya
    • Post confirmation comment
    • Status → Done
    
Rai (every 5 min, Control Plane):
  Watch: Status = Ready for Deployment
  Action:
    • Run smoke tests
    • Post verification comment
    • Status → Deployed / Done
```

### Step 3: Define Evidence Format

**Every profile posts structured JSON in Linear comments:**

```json
{
  "actor": "mai-architect",
  "timestamp": "2026-07-03T10:50:00Z",
  "action": "DESIGN_COMPLETE",
  "issue": "KS-3047.1",
  "task": "Website Structure & Copy",
  
  "evidence": {
    "deliverable": "Wireframes + copy deck",
    "location": "wiki/kohd-heritage/website-structure",
    "quality": "draft",
    "details": "1200 words, SEO optimized"
  },
  
  "next_step": "Review by kai-validator",
  "next_assignee": "kai-validator",
  "status": "READY_FOR_REVIEW"
}
```

This evidence:
- Is machine-parseable (for reporting)
- Is human-readable (for audit)
- Captures proof of work (not just claims)
- Enables Laura's next decision (clear next_step)

### Step 4: Define Neil's Approval Gates

**When work is Ready for Approval:**

1. Laura detects signal in Linear
2. Laura posts Telegram to Neil (async):
   ```
   🟡 APPROVAL: Website Structure & Copy
   Completed by: mai-architect
   Validated by: kai-validator
   Evidence: Wireframes + copy in wiki
   
   Ready to deploy? YES / NO
   ```

3. Neil replies (on phone, any time):
   ```
   YES
   ```

4. Laura detects Telegram reply (polls Telegram API):
   ```
   Update Linear: Status → Approved, Assignee → rai-ops
   Post comment: "✅ Approved by neil-digital-twin"
   ```

5. Rai detects Ready for Deployment → executes

**Full cycle: 15-30 min while Neil was away**

### Step 5: Define Custom Fields (Optional but Recommended)

```
Linear Custom Fields:

Phase              [string]   — e.g., "KOHD-Heritage-WS05"
Club-ID            [string]   — for club-specific work
Onboarding-Status  [select]   — NEW / IN_PROGRESS / COMPLETE / BLOCKED
Evidence-Quality   [select]   — PENDING / DRAFT / VERIFIED / COMPLETE
Approval-Status    [select]   — PENDING / APPROVED / REVISION-NEEDED
Content-Type       [string]   — "design", "email", "test", etc.
Platform           [string]   — "ghl", "himalaya", "hermes", etc.
```

These enable:
- Quick filtering in Linear UI
- Structured data for automation routing
- Evidence quality tracking

### Step 6: Define Tags (Standardized)

```
Work Type:
  #architecture, #testing, #support, #comms, #deployment, #documentation

Status (parallel to Status field):
  #routed, #ready-for-review, #ready-for-approval, #blocking

Platform:
  #platform-ghl, #platform-himalaya, #platform-linear, #platform-hermes

Priority:
  #cd-delivery (urgent), #high, #medium, #low

Team:
  #team-cd, #team-ks, #team-bizops
```

## Implementation Pattern

**This is the order to implement:**

1. **Create custom fields** in Linear (if using them)
2. **Create tags** in Linear workspace
3. **Configure profiles' Linear tokens** (.env)
4. **Deploy profiles** to target machines
5. **Configure each profile's cron queries** (exact LinkedIn filters)
6. **Test with 1 real issue** (end-to-end: Neil → Laura → Mai → Kai → Neil approval → Rai → Done)
7. **Monitor logs** first 24 hours
8. **Tune cron intervals** if needed (e.g., Amelia 10 min is too frequent → 15 min)

## Pitfalls

### Pitfall 1: Workflow Doesn't Match Reality

**Problem**: You design Status: NEW → DESIGN → TEST → DEPLOY, but actual backlog uses: Backlog → Triage → Todo → Done (no explicit DESIGN/TEST states).

**Fix**: Query backlog first. Use the statuses that actually exist. Work within constraints.

### Pitfall 2: Laura Becomes a Bottleneck

**Problem**: Laura checks every 2 min but routing takes 10 min of work. Queue backs up.

**Fix**: Make Laura's job mechanical:
- Simple tag-based routing: if #design → mai, if #test → kai (no judgment)
- If judgment needed, post to Linear for human review, don't block cron

### Pitfall 3: Evidence is Too Verbose

**Problem**: Profiles post 500-word comments, Laura's Telegram is unreadable.

**Fix**: Keep evidence JSON compact. Link to wiki for details. Telegram summary must be <100 words.

### Pitfall 4: Profile Duplication

**Problem**: Two profiles think they should handle the same task. Or work falls through the cracks.

**Fix**: Be explicit. In Linear, every issue must have exactly one profile tag:
- If no tag → Laura assigns #unrouted
- If multiple tags → Laura posts "Clarify routing"
- If unassigned after 4 hours → Escalate to Neil

### Pitfall 5: Forgetting Rai's Ops Loop

**Problem**: Deployment is manual. Profile completes work but no one deploys.

**Fix**: Make Rai's signal explicit:
- When Ready for Deployment: Assignee = rai-ops, Tag = #ready-for-deployment
- Rai runs every 5 min (no human needed)
- Rai posts evidence (smoke tests, verification)
- Status → Deployed automatically

## Testing the Schema

**Before going live, test with 1 real issue:**

```
1. Neil creates in Linear: "Test blog post for club signup" (Backlog status)
2. Wait 2 min → Laura routes to amelia-comms (Tag #comms)
3. Wait 5 min → Amelia executes, posts evidence
4. Wait 2 min → Laura detects completion, posts to Neil's Telegram
5. Neil replies YES on phone
6. Wait 2 min → Laura updates Linear (Status → Approved)
7. Wait 5 min → Rai detects Ready for Deployment, runs tests
8. Rai posts verification, Status → Done

Total time: 15 minutes
Audit trail: Complete in Linear comments
```

If this works, scale to 10 issues. If failures appear, fix them before going full deployment.

## Variations by Backlog Size

**Small backlog (< 50 issues):**
- Laura every 5 min (instead of 2)
- Executors every 10 min (instead of 5)
- Manual review of routing rules

**Large backlog (> 200 issues):**
- Laura every 1 min (aggressive routing)
- Multiple instances of Laura/Mai (parallel executors)
- Webhook for immediate signal (GHL → Linear → Laura)

**Mixed urgent + general:**
- CD_Client_Delivery issues: Laura every 1 min, priority routing
- KS_Kohd_Systems issues: Laura every 5 min, standard routing
- Use Linear Cycle/Milestone to segment

## See Also

- `linear-api-integration` — How to query Linear for backlog analysis
- `hermes-profiles` — Profile creation and deployment
