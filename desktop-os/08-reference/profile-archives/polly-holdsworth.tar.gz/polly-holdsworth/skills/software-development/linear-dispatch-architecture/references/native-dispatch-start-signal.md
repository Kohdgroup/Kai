# Native Dispatch Start Signal (KOHD session note)

This note captures the session-specific native Linear dispatch pattern used for KOHD.

## Pattern
- Create a visible **start signal** issue in Linear.
- Subscribe the intended delivery lead (Laura) to that issue.
- Create a first **actionable kickoff child issue** under the start signal.
- Keep the platform registry, solution blueprint, platform matrix, and operating-model index as the source artifacts.
- Consider the work **started** only when a Laura-authored action trail appears in Linear.

## What counts as a visible start trail
At least one of:
- Laura-authored update on the kickoff issue
- assignee or state change on the kickoff issue
- child issue breakdown created by Laura
- Laura’s first sprint-cut update or handoff note

## Why it can stall
- Subscription alone is not operational ownership.
- A start signal without a child kickoff issue is too weak.
- Review lanes and execution lanes must stay separate.
- If the Linear write scope is limited, the action trail may not be writable even if the signal exists.

## KOHD examples
- `BIZOPS-105` — official start signal
- `BIZOPS-106` — first actionable kickoff child issue

## Reuse
Use this note as the default native-dispatch pattern when a future project needs Laura to begin from Linear without a bespoke automation bridge.
