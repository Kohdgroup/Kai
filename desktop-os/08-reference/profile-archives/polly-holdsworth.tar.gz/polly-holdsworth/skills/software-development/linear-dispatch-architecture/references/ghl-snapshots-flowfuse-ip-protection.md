# GHL Snapshots + FlowFuse IP Protection Architecture

**Session**: 2026-07-03  
**Topic**: How GHL Snapshots enable repeatable deployment while FlowFuse Node-RED flows hide proprietary logic from customers.

---

## The Firewall Model

```
WHAT CUSTOMERS OWN & SEE:
├─ GHL Sub-Account
│  ├─ Forms (Story Capture, Tile Order, Sponsor Signup — editable by club)
│  ├─ Custom Objects (stories, tiles, sponsors — club owns data)
│  ├─ Contacts/Households (club member data)
│  ├─ Automations (email sequences, reminders — visible, editable)
│  ├─ Dashboard (club sees their analytics, member list, revenue)
│  └─ Webhooks (club knows when data leaves, sees payload shape)

WHAT CUSTOMERS DO NOT SEE (YOUR IP):
├─ FlowFuse Node-RED Flows
│  ├─ Form submission routing logic
│  ├─ Data transformation (tile order → inventory check → revenue calc)
│  ├─ Validation rules (KOHD-specific business logic)
│  ├─ Multi-tenant coordination (tenant_id extraction, schema routing)
│  ├─ Affiliate/revenue split calculation
│  ├─ Sponsor tier logic
│  └─ Integration orchestration
├─ MariaDB Schema
│  └─ Club only trusts webhook outputs; never sees database directly
└─ Deployment Automation
    └─ Rai, profiles, orchestration — invisible to club
```

---

## GHL Snapshots: Repeatable SaaS Deployment

### What Is a Snapshot?

A **snapshot** is a pre-configured GHL sub-account template that can be cloned/deployed instantly to new customers. Contains:

- Forms (schema, fields, labels, validation rules)
- Custom objects (stories, tiles, sponsors, with fields)
- Drop-down options, default values
- Automation triggers (on form submit, etc.)
- Email templates
- API permissions and scopes

**Key**: Snapshots are stored in the **parent GHL account**. When a new customer signs up, Rai calls the GHL API to:
1. Create a new sub-account (owned by the parent organization)
2. Deploy the snapshot to that sub-account
3. Customize fields (club name, domain, etc.)
4. Register webhook endpoint

The customer typically gets **read-write access to the sub-account** (can edit forms, manage contacts). They do NOT see the parent account or the snapshot source.

---

## Implementation: Per-Project Snapshots

### KOHD Heritage Snapshot

**Created Once** (manually, via GHL UI or API):

```
Snapshot ID: kohd-heritage-snapshot-v1

Forms:
├─ Story Capture Form
│  ├─ Fields: story_title, person_name, era, body, media_upload
│  ├─ Custom object: stories
│  └─ On submit → webhook to flowfuse.kohd.io/webhook
├─ Tile Order Form
│  ├─ Fields: purchaser_name, tile_type, copy_text, tile_recipient
│  ├─ Custom object: tiles
│  └─ On submit → webhook
└─ Sponsor Signup Form
    ├─ Fields: sponsor_name, package_tier, start_date
    ├─ Custom object: sponsors
    └─ On submit → webhook

Custom Objects:
├─ stories (text, media_url, tile_link, sponsor_link)
├─ tiles (tile_type, purchaser, recipient, copy, panel_position, status)
└─ sponsors (name, tier, renewal_date, deliverables_checklist)

Automations:
├─ On story submission → send confirmation email
├─ On tile order → send payment instruction
└─ On sponsor signup → send package details
```

**Deployed MANY Times** (one per new club):

```
Rai API call:

POST https://api.gohighlevel.com/v1/locations/provision

{
  "parent_account_id": "kohd-org-id",
  "snapshot_id": "kohd-heritage-snapshot-v1",
  "new_location": {
    "name": "Lancashire Bulls KOHD Club",
    "email": "webmaster@lancshirebulls.co.uk"
  },
  "customizations": {
    "story_capture_form": {
      "title": "Lancashire Bulls Heritage Stories",
      "description": "Share club memories and build our heritage archive"
    },
    "club_name_field": "Lancashire Bulls",
    "club_domain": "lancashire-bulls.kohd.io"
  }
}

Response:

{
  "location_id": "loc_xyz123",
  "location_name": "Lancashire Bulls",
  "dashboard_url": "https://loc_xyz123.gohighlevel.com",
  "api_key": "ghl-key-xyz123",  ← Stored in Rai vault
  "webhook_endpoint": "https://api.gohighlevel.com/v1/locations/loc_xyz123/webhook"
}
```

**Result**: Lancashire Bulls now has a GHL sub-account with all KOHD Heritage forms pre-configured. No manual form design needed.

---

## EcoPUK & Aardvark: Separate Snapshots

Each project gets its own snapshot (because their business logic differs):

```
ECOPUK:
├─ Snapshot ID: ecopuk-snapshot-v1
├─ Forms: Quote request, project scope, timeline, deliverables
├─ Custom objects: projects, quotes, contracts
└─ Deployed: Once (1 customer, 1 sub-account)
    └─ Can later expand to multiple EcoPUK clients if needed (add new tenant_id to MariaDB)

AARDVARK:
├─ Snapshot ID: aardvark-snapshot-v1
├─ Forms: (project-specific)
├─ Custom objects: (project-specific)
└─ Deployed: Once (1 customer, 1 sub-account)
```

---

## FlowFuse Node-RED: The Hidden Logic Engine

### Architecture

```
PRODUCTION:

GHL Sub-Account (club sees this)
    ↓ (on form submit)
    ↓ webhook POST: { ghl_data: {...}, X-Tenant-ID: "uuid-club-001" }
    ↓
FlowFuse Node-RED (your IP, club does NOT see)
    ├─ Node: Extract X-Tenant-ID from headers
    ├─ Node: Lookup MariaDB schema from tenant_lookup table
    ├─ Node: Route to "story-capture-transform" flow (or tile-order-process, etc.)
    ├─ Node: Apply KOHD business logic
    │  ├─ Validate tile copy (length, profanity filter, brand guidelines)
    │  ├─ Calculate revenue split (club gets 70%, KOHD gets 30%)
    │  ├─ Assign sponsor tier based on spend
    │  ├─ Flag duplicate stories (Levenshtein distance)
    │  └─ Generate attribution string for social media
    ├─ Node: INSERT into MariaDB kohd_lancashire_bulls.stories
    └─ Node: (Optional) Send confirmation back to GHL or email
    ↓
MariaDB
    ├─ Table: kohd_lancashire_bulls.stories
    ├─ Table: kohd_lancashire_bulls.tiles
    ├─ Table: kohd_lancashire_bulls.sponsors
    └─ Club never accesses directly; only trusts webhook result
```

### Single Instance, Reusable Flows

```
ONE Node-RED runtime per project (not per club):

KOHD FlowFuse instance:
├─ Reusable flows (parameterized by tenant_id):
│  ├─ flow: "ghl-webhook-handler"
│  │  - Receives webhook with X-Tenant-ID header
│  │  - Routes to correct downstream flow based on form_type
│  │
│  ├─ flow: "story-capture-transform"
│  │  - Input: { title, body, person_name, era, media_url }
│  │  - Apply KOHD logic: validate, flag duplicates, generate metadata
│  │  - Output: { story_record, ready_to_insert }
│  │  - Lookup MariaDB schema for tenant_id
│  │  - INSERT
│  │
│  ├─ flow: "tile-order-processor"
│  │  - Input: { purchaser, tile_type, copy, recipient }
│  │  - Calculate revenue split, assign tier
│  │  - Inventory check (has panel space?)
│  │  - Send payment link to GHL API (update contact)
│  │  - INSERT
│  │
│  ├─ flow: "sunday-stats-sync"
│  │  - Runs on schedule (every Sunday 09:00)
│  │  - For each tenant_id:
│  │    ├─ Call external API (club sports stats endpoint)
│  │    ├─ Transform + validate
│  │    ├─ INSERT into stats_log
│  │    └─ Send summary email
│  │
│  └─ ... (more flows)
│
└─ Environment:
   ├─ FLOWFUSE_INSTANCE_NAME: "kohd-production"
   ├─ FLOWFUSE_TENANT_LOOKUP_DB: "mysql://..."
   ├─ FLOWFUSE_TENANT_ISOLATION: true
   ├─ FLOWFUSE_LOG_LEVEL: "info"
   └─ Each flow accesses tenant_id from webhook headers
```

### Multi-Tenancy via Parameterization

```
When webhook arrives for Lancashire Bulls:

1. Node-RED receives:
   POST https://flowfuse.kohd.io/webhook
   {
     "form_type": "story",
     "ghl_data": {
       "title": "First Match",
       "person_name": "John Smith",
       "body": "...",
       "media_url": "..."
     }
   }
   Headers: { "X-Tenant-ID": "uuid-club-001" }

2. Node: Extract tenant_id
   ├─ Extract from header: uuid-club-001
   └─ Lookup in tenant_lookup table:
      ├─ SELECT mariadb_schema, ghl_location_id, project
      │ WHERE tenant_id = "uuid-club-001"
      └─ Returns: { mariadb_schema: "kohd_lancashire_bulls", ... }

3. Node: Route to transform flow
   ├─ story-capture-transform flow
   ├─ Receives: { ghl_data, tenant_id, mariadb_schema }
   └─ Applies KOHD logic (hidden)

4. Node: INSERT into correct schema
   ├─ INSERT INTO kohd_lancashire_bulls.stories (title, person_name, body, ...)
   └─ No other club can see this data

Result:
├─ Club data lands in correct schema
├─ KOHD logic applied invisibly
├─ Club never sees the flows
└─ Club can't steal your revenue split logic or validation rules
```

---

## Credential Flow (GHL API Keys)

### Parent Account (Admin)

**Used by**: Rai (provisioning only)

```
ghl_parent_api_key: "ghl-admin-xyz..."

Permissions:
├─ Create sub-accounts
├─ Deploy snapshots
├─ Manage locations
├─ Read organization settings
└─ NOT: Create contacts, send emails (done by sub-account keys)
```

### Sub-Account (per club, KOHD only)

**Used by**: GHL API client (when Rai needs to read club data)

```
Each KOHD club gets unique key:
├─ kohd_club_001.ghl_api_key: "ghl-loc-xyz123..."
├─ kohd_club_002.ghl_api_key: "ghl-loc-abc456..."
└─ ... (stored encrypted in Rai vault)

Permissions (customer-specific):
├─ Read/write forms
├─ Read/write contacts
├─ Read automations
├─ Manage custom objects
└─ NOT: Create sub-accounts, deploy snapshots (parent account only)
```

### Node-RED (No GHL API calls)

**Used by**: FlowFuse flows (query webhook data only, no auth needed)

```
Node-RED listens for webhooks (inbound only).
Does NOT call GHL API.
Does NOT need GHL credentials.

Authentication:
├─ Webhook signature verification (GHL signs POST with secret)
├─ X-Tenant-ID header routing (trusted, comes from GHL)
└─ FlowFuse environment isolation (only KOHD flows on KOHD instance)
```

---

## Deployment Sequence (Full)

### Day 1: Create Snapshots (One-Time Setup)

```
Rai (or manual):
1. GHL UI: Design KOHD Heritage snapshot
   ├─ Create forms (Story, Tile, Sponsor)
   ├─ Configure custom objects + fields
   └─ Test with dummy sub-account
2. Export snapshot or save as template
3. Note snapshot_id: "kohd-heritage-snapshot-v1"
4. Repeat for EcoPUK, Aardvark (different snapshots)

Development:
1. FlowFuse: Build Node-RED flows
   ├─ story-capture-transform
   ├─ tile-order-processor
   ├─ sponsor-activation
   └─ sunday-stats-sync (recurring)
2. Test flows with tenant_id routing
3. Deploy to production FlowFuse instance

Database:
1. MariaDB: Create tenant_lookup table + schema templates
2. Deploy database initialization scripts
```

### Day 2+: Provision New Club (Repeatable, 15 min)

```
Customer fills GHL intake form → Webhook → Rai

Rai dispatch (automated, no human touch):

1. freddy-frontend (GHL provisioning)
   ├─ GHL API: Create sub-account + deploy snapshot
   ├─ Customize forms (club name, domain)
   └─ Result: Club now has GHL sub-account

2. kai-backend (MariaDB schema)
   ├─ Create schema kohd_<club>
   ├─ Load schema.sql
   ├─ Register tenant_id in tenant_lookup
   └─ Result: MariaDB ready

3. rai-sre (Networking + Webhook)
   ├─ Cloudflare: Create DNS
   ├─ Node-RED: Register tenant_id in lookup
   ├─ Test: form submit → webhook → data lands
   └─ Result: LIVE

Done. Club can now:
├─ Receive story submissions
├─ Process tile orders
├─ Activate sponsors
└─ See all their data in GHL + Heritage timeline website
```

---

## IP Protection Recap

| What | Where | Club Sees? | Your IP? |
|-----|-------|----------|---------|
| Forms | GHL | ✓ Yes (can edit) | ✗ No |
| Form data | GHL | ✓ Yes (owns data) | ✗ No |
| Webhook payload | Logs | ✓ Yes (optional) | ✗ No |
| Node-RED flows | FlowFuse | ✗ No | ✓ Yes (proprietary) |
| Transformation logic | Node-RED | ✗ No | ✓ Yes (hidden) |
| Revenue split | Node-RED | ✗ No | ✓ Yes (algorithm) |
| MariaDB schema | Reserved | ✗ No | ~ Partially (API contract only) |

**Result**: Club owns their data, sees their GHL interface, but cannot reverse-engineer your logic or steal your intellectual property.

---

## References

- See `references/multi-project-saas-provisioning-pattern.md` § Dispatch (Phase 1 freddy-frontend) for GHL API calls.
- See `references/kohd-canonical-description.xml` § go_high_level_model for the original IP protection requirements.
