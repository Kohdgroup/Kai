# KOHD ADF Linear Schema (v1.0)

## Purpose

This schema defines the Linear workspace structure for KOHD Club OS ADF (Architecture + Design + Framework) implementation projects. It is tied to the LINEAR-FIRST cron dispatch pattern and the three-tier Hermes orchestration model (Laptop + Desktop + Control Plane).

**Single Linear License**: One workspace, multiple OAuth actor identities (neil, laura, mai, kai, rai). No separate licenses per profile.

## Teams & Projects

**Team: KS_Kohd Systems**
- General KOHD backlog and platform work
- Lower urgency than Client Delivery

**Team: CD_Client Delivery**
- Active implementation projects for specific clients/use cases
- PRIORITY: Read this team first
- Urgent work; time-sensitive delivery

## Status Workflow

```
NEW
  └─ [Laura routes, all profiles read]
    └─ IN_PROGRESS
      └─ [Profiles work in parallel]
        └─ ONBOARDING_COMPLETE (all evidence collected)
          └─ AWAITING_APPROVAL (Laura posts to Telegram, Neil decides)
            └─ PUBLISHED (Neil approved, ready for deployment)
              └─ DEPLOYED (Rai verified live)
                └─ DONE
```

**Governance:**
- NEW → IN_PROGRESS: Laura only
- IN_PROGRESS → ONBOARDING_COMPLETE: Rai or automation (final profile finishes)
- ONBOARDING_COMPLETE → AWAITING_APPROVAL: Laura (posts Telegram for Neil)
- AWAITING_APPROVAL → PUBLISHED: Neil (via Telegram) → Neil's Digital Twin updates Linear
- PUBLISHED → DEPLOYED: Rai (final ops verification)
- DEPLOYED → DONE: Laura (cleanup/closure)

## Assignee Routing

```
neil-digital-twin
  - Your laptop profile
  - Reads: Issues after execution (approval stage)
  - Writes: Decisions, final approvals
  
laura-orchestrator
  - Desktop PC, Scrum Master role
  - Reads: All issues (NEW, IN_PROGRESS, AWAITING_APPROVAL)
  - Writes: Status transitions, routine assignments, Telegram posts
  - Cron: Every 2 minutes
  
mai-architect
  - Desktop PC, Platform architect
  - Reads: [Assigned to mai-architect]
  - Writes: Architecture decisions, design comments, content
  - Cron: Every 5 minutes
  
kai-validator
  - Desktop PC, QA/validation lead
  - Reads: [Assigned to kai-validator]
  - Writes: Validation evidence, test results
  - Cron: Every 5 minutes
  
rai-ops
  - Control Plane, Operations/deployment
  - Reads: [Tags contain ready-for-deployment] OR [Assigned to rai-ops]
  - Writes: Ops evidence, readiness checks, deployment confirmation
  - Cron: Every 5 minutes (Control Plane)
```

## Tags (Minimal Set, Orthogonal)

**Work Type:**
- `content-creation` — Mai runs blog-writing skill
- `architecture-review` — Mai evaluates design decisions
- `implementation` — Kai or Rai runs platform setup
- `testing` — Kai runs validation skill
- `deployment` — Rai runs ops checks

**Platform:**
- `platform-himalaya` — Email/comms integration
- `platform-gws` — Google Workspace integration
- `platform-ghl` — Go High Level integration
- `platform-flowfuse` — Flow runtime integration

**Status Signals:**
- `ready-for-deployment` — Rai detects this, runs checks
- `blocking` — Laura escalates to Telegram
- `urgent` — Priority marker (no automation)

**Club Scope (Multi-Tenant):**
- `club-{club_id}` — Or custom field below

## Custom Fields

**MANDATORY:**
- **Club ID** (text): Which club does this affect? (e.g., "5042")
- **Club Name** (text): Human-readable club name (e.g., "ABC Rugby Club")
- **GHL Account** (text): Which GHL sub-account? (e.g., "ghl_abc_rugby")
- **Onboarding Status** (select: Ready / In Progress / Complete)

**OPTIONAL (Nice-to-have):**
- **Phase** (select: Phase 1 / Phase 2 / Phase 3): Which rollout wave?
- **Risk Level** (select: Low / Medium / High): Business/technical risk
- **Evidence Status** (select: No Evidence / Partial / Full): Audit trail completeness

## Issue Templates

### Template: Club Signup

```
Title: "Onboarding - {Club Name}"

Description:
Club signup received from GHL form.

Club ID: {club_id}
Club Name: {club_name}
Owner: {owner_email}
GHL Account: {ghl_account}

Ready for: Welcome email, system validation, go-live verification

Acceptance Criteria:
- [ ] Welcome email sent to owner
- [ ] Spond + GHL integration validated
- [ ] Blog post created (if applicable)
- [ ] All systems verified live

---

Status: NEW (system will set)
Assignee: laura-orchestrator (system will set)
Club ID: {club_id}
```

### Template: Platform Integration

```
Title: "Platform Integration - {Platform Name}"

Description:
Set up {Platform} for KOHD ADF.

Platform: {platform_name}
Scope: {what_work}
Owner (Design): {mai}
Owner (Validation): {kai}
Owner (Deployment): {rai}

Acceptance Criteria:
- [ ] Architecture designed (Mai)
- [ ] Validation passed (Kai)
- [ ] Deployment verified (Rai)
- [ ] Evidence in comments

---

Status: TO_DO
Assignee: mai-architect (first stage)
Tags: platform-{platform_name}, architecture-review
```

## Evidence Comment Format

All profiles post comments in this format:

```
[PROFILE: {actor_name}]
[TIMESTAMP: {ISO8601}]
[ACTION: {what_skill_ran}]
[STATUS: ✅ or ❌]

{key_fields}: {values}
{key_fields}: {values}

Next: {what_happens_next}
```

**Parser extracts:**
- Profile (OAuth actor identity)
- Timestamp (for freshness check)
- Action (skill name)
- Status (pass/fail)
- Key-value pairs (varies by profile)

## Webhook Integration

**Trigger:** GHL form submission (club signup)

**Input:**
```json
{
  "club_id": "5042",
  "club_name": "ABC Rugby Club",
  "owner_email": "john@abcrugby.com",
  "ghl_account": "ghl_abc_rugby",
  "timestamp": "2026-07-03T10:05:00Z"
}
```

**Action:** Desktop PC webhook handler creates Linear issue

**Output:** KOHD-CLUB-5042 with Status=NEW, Assignee=laura-orchestrator

## Audit Trail Rules

**All decisions go to Linear:**
- Status changes = Laura writes comment
- Evidence = Profile posts structured comment
- Approvals = Neil's Digital Twin writes to Linear (after reading Telegram)
- Blockers = Laura escalates to Telegram, then posts resolution

**Telegram is approval gate only:**
- Not stored as source of truth
- Redirects back to Linear once decided
- Async (Neil can reply on phone without being at laptop)

## OAuth Tokens (Per-Profile Setup)

Each profile's `.env` file contains:

```
LINEAR_API_TOKEN={oauth_token_for_this_actor}
LINEAR_WORKSPACE_ID={workspace_id}
```

**Token creation:**
1. Go to Linear workspace settings → API
2. Create OAuth application per actor (neil, laura, mai, kai, rai)
3. Generate token for each
4. Store in respective profile's .env
5. Never commit .env to git (Hermes protects this)

## Verification Checklist

- [ ] Status workflow matches three-stage pattern above
- [ ] Assignee routing matches profile cron intervals
- [ ] All profiles have OAuth tokens in ~/.hermes/profiles/X/.env
- [ ] Evidence comments follow structured format
- [ ] Custom fields match team's data needs
- [ ] Tags are minimal and orthogonal (not duplicative)
- [ ] Issue templates cover main work types
- [ ] Webhook integration runs on Desktop PC (not Control Plane)
- [ ] Laura-orchestrator is only status-changer (except Rai DEPLOYED → DONE)
- [ ] Telegram approval gate posts from Laura, not auto-hidden
