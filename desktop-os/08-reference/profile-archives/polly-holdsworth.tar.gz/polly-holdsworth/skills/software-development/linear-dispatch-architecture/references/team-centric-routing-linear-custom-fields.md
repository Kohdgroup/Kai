# Team-Centric Routing with Linear Custom Fields

## Validation Status (2026-07-03)

**CONFIRMED**: Linear supports custom fields for team-based task routing.

### Evidence
- Linear GraphQL API: `issueFields(first: N)` query returns all custom fields with `isCustom: boolean` flag
- Accessible via: Linear UI (Issue Properties section in workspace settings) + GraphQL mutations
- Supported field types: text, number, date, select, multi-select, etc.

### Application to Dispatcher Architecture

Linear custom fields enable **team-centric dispatch routing at scale** (80+ profiles reduced to 8-10 teams):

**Custom fields to implement:**
- `assigned_team` (text or select) — e.g., "design", "marketing", "engineering", "devops", "support"
- `assigned_node` (derived or explicit) — e.g., "node-02", "node-04" (auto-populated from team config or explicit)

**Dispatcher logic (Rai on 60.10):**
1. Poll Linear issue query with custom field filters: `assigned_team != null`
2. For each team-assigned issue:
   - Look up team in local `config.team_node_map` (e.g., `design → node-02`)
   - Create kanban task with `team` metadata and `assigned_node`
   - Dispatcher spawns available profile from team on assigned node
3. Profile executes work, posts completion comment as team ("**Design Team** completed…")
4. Executor name + OAuth identity tracked in logs / kanban details for audit

**Benefits:**
- Scales to 80+ profiles via stable 8–10 team abstractions
- Team-level accountability in Linear (not individual profile details)
- Custom fields are canonical source; no hardcoded profile-to-node mappings
- Linear remains system of record for all routing decisions

### Integration Recipe

**Setup steps for Rai cron (Linear poller):**
1. Create custom fields in Linear workspace settings (or via GraphQL)
2. Populate `assigned_team` on issues as they come in (webhook defaults, manual assignment, or import)
3. Rai runs 1-min cron: Read Linear issue query with `assigned_team` custom field filter
4. Map team to node: `team_node_map = { design: "node-02", marketing: "node-04", ... }`
5. Write kanban tasks with team routing metadata
6. Dispatcher spawns profiles as usual; they execute and post evidence

**No breaking changes to Kanban + Profiles native model.** Custom fields are read-only routing input; execution remains unchanged.

### Blockers Cleared
- ~~"Do custom fields exist?"~~ **CONFIRMED YES**. No alternate routing sources needed.
- Team-centric scaling model can proceed to implementation.

### Next Steps
1. Design Rai cron architecture (Linear poll → custom field read → team_node_map lookup → kanban dispatch)
2. Define team_node_map config structure
3. Create team-level audit template for Linear comments
4. Build smoke test for end-to-end team dispatch (assign issue to "design" team, verify profile from design pool executes)
