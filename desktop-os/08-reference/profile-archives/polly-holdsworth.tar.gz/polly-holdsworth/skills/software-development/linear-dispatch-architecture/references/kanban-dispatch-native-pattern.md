# Kanban Native Dispatch Pattern

**Session**: 2026-07-03 — verified against official Hermes docs at https://hermes-agent.nousresearch.com/docs/user-guide/features/kanban

## The Pattern (Not Hybrid, Not Faceless-Only)

### Wrong Assumption
"Can I run profiles as named control-plane + faceless workers in hybrid mode?"

**Answer**: No. There is no hybrid mode. Kanban dispatch is the only documented native pattern, and it uses **full-process workers**, not faceless nodes.

### Right Pattern

```
┌─────────────────────────────────────────┐
│      Control Plane (named actors)       │
│  - Rai (orchestrator/approver)          │
│  - Kai (pre-prod lead)                  │
│  - Mai (platform architect)             │
│  - Linear OAuth tokens for each         │
└──────────────────┬──────────────────────┘
                   │
                   ├─→ Kanban Task Board
                   │   (~/.hermes/kanban.db)
                   │   - shared across all profiles
                   │   - durable, on disk
                   │   - atomic claim + spawn
                   │
                   ├─→ Dispatcher (in gateway)
                   │   - default: kanban.dispatch_in_gateway: true
                   │   - watches for stale claims
                   │   - promotes ready tasks (deps met)
                   │   - claims atomically
                   │   - spawns assigned profiles
                   │
                   └─→ Worker Profiles (full OS processes)
                       - worker-node01 / worker-node02 / ...
                       - each has own ~/.hermes/profiles/<name>/
                       - each has own config.yaml + .env
                       - each has own canban_* toolset
                       - when they call kanban_comment, comment
                         appears under THEIR identity (via their .env OAuth token)
```

### Three Key Layers

**1. Control Plane (named actors, orchestration)**
- Profiles for Rai, Kai, Mai with distinct Linear OAuth tokens
- These are the approval/review faces in Linear
- They own the Kanban board (_their_ profile commands control it)
- They write high-level decisions and escalations

**2. Kanban Board (durable, multi-user)**
- SQLite at `~/.hermes/kanban.db`
- Every task is a row; any profile can read/write
- Dispatcher runs here automatically (in the gateway)
- No custom orchestration layer needed — this IS the layer

**3. Worker Profiles (faceless, full-process)**
- Spawned by the dispatcher from the board
- Each gets `HERMES_KANBAN_TASK` env var pointing to the task it owns
- They have basic kanban_* tools to claim, report, complete
- They call `kanban_comment` with THEIR identity (faceless worker token)
- They are NOT in-process — they're separate terminal(background=true) processes

### Identity & Commenting

**Misconception**: "Faceless workers should comment as the control plane."

**Reality**: Workers comment as THEMSELVES. That's the whole point.

```yaml
# Control Plane (Rai's profile)
~/.hermes/profiles/rai/.env
  LINEAR_OAUTH_TOKEN=[Rai's token]

# Worker (faceless node01)
~/.hermes/profiles/worker-node01/.env
  LINEAR_OAUTH_TOKEN=[faceless/shared worker token]

# When worker-node01 calls kanban_comment:
# The comment appears in Linear under the WORKER identity, not Rai's.
```

This keeps the audit trail **honest**. Rai makes governance decisions. The worker executes and reports the outcome. Both visible in Linear.

### Dispatch in Gateway

```
gateway/run.py → cron/dispatcher.py

- Runs every tick (configurable interval)
- Reads kanban.db for ready + unclaimed tasks
- Atomically claims each task
- Spawns the assigned profile via terminal(background=true)
- Passes HERMES_KANBAN_TASK env var
- Auto-blocks on repeated spawn failure (failure_limit, default 2)
```

**No custom bridge needed.** This is built into Hermes core.

## Integration Recipe

### 1. Set up control-plane profiles

```bash
hermes profile create rai --description "Orchestrator/approver"
hermes profile create kai --description "Pre-prod lead"
hermes profile create mai --description "Platform architect"

# Each one gets its own Linear OAuth token in .env
```

### 2. Create worker profiles

```bash
hermes profile create worker-node01 --description "faceless execution"
hermes profile create worker-node02 --description "faceless execution"
# ... up to your node count

# Each worker gets the SAME shared Linear token (or a dedicated worker bot token)
```

### 3. Wire up Kanban

```bash
# In the control plane (e.g., rai's profile):
hermes kanban init

# Enable dispatcher in gateway (default is on):
hermes config set kanban.dispatch_in_gateway true

# Set failure tolerance:
hermes config set kanban.failure_limit 2

# Start gateway
rai gateway start
```

### 4. Create tasks from Linear

```bash
# Either:
# a) Control plane creates Kanban tasks manually:
hermes kanban create "MBLK-60" --assign worker-node01

# b) Or use Linear API integration to push issues → Kanban tasks
```

### 5. Workers run automatically

Dispatcher watches; worker profile spawns; task gets claimed; work happens; worker calls `kanban_complete`.

```
Task state: ready
→ Dispatcher claims it
→ spawn worker-node01
→ worker reads HERMES_KANBAN_TASK
→ worker calls kanban_show, does work, calls kanban_comment as itself
→ dispatcher sees heartbeat, knows work is live
→ worker calls kanban_complete
→ dispatcher reclaims stale work if the worker dies
```

## Why This Works

1. **No custom orchestration** — the dispatcher is built-in.
2. **No hidden identity swapping** — workers are visible as themselves.
3. **Durable board** — survives process restarts.
4. **Atomic claims** — no task race conditions.
5. **Easy to expand** — add more worker profiles, they auto-join the dispatch loop.
6. **Linear stays authoritative** — every action reflects in Linear via the right actor.

## Common Pitfalls

**Pitfall 1**: "I want faceless workers but they should comment as Rai."
- No. They comment as themselves. That's the audit trail.
- If you want Rai's voice on the output, Rai posts a summary comment after the worker finishes.

**Pitfall 2**: "Can I run Kanban without the dispatcher?"
- Yes, but you lose atomicity and auto-retry. Manual board control is fine for small fleets.
- Dispatcher is opt-in via `kanban.dispatch_in_gateway`.

**Pitfall 3**: "Do I need a custom bridge to integrate Linear?"
- No. Use the Linear API or webhook integration; Kanban tasks become rows; dispatcher routes them.
- Keep Linear outside the Kanban DB; let the dispatcher pull/route.

**Pitfall 4**: "Hybrid profiles means some named, some faceless, right?"
- Yes, that's correct—but it's NOT a separate mode. Named control-plane + faceless workers is the standard pattern.
- All profiles work the same way; some can be human agents, some can be machines.

## Reference

- **Official Docs**: https://hermes-agent.nousresearch.com/docs/user-guide/features/kanban
- **Kanban Tutorial**: https://hermes-agent.nousresearch.com/docs/user-guide/features/kanban-tutorial
- **Kanban Worker Lanes**: https://hermes-agent.nousresearch.com/docs/user-guide/features/kanban-worker-lanes
