# KOHD Workspace Structure (Live Discovery 2026-07-03)

**API Token**: `lin_api_7XIXcPMdMhxCAy9gvdqXhuSFSNEEZ5TgWYp8Ppjc` (saved in memory)

## Teams

- Master Backlog
- Architecture, Operations & Business
- **Kohd - Hub 1** (Operational hub; guests scoped to this team)
- Support
- Club Operations
- Release & Governance
- Business Operations
- **CD_Client Delivery**
- Rai
- **KS_Kohd Systems** (Primary delivery team)
- Infrastructure & Operations

## Key Projects (50+ total; selected)

### Delivery Projects

| Project | Team | Issues | Model |
|---------|------|--------|-------|
| **KOHD Heritage – Go To Market Programme** | KS_Kohd Systems | 61 | Epic-scoped (2 main epics, 10 total parents) |
| **KOHD ADF Operating Model** | Master Backlog | 9 | Platform workstreams (meta-project) |
| **kohd-autonomous-project-delivery** | — | ? | Autonomous sprint teams |
| **KOHD-PRODUCTION** | — | — | Live 50K+ clubs platform, 99.9% SLA |
| **KOHD-DISCOVERY** | — | — | Wedge research (Aardvark, EcoPUK) |

### Governance/Meta Projects

- ARC-000 through ARC-008 (Workshop governance, founder review, decision intake, etc.)
- KOHD Shared Memory & Knowledge Graph
- KOHD Public Content & Asset OS
- KOHD AI Routing & Automation

### Integration Projects

- **INFOPS Platform Integration Programme** (90 issues total, 9 platforms)
  - Apple Wallet, BrightSign, Spond, Lightspeed HQ, GoHighLevel, Xero, FlowFuse, Cloudflare, Krystal.io
- Individual platform integration projects (e.g., `GoHighLevel Platform Integration`)

## KOHD Heritage Project Detail

**61 issues across 2 main epics:**

### Epic 1: KS-2999 "Programme Control: KOHD Heritage GTM execution master"
- **29 subtasks** (workshops + phases)
- **State**: Backlog
- **Priority**: 1
- **Estimate**: 8
- **Assignee**: Unassigned
- **Children** (sample):
  - KS-3047: Hermes Handoff — Convert GTM to AI execution
  - KS-3046: Hermes Dispatch Pack — Prepare for AI dispatch
  - KS-3026: WS22 — Prepare 800-club national scale plan
  - KS-3025: WS21 — Execute foundation pilot launch
  - KS-3024: WS22 — Build national rollout plan
  - (24 more...)

### Epic 2: KS-3048 "Platform Readiness: Hermes V3 Deployment Validation"
- **9 subtasks** (infrastructure validation)
- **State**: In Progress
- **Priority**: 1
- **Estimate**: 13
- **Children** (sample):
  - KS-3057: API Integration & Delivery Automation Configured (Done)
  - KS-3056: Skill Pool Validated Against KS-3047 Work (Done)
  - KS-3055: Live Validation Comments Replace Reporting (Todo)
  - KS-3054: Faceless Worker Pool Replaced Swarm Pool (Todo)
  - KS-3053: Linear Integration Configured (Done)

### Other Root Issues

- KS-3064: TEST — Execute database-infrastructure skill (Done)
- KS-3065: ✅ Hermes v3 Deployment Complete (Backlog)

## Custom Fields

**Currently: None defined.**

Recommend adding:
- `Skill` (enum: backend | frontend | design | devops | data | ops | devrel | marketing)
- `Active Epic` (text: e.g., "KS-2999 Phase 1")
- `Assigned Node` (if multi-node dispatch: 01-09)
- `Assigned Team` (if team-based routing: Design Team, Backend Team, etc.)
- `Executor` (text: profile name for audit, not a seat consumer)

## Status Workflow

**Inferred from issues observed:**
- Triage
- Backlog
- Todo
- In Progress
- Done
- (Archived — not shown in queries)

## Labels

**Currently: None used** (no labels in the 61 KOHD Heritage issues examined).

Recommend:
- `skill-backend`, `skill-frontend`, `skill-design`, `skill-devops` (if using labels instead of custom field)
- `workshop-4`, `workshop-6`, etc. (for workshop grouping)
- `phase-1`, `phase-2` (for release phases)
- `blocker` (for critical path issues)

## Issue Hierarchy Pattern

**Parent-Child Structure** (from 61 issues):

```
Root Issue (Epic)
├─ Child 1 (Workshop or capability)
├─ Child 2 (Workshop or capability)
└─ ...

Each child is a discrete deliverable (not further subdivided in this view).
```

**No leaf-level sub-subtasks observed** (all sub-tasks are direct children of epics).

## Assignment Status

**Current state: All issues unassigned** (no individuals bound to issues yet).

Work is routed via:
1. Hermes profiles (not Linear assignee)
2. Kanban dispatch (profile names)
3. Linear comments (evidence postings as profiles)

## Key Observations for Rai Implementation

1. **Epic-scoped delivery is explicit**: User expects Rai to read epics (KS-2999), not random issues.
2. **No skill fields yet**: Rai will need to infer from titles or you add a custom field.
3. **No workflow blocker detection**: If some workshops must sequence (e.g., WS04 before WS06), Rai won't know without explicit parent-child or blocked-by relationships.
4. **No team assignments**: Profiles are actors, not Linear team members.
5. **Large scale**: 1000+ issues across KOHD ecosystem; KOHD Heritage is just one project.

## Rai Discovery Queries (GraphQL)

To replicate this discovery:

```graphql
# 1. Get all projects
query {
  projects(first: 50) {
    edges {
      node {
        id
        name
        description
      }
    }
  }
}

# 2. Get a specific project + all issues
query {
  project(id: "ec6ff25c-cea0-4f7c-abd5-699003ec51ef") {
    name
    issues(first: 200) {
      edges {
        node {
          identifier
          title
          state { name }
          priority
          estimate
          assignee { name }
          parent { identifier title }
        }
      }
    }
  }
}

# 3. Get custom fields (usually empty; use to verify)
query {
  customFieldDefinitions(first: 50) {
    edges {
      node {
        id
        name
        fieldType
        description
      }
    }
  }
}

# 4. Get teams
query {
  teams(first: 50) {
    edges {
      node {
        id
        name
        description
      }
    }
  }
}
```

---

**Use this as the reference baseline for KOHD architecture decisions. Update after each significant Linear schema change.**
