# Multi-Project SaaS Provisioning Pattern (Rai Orchestrator)

**Session**: 2026-07-03  
**Context**: KOHD OS + Aardvark + EcoPUK multi-tenant delivery with shared profiles, GHL Snapshots, FlowFuse IP hiding, and Telegram approval gates.

---

## Executive Summary

**Business Model**: Solutions provider that builds and runs autonomous production systems. Delivery phase (profiles build 24/7 while human sleeps), then 80% autonomous production phase (webhooks + scheduled crons execute profiles, tracked in Linear).

**Three Projects, One Workflow**:
- **KOHD Heritage** (MVP of Club OS): Multi-tenant platform. Each club gets own GHL sub-account + MariaDB schema. 61 issues, 2 main epics. Deadline: Early August. Dispatch priority: **60-70%**.
- **EcoPUK** (Single customer quote phase): 1 GHL sub-account, 1 MariaDB schema. Quote phase ONLY (this week). Dispatch priority: **20-30%**.
- **Aardvark** (Single customer, digital transformation): 1 GHL sub-account, 1 MariaDB schema. Production in 4 weeks. Dispatch priority: **10-20%**.

**Shared Infrastructure**: All 3 projects use same cloud platforms (GHL, Cloudflare, FlowFuse, MariaDB, Node-RED). Same 8+ profiles execute work across all projects.

**Key Architectural Decision**: GHL Snapshots (SaaS template model) are the deployment unit. FlowFuse contains proprietary Node-RED flows (hidden from customers). MariaDB is tenant-isolated. Rai is the multi-project coordinator.

---

## Rai Orchestrator: Multi-Project Flow

### Intake (Webhook → Approval Gate)

```
TRIGGER: Customer fills GHL intake form (signup, quote request, etc.)
├─ GHL webhook fires → Rai endpoint
├─ Rai creates Linear issue (parent):
│  {
│    title: "Setup KOHD club: Lancashire Bulls",
│    project: "KOHD Heritage GTM",
│    status: "Triage",
│    priority: 1,
│    description: "..."
│  }
├─ Rai sends Telegram to Neil (with approval buttons or reply format):
│  "New signup: Lancashire Bulls (KOHD club). Approve? [yes/no]"
└─ Awaits approval

APPROVAL (Neil in Telegram):
├─ Replies: "approve" (or clicks button)
├─ Rai marks Linear issue: status = "Ready for dispatch"
└─ Rai moves to Dispatch phase
```

### Dispatch (Credential Setup + Provisioning)

**Sequence**: Same for all projects (KOHD / EcoPUK / Aardvark). Rai reads project type from Linear and routes accordingly.

```
PHASE 1 — freddy-frontend (GHL Forms + Snapshot)
├─ Lookup credentials:
│  {
│    ghl_api_key: (encrypted, stored in vault on 60.10),
│    ghl_parent_api_key: (for creating/deploying only),
│    ghl_location_id: (sub-account ID)
│  }
├─ GHL API Call 1: Create sub-account (if new club)
│  POST /api/ghl/sub-accounts
│  {
│    parent_account: "kohd",
│    name: "Lancashire Bulls KOHD Club",
│    contact_email: "...@club.com"
│  }
│  Response: { location_id: "xyz123", webhook_url: "..." }
├─ GHL API Call 2: Deploy snapshot
│  POST /api/ghl/locations/{location_id}/provision-snapshot
│  {
│    snapshot_id: "kohd-heritage-snapshot-v1",
│    overrides: {
│      club_name: "Lancashire Bulls",
│      club_domain: "lancashire-bulls.kohd.io"
│    }
│  }
│  Response: { forms_deployed: [...], webhook_endpoint: "..." }
├─ Result: Club now has GHL sub-account with:
│  ├─ Story Capture form
│  ├─ Tile Order form
│  ├─ Sponsor Signup form
│  ├─ Custom objects (stories, tiles, sponsors)
│  └─ Webhook ready to receive form submissions
└─ Rai creates Linear child issue:
   "GHL snapshot deployed for Lancashire Bulls"

PHASE 2 — kai-backend (MariaDB Tenant Schema)
├─ Lookup MariaDB connection (central instance on 60.10)
├─ Create new schema:
│  CREATE SCHEMA kohd_lancashire_bulls;
├─ Load schema.sql template:
│  ├─ CREATE TABLE kohd_lancashire_bulls.stories (...)
│  ├─ CREATE TABLE kohd_lancashire_bulls.tiles (...)
│  ├─ CREATE TABLE kohd_lancashire_bulls.sponsors (...)
│  ├─ CREATE TABLE kohd_lancashire_bulls.households (...)
│  └─ ... (20+ tables for full KOHD data model)
├─ Insert into tenant_lookup table:
│  INSERT INTO tenant_lookup
│  (tenant_id, project, club_name, ghl_location_id, mariadb_schema, status)
│  VALUES (uuid(), "kohd", "Lancashire Bulls", "xyz123", "kohd_lancashire_bulls", "active")
├─ Test connection and verify tables created
└─ Rai creates Linear child issue:
   "MariaDB schema created + tenant registered"

PHASE 3 — rai-sre (Networking + Webhook Registration)
├─ Cloudflare API: Create DNS
│  POST /api/zones/{zone_id}/dns_records
│  {
│    type: "A",
│    name: "lancashire-bulls.kohd.io",
│    content: "nginx-reverse-proxy-ip",
│    ttl: 3600
│  }
│  Response: { id: "cf123", status: "pending" }
├─ Verify DNS propagation (nslookup test)
├─ Node-RED webhook registration:
│  Update FlowFuse environment:
│  {
│    tenant_id: uuid,
│    project: "kohd",
│    mariadb_schema: "kohd_lancashire_bulls",
│    ghl_location_id: "xyz123",
│    webhook_endpoint: "https://flowfuse.kohd.io/webhook"
│  }
├─ Test full path:
│  ├─ Submit form in GHL sub-account
│  ├─ GHL fires webhook: POST to flowfuse.kohd.io/webhook
│  │  Headers: X-Tenant-ID: uuid
│  ├─ Node-RED receives webhook
│  ├─ Routes to story-capture-transform flow
│  ├─ Applies KOHD logic (hidden from club)
│  ├─ Inserts INTO kohd_lancashire_bulls.stories
│  └─ Verifies row count incremented
└─ Rai creates Linear child issue:
   "DNS configured + webhook routing verified. LIVE."

COMPLETION:
├─ Rai marks parent issue: status = "Done"
├─ Rai posts comment:
   "Lancashire Bulls KOHD club is live.
    GHL: https://location-xyz123.gohighlevel.com
    Heritage timeline: https://lancashire-bulls.kohd.io
    Deployment: 2026-07-03 14:30 UTC"
└─ Club can now accept story submissions, tile orders, sponsor signups
```

---

## Credential Vault (Encrypted on 60.10)

```
~/.hermes/rai-vault (encrypted, owned by Rai profile only):

KOHD:
├─ ghl_parent_api_key: (for sub-account creation + snapshot deploy)
├─ For each club:
│  ├─ kohd_club_001
│  │  ├─ tenant_id: uuid-abc123
│  │  ├─ club_name: Lancashire Bulls
│  │  ├─ ghl_location_id: xyz123
│  │  ├─ ghl_api_key: (encrypted, customer-specific)
│  │  ├─ mariadb_schema: kohd_lancashire_bulls
│  │  ├─ status: active
│  │  └─ created_at: 2026-07-03

EcoPUK:
├─ ghl_api_key: (1 account for ALL EcoPUK data)
├─ tenant_id: uuid-ecopuk
├─ mariadb_schema: ecopuk_project
└─ status: active

AARDVARK:
├─ ghl_api_key: (1 account for ALL Aardvark data)
├─ tenant_id: uuid-aardvark
├─ mariadb_schema: aardvark_project
└─ status: active
```

**Access**: Only Rai profile has decrypt key. Profiles receive credentials via kanban task context (scoped, temporary).

---

## Dispatch Priority & Load Balancing

**Priority Queue** (when multiple projects have pending issues):

```
IF (KOHD issues waiting) AND (now < early_august_deadline):
  ├─ Assign 60-70% available profiles to KOHD
  └─ Continue until KOHD MVP is done
ELSE IF (EcoPUK quote phase pending) AND (capacity available):
  ├─ Assign 20-30% profiles to EcoPUK
  └─ Quick parallel work
ELSE IF (Aardvark Phase 1 pending) AND (capacity available):
  ├─ Assign 10-20% profiles to Aardvark
  └─ Slow burn (4-week runway)

REPEAT every 60 seconds.
```

**Example Dispatch Tick** (Rai cron at T=60s):

```
Pending work:
├─ KOHD: 5 ready issues
├─ EcoPUK: 2 ready issues
└─ Aardvark: 1 ready issue

Available profiles (capacity check):
├─ kai-backend: 0 running → AVAILABLE
├─ freddy-frontend: 1 running → AVAILABLE (can take 1 more)
├─ jane-designer: 2 running → AVAILABLE (can take 1 more)
└─ rai-sre: 0 running → AVAILABLE

Dispatch (priority order):
├─ KOHD (70% capacity):
│  ├─ kai-backend → KOHD backend issue #1
│  ├─ freddy-frontend → KOHD frontend issue #1
│  └─ jane-designer → KOHD design issue #1
├─ EcoPUK (20% remaining):
│  └─ rai-sre → EcoPUK provisioning issue #1
└─ Aardvark (10% remaining):
    └─ (no capacity, wait for next tick)

kanban_create() calls:
├─ {assignee: "kai-backend", project: "kohd", issue_id: "KS-3000", ...}
├─ {assignee: "freddy-frontend", project: "kohd", issue_id: "KS-3001", ...}
├─ {assignee: "jane-designer", project: "kohd", issue_id: "KS-3002", ...}
└─ {assignee: "rai-sre", project: "ecopuk", issue_id: "ECP-010", ...}

Profiles claim and execute immediately.
```

---

## Production Phase: 80% Autonomous Execution

After delivery (Heritage live, etc.), Rai switches to **production mode**:

```
RECURRING WORKFLOWS (automated, no human intervention):

Sunday Cron: "Fetch player stats for all clubs"
├─ Rai queries: SELECT * FROM tenant_lookup WHERE status='active'
├─ For each tenant_id:
│  ├─ Create kanban task: "Fetch stats for tenant_id"
│  ├─ Dispatch to data-sync profile
│  ├─ Profile calls external API (club stats endpoint)
│  ├─ Transform + validate
│  ├─ INSERT into kohd_<club>.stats_log
│  └─ Post result to Linear
└─ Daily standup reports on completion

GHL Webhook (ongoing): "New membership signup"
├─ GHL fires webhook: POST to flowfuse.kohd.io/webhook
├─ Node-RED receives:
│  ├─ Extract X-Tenant-ID
│  ├─ Lookup MariaDB schema
│  ├─ Apply KOHD membership logic (hidden)
│  ├─ INSERT into household + member tables
│  └─ Send confirmation email
└─ All logged; Linear comment optional (batched daily)

Billing Sync (recurring): "Monthly billing calculations"
├─ Rai creates kanban task for billing profile
├─ Profile queries: SELECT * FROM all tenant schemas, aggregate revenue
├─ Create invoices, email clubs
└─ Post summary to Linear
```

---

## Critical Decisions (Locked)

### 1. **GHL Snapshots Are the Deployment Unit**
- Create snapshot once per project (KOHD Heritage, EcoPUK, Aardvark)
- Deploy to new sub-accounts instantly (no re-designing forms each time)
- Snapshot contains ONLY club-facing forms, no IP (Node-RED is separate)

### 2. **FlowFuse Contains Secret Sauce**
- 1 Node-RED instance per project (KOHD, EcoPUK, Aardvark separate)
- Flows are parameterized by tenant_id, shared across all clubs
- Clubs see only inputs/outputs, never the flows themselves
- Revenue logic, sponsor tiers, affiliate calculations live here (hidden)

### 3. **Tenant Isolation via MariaDB Schemas**
- KOHD: Each club gets schema (kohd_club_001, kohd_club_002, etc.)
- EcoPUK: 1 schema (ecopuk_project), but tenant_id param inside (if multi-tenant later)
- Aardvark: 1 schema (aardvark_project)
- Lookup table mediates tenant_id → schema mapping

### 4. **Credentials per Sub-Account**
- KOHD: Parent account has master key for creating sub-accounts
- Each club gets unique ghl_api_key (stored encrypted in vault)
- EcoPUK + Aardvark: Single ghl_api_key (shared by all tenants within project)

### 5. **Telegram Approval Gate**
- Customer fills intake form → webhook → Rai creates Linear issue
- Rai sends Telegram to Neil with approval request
- Neil approves → Rai transitions to Dispatch phase
- All provisioning then automated (no further human intervention until production blockers)

### 6. **Dispatch Priority (Strict, No Round-Robin)**
- KOHD gets 60-70% capacity until MVP done (early August)
- EcoPUK gets 20-30% for quick quote phase (this week)
- Aardvark gets 10-20% background work (4-week runway)
- If KOHD capacity drops (due to completed issues), Rai fills with EcoPUK/Aardvark

---

## Open Questions (Pending Implementation)

1. **Telegram approval workflow format:**
   - Buttons (✓ / ✗)?
   - Or simple text reply ("approve")?
   - Who sends approval? (Neil directly in Telegram channel?)

2. **GHL webhook endpoint:**
   - Where does Rai listen? (60.10 public nginx? Hermes gateway?)
   - Webhook URL structure? (`https://rai.kohd.io/webhook/ghl`? Or Hermes native?)

3. **Kanban task context (credentials delivery):**
   - Should profiles receive encrypted credentials in kanban task body?
   - Or fetch from a shared vault endpoint at runtime?
   - How does kai-backend connect to MariaDB without hardcoding password?

4. **Error handling & retries:**
   - If GHL API call fails (timeout, rate limit), retry? How many times?
   - If webhook registration fails, escalate to Linear blocker?
   - Should Rai auto-rollback (delete schema, deprovision) on failure?

5. **Kanban dashboard UI:**
   - Does Hermes v0.18.0 have native web UI for manual kanban task creation?
   - If not, can profiles (during incidents) create urgent tasks via CLI?

---

## Implementation Checklist

- [ ] Create Linear issues for each deployment phase (freddy-frontend, kai-backend, rai-sre)
- [ ] Rai cron: poll Linear for "Ready for dispatch" issues
- [ ] Rai credential vault: set up encrypted store on 60.10
- [ ] Rai: implement GHL API calls (sub-account creation, snapshot deploy, webhook registration)
- [ ] Rai: implement Telegram approval flow (send message, wait for reply, update Linear)
- [ ] Rai: implement dispatch logic (priority queue, capacity check, kanban_create)
- [ ] Profiles: implement kanban_show → credential lookup → execute work
- [ ] Node-RED: implement tenant_id routing + parameterization
- [ ] Cloudflare: document DNS setup automation
- [ ] Test: full path (form submit → GHL → webhook → Node-RED → MariaDB)
- [ ] Runbook: what happens if webhook endpoint goes down?

---

## References

- See `references/kohd-canonical-description.xml` for the full KOHD system blueprint (phases, modules, data model, governance).
- See `references/kohd-workspace-discovery-2026-07-03.md` for Linear workspace structure (teams, projects, 61 issues in Heritage GTM, epic breakdown).
- See `references/rai-workflow-coordinator-pattern.md` for Rai as mini workflow (not single API request).
- See `references/project-scoped-delivery-model.md` for epic-based delivery (Laura decides scope, Rai dispatches by skill).
