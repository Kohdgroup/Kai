# Kanban Multi-Node Topology (Named Profiles on Distributed Worker Nodes)

## Setup

- **60.10** = Control Plane (Rai dispatcher, kanban.db, orchestrator)
- **01-09** = 9 Worker nodes (each runs independent Hermes instance)

All nodes share access to the same `kanban.db` (NFS mount or replicated storage).

## How It Works

### 1. Task Creation (Rai on 60.10)

Rai (orchestrator) detects a NEW issue in Linear, creates a kanban task:

```bash
# Rai runs this cron job on 60.10 every 1 minute:
hermes kanban create \
  --board kohd \
  --profile mai-architect \
  --title "Design homepage [KOHD-123]" \
  --description "Issue: KOHD-123"
```

Task state: `todo` → `ready` (when explicitly promoted or auto-promoted).

### 2. Kanban Dispatcher (Gateway Daemon on 60.10)

The dispatcher runs in the gateway (daemon mode, always-on):

```bash
hermes --profile rai-ops desktop  # gateway runs kanban.dispatch_in_gateway: true by default
```

Every tick, the dispatcher:
1. **Detects ready tasks** (status = `ready`)
2. **Atomically claims** the task for the assigned profile (e.g., `mai-architect`)
3. **Spawns worker process** on the node where that profile is registered

All nodes have read access to kanban.db (shared storage), so the dispatcher can see which node has which profile and route accordingly.

### 3. Worker Execution (Profile on Assigned Node)

When the dispatcher claims a task for `mai-architect`, it triggers mai-architect on the node where she's registered (e.g., node 03).

The worker checks in via `kanban_show`:

```bash
# Worker (mai-architect on node 03) calls:
kanban_show <task-id>  # Returns task metadata, description, Linear issue link
```

Worker executes work:
- Reads task metadata
- Fetches issue details from Linear (if needed)
- Executes design/content/validation work
- Posts evidence to Linear as herself (using her OAuth token from `.env`)
- Calls `kanban_complete` with results

```bash
# Worker posts evidence:
kanban_complete <task-id> \
  --summary "Homepage design complete. See Linear comment and design assets at .../.../design.figma"
```

### 4. Completion Tracking (Rai on 60.10)

Dispatcher monitors task completion:

1. Detects `<task-id>` now has status = `completed`
2. Reads completion summary from kanban.db
3. Posts completion evidence to Linear comment (as Rai-ops or relays worker's summary)
4. Updates Linear issue status → `DONE`

## Key Invariants

- **One kanban.db, shared storage** — All nodes see the same board. Atomicity is enforced by SQLite + file locking.
- **Profiles registered per node** — Each profile exists on exactly one worker node. Dispatcher knows where mai-architect runs (node 03) and routes there.
- **Profile = named actor** — When mai-architect executes a task, she posts comments to Linear as `mai-architect`, not masked through Rai.
- **No central job queue separate from kanban** — Kanban IS the job queue. No separate Celery, RabbitMQ, or custom dispatch layer.
- **Failure handling** — If a worker crashes, the task remains `in_progress` until the dispatcher reclaims it (stale timeout). Tasks auto-block after `failure_limit` consecutive failures (default 2).

## Scaling This Topology

To add more worker nodes (10+):

1. **Install Hermes on new node** (e.g., node 10)
2. **Register profiles** on node 10 (e.g., `hermes profile create quinn-support-node10`)
3. **Ensure kanban.db is accessible** (NFS, already done if using shared storage)
4. **Dispatcher automatically sees new profiles** on next tick
5. **Route new tasks** to the new node by assigning the right profile

No rewrite needed. The topology scales linearly.

## Profile Distribution Example

| Node | Profiles |
|------|----------|
| 60.10 (Control Plane) | rai-ops (dispatcher only) |
| 01 | mai-architect, laura-orchestrator |
| 02 | kai-validator |
| 03 | quinn-support |
| 04 | amelia-comms |
| 05-09 | (reserved for future profiles or replicas) |

When a task is assigned to `mai-architect`, the dispatcher spawns her on node 01. When one assigned to `kai-validator`, spawned on node 02. Each profile is a full OS process with its own session, tools, and credentials.

## Why This Works

- **Native Hermes design** — Kanban + Profiles is built-in, no custom orchestration needed.
- **Multi-node without complexity** — Shared storage + atomic SQLite ops = distributed dispatch without Kafka, Consul, or service mesh.
- **Identity preserved** — Each worker posts as themselves. Audit trail is clear and cryptographically signed by their OAuth token.
- **Expansion without redesign** — Add nodes and profiles without changing the dispatcher or task flow.
