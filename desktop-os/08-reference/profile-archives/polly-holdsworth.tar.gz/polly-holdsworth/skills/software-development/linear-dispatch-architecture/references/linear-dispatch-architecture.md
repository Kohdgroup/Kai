# Linear-Driven Hermes Dispatch Architecture Notes

This reference captures the session-specific decisions and constraints for the Hermes control-plane / worker deployment work.

## Authoritative baseline
- Treat Hermes Agent **v2026.7.1 / v0.18.0** as the baseline when updating deployment or orchestration plans.
- Reconcile older V3 docs against the release before using them as the source of truth.
- The release emphasized:
  - first-class MoA (mixture-of-agents)
  - verification / completion contracts
  - background fan-out
  - scale-to-zero and drain coordination
  - `/learn` and `/journey`

## Operating model constraints
- **Linear is the system of record** for work.
- All work must be entered into Linear.
- All comments must be posted back per issue.
- Completion requires business requirements and real validation/evidence before marking an issue done.
- The user prefers **native platforms with minimal custom work**.
- Prefer the smallest reliable amount of bespoke orchestration.

## Control-plane / worker shape
- Use **named control-plane actors** for orchestration and governance.
- Use **faceless shared execution nodes** for workers.
- The recommended shape in this session was:
  - 9 faceless worker nodes now
  - expansion path to 22 worker nodes later
- Keep worker nodes generic and interchangeable.
- Concentrate identity / voice / governance on the control plane.

## Human feedback loop
- Raise real blockers to the user in a **daily standup via Telegram**.
- Use actor-based comments in Linear to record decisions, approvals, blockers, and evidence.

## Ask-one-question-at-a-time rule
- For this class of architecture / planning work, ask **one question at a time**.
- Do not bundle large clarification grids once the big-picture constraints are known.
- Prefer the next highest-value decision only.

## Scaling to 80+ Profiles (Team-Centric Model — 2026-07-03)

**UNLOCKED (Blocker cleared)**: Linear custom fields confirmed. Team-centric dispatch can proceed.

- Route by **team** (8–10 team abstractions), not individual profiles (80+)
- Linear custom fields: `assigned_team` (source of routing decisions)
- Rai polls Linear 1x/min, reads custom fields, maps team→node, dispatches available profile from team
- Team-level accountability in Linear comments; executor tracked in logs
- Scales cleanly without profile-to-node hardcoding

See references/team-centric-routing-linear-custom-fields.md for full recipe and Rai cron architecture.

## Previous notes (for context)
- The previous unresolved topology question was whether the deployment should target the current 9-node footprint only, or a 9-node baseline with a clean expansion path to 22 nodes.
- Team-centric model resolves this: 9 nodes can serve 80+ profiles via team pooling.
