# Kanban v0.18.0: Native Capabilities & Limitations

**Date verified:** 2026-07-03  
**Source:** https://hermes-agent.nousresearch.com/docs/user-guide/features/kanban (v0.18.0 docs)  
**Applied to:** Multi-node Kanban + Profiles dispatch with 80+ profile scaling

## Critical Discovery: Profile-Name-Based Assignment (NOT Skill-Based)

### What IS Native

- **`kanban_heartbeat()`** — Workers signal liveness. Dispatched auto-reclaims after 4+ hours with no heartbeat in last hour. Native, zero custom code.
- **Profile assignment by explicit name** — `kanban_create(..., assignee="jane-designer")`. Task is assigned to THE PROFILE with that name. Deterministic, single assignment.
- **Skills pinned per-task** — `kanban_create(..., assignee="jane", skills=["translation", "github-code-review"])`. Those skills load only for that task on that profile. No global skill registry.
- **One dispatcher per board** — Embedded in gateway (default). Atomically claims, spawns assigned profile, reclaims on crash/stale/timeout. Native state machine.

### What is NOT Native

**Multi-profile skill-based load-balancing:**
- Kanban does NOT auto-route to "least-loaded profile with Design skill"
- Kanban does NOT discover which profiles have which skills
- Kanban does NOT aggregate profiles by skill and pick the best one
- If you have 2 profiles with the same skill (`jane-designer` + `freddy-designer`), Kanban cannot route between them automatically

**What this means:** Routing logic is YOUR responsibility (Rai's responsibility), not Kanban's.

## Implication for 80+ Profile Scaling

When scaling to 80+ profiles grouped by skill/team:

### Option A: Rai Does the Routing (Custom Logic, Native Kanban)

**Rai maintains a node registry:**
```yaml
teams:
  Design: [jane-designer, freddy-designer, alex-designer]
  Marketing: [maya-marketing, pam-marketing]
  Engineering: [kai-eng, sre-1, sre-2]
```

**On each Linear task (Business Unit: Design):**
1. Rai reads Linear custom field: `Business Unit = "Design"`
2. Rai queries kanban.db: `SELECT COUNT(*) FROM tasks WHERE status='running' AND assignee IN (...Design team profiles...)`
3. Rai calculates least-loaded profile
4. Rai calls `kanban_create(..., assignee="jane-designer")` explicitly
5. Kanban dispatcher spawns jane-designer
6. jane-designer calls `kanban_heartbeat()` hourly
7. If stale (4h+ no heartbeat), dispatcher auto-reclaims, task goes to ready
8. Rai re-routes to next-least-loaded profile next tick

**Pros:**
- Fully native Kanban
- Complete control over routing logic
- Clear failure semantics
- Scales to arbitrary profile count

**Cons:**
- Rai must maintain registry
- Rai must query kanban.db capacity on every dispatch cycle (or cache + update on heartbeat)
- Load-balancing logic is custom (not handed off to system)

### Option B: Auto-Decomposer (Semi-Native, High-Level)

**Use Kanban's built-in `auto_decompose` feature:**
1. Laura drops rough one-liner into Linear: "Complete logo redesign"
2. Task lands in triage
3. Dispatcher auto-runs decomposer (LLM) on triage tasks
4. Decomposer reads profile roster + descriptions, fans task into specialized child tasks
5. Each child routed to best-fit specialist by the decomposer's LLM logic
6. Dispatcher spawns each profile, tracks via Kanban

**Pros:**
- Routing is LLM-driven (flexible, semantic)
- Less custom code
- Handles team abstractions naturally

**Cons:**
- Only works on coarse decomposition (large task → many subtasks)
- Not good for continuous work streams
- Adds auxiliary LLM cost
- Not suitable for frequent dispatch (e.g., 100+ tasks/day)

### Option C: Hybrid (Recommended for KOHD)

1. **Small, frequent tasks** (< 30min each) → Rai + custom logic (Option A)
2. **Large exploratory tasks** → Decomposer (Option B) + Rai routes children

## The Linear Licensing Question

**UNRESOLVED (2026-07-03):** Does each OAuth profile count as a separate seat / paid license in Linear?

**If YES (each OAuth token = 1 seat):**
- 80 profiles = 80 paid seats = prohibitively expensive
- Architecture pivots: fewer broad profiles + execution detail in comments

**If NO (only Linear workspace members counted):**
- 80 OAuth tokens on 1 workspace = 1 paid seat (amortized across them)
- Current architecture scales cleanly

**ACTION:** Verify with your Linear workspace:
1. Create 2 OAuth apps, have them both post to the same issue
2. Check Linear's "Members" count in workspace settings
3. Consult Linear's licensing docs on OAuth app seats

This is a blocker for finalizing the 80-profile scaling model.

## Hermes v0.18.0-Specific Notes

**Kanban dispatcher behavior (confirmed from docs):**
- Runs in gateway by default (`kanban.dispatch_in_gateway: true`)
- Ticks every `dispatch_interval_seconds` (default 60s)
- Reclaims tasks stale > `dispatch_stale_timeout_seconds` (default 4h) if no heartbeat in last hour
- Auto-blocks after `failure_limit` (default 2) consecutive spawn failures
- Workers get task-scoped tools (`kanban_show`, `kanban_complete`, `kanban_heartbeat`, etc.) via env var `HERMES_KANBAN_TASK`

**Heartbeat details:**
- Workers call `kanban_heartbeat(note="...")` (optional note, pure side-effect)
- Dispatcher tracks timestamp in kanban.db
- If 4h+ elapsed AND no heartbeat in last 1h, task is reclaimed to ready
- Reclaim is benign (no failure-counter tick), but worker loses current progress

**Multi-node topology (confirmed tested 2026-07-02):**
- Central kanban.db on control plane (60.10)
- NFS-mounted to worker nodes (01-09)
- Each worker node runs independent Hermes instance
- Dispatcher on control plane spawns workers on remote nodes via SSH backend
- Works and has been smoke-tested

## Pitfalls to Avoid

1. **Assuming Kanban does skill-based routing** — It doesn't. Rai must implement that logic.

2. **Not calling `kanban_heartbeat()` hourly on long tasks** — Dispatcher will auto-reclaim without it (task goes to ready, progress lost).

3. **Building custom skill registry outside Kanban** — Kanban doesn't expose profile skills, so you must maintain the registry yourself (in config, in Linear custom fields, or in Rai's memory).

4. **Assuming profiles on different nodes can't have the same skill** — They can. Rai's registry must track this.

5. **Not verifying Linear license impact before scaling to 80 profiles** — This is a hard blocker. Resolve it first.

6. **Using profile-to-node affinity when you want load-balancing** — If you want redistribution across nodes, don't pin profiles to single nodes. Let Rai's registry track that profiles can be on multiple nodes, and Rai can dispatch to any of them.

## Next Steps for KOHD / 80+ Profile Scaling

1. **Verify Linear licensing** — Does 1 workspace + 80 OAuth tokens = 1 seat or 80 seats?
2. **Design Rai registry** — Static config file, or dynamic heartbeat-based discovery?
3. **Implement Rai dispatch cron** — Poll Linear custom field (Business Unit), query registry, query kanban.db capacity, dispatch to least-loaded profile.
4. **Test multi-profile skill scenario** — 2+ profiles with same skill, verify Rai routes between them correctly.
5. **Heartbeat monitoring** — Ensure profiles call `kanban_heartbeat()` hourly; verify dispatcher reclaims stale tasks.
