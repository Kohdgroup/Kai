# Linear-First Cron Dispatch Pattern (KOHD Implementation)

## Overview

This is an alternative to Kanban-based dispatch for scenarios where:
- Single Linear license (OAuth-based actors)
- Profiles are always-on on a always-on Desktop PC or Control Plane
- Work is primarily human-initiated (not high-volume auto-triggered)
- Evidence trail must live in Linear comments (not separate audit plane)
- Approval gates are async (Neil on Telegram, not blocking)

**This is NOT Kanban dispatch; it is LINEAR-FIRST with profiles as watchers.**

## Architecture

```
LINEAR (System of Record)
├─ Issues: Status + Assignee + Comments
├─ OAuth Actors: neil, laura, mai, kai, rai (tokens in ~/.hermes/profiles/X/.env)
└─ Evidence: Comments with structured JSON blocks (machine-parseable)

PROFILES (Always-On Watchers)
├─ Laura (Desktop - Orchestrator)
│  ├─ Cron: Every 2 minutes
│  ├─ Watch: Status = NEW or AWAITING_APPROVAL
│  ├─ Action: Read issue, route to next profile, post Telegram
│  └─ Writes: Status transition, Assignee update, route decision comment
│
├─ Mai (Desktop - Architect/Content)
│  ├─ Cron: Every 5 minutes
│  ├─ Watch: (Assigned to mai-architect) AND (Status != Done)
│  ├─ Action: Execute skill (blog-writing, design-md, etc), post evidence
│  └─ Writes: Evidence comment (NO status change — Laura decides)
│
├─ Kai (Desktop - Validator)
│  ├─ Cron: Every 5 minutes
│  ├─ Watch: (Assigned to kai-validator) AND (Status != Done)
│  ├─ Action: Execute validation skill, post evidence
│  └─ Writes: Evidence comment (NO status change — Laura decides)
│
└─ Rai (Control Plane - Ops/Deployment)
   ├─ Cron: Every 5 minutes
   ├─ Watch: (Tags contain ready-for-deployment) OR (Assigned to rai-ops)
   ├─ Action: Run ops checks, collect evidence, verify
   └─ Writes: Evidence comment, Status update to DEPLOYED

TELEGRAM (Approval Gate)
├─ Desktop posts: "Status update needed. Neil decision?"
├─ Neil replies: "YES / NO / MODIFY"
└─ Hermes reads reply, updates Linear, proceeds
```

## Status Workflow

```
NEW
  → [Laura routes]
  → IN PROGRESS (profiles work in parallel)
  → ONBOARDING_COMPLETE (all profiles done)
  → AWAITING_APPROVAL (Laura posts to Telegram, waits for Neil)
  → PUBLISHED (Neil approved)
  → DEPLOYED (Rai verified live)
  → DONE
```

## Watch Rules (Exact Conditions)

### Laura (Orchestrator)
```python
Cron: '*/2 * * * *'  # Every 2 min

if (Status in [NEW, AWAITING_APPROVAL]):
    - Read issue + all comments
    - Decide next routing
    - Update Assignee to next profile / neil-digital-twin
    - Update Status to next stage
    - Post to Telegram if awaiting user decision
```

### Mai/Kai (Execution)
```python
Cron: '*/5 * * * *'  # Every 5 min

if (Assignee == "mai-architect" OR "kai-validator") AND Status != Done:
    - Read issue + tags
    - Match tags to skill (tag:content-creation → blog-writing skill, etc)
    - Execute skill
    - Post evidence comment (structured JSON block)
    - Do NOT change status (Laura changes status)
```

### Rai (Ops)
```python
Cron: '*/5 * * * *'  # Every 5 min

if Tags contains "ready-for-deployment" OR Assignee == "rai-ops":
    if Status in [IN_PROGRESS, DEPLOYED_READY]:
        - Run smoke tests / readiness checks
        - Post evidence comment
        - Update Status to DEPLOYED (final change)
```

## Evidence Format (Machine-Parseable + Human-Readable)

All profiles write comments in this format:

```
[PROFILE: mai-architect]
[TIMESTAMP: 2026-07-03T14:22:31Z]
[ACTION: Blog Post Creation]
[STATUS: ✅ Complete]

Title: "Introducing FlowFuse to Club Managers"
Word Count: 850
URL: https://blog.kohd.example.com/flowfuse-clubs
Validation: Passed grammar + SEO checks

Next: Awaiting neil-digital-twin approval
```

Parser extracts:
- Profile (OAuth actor)
- Timestamp (for ordering/freshness)
- Action (what skill ran)
- Status (✅ / ❌)
- Key fields (varies by profile)

## Club Signup Example (Full Flow)

```
1. GHL FORM SUBMISSION
   Club signs up via GHL form
   
2. WEBHOOK TRIGGERS DESKTOP
   Webhook fires to kohd-hub gateway
   Linear issue created: KOHD-CLUB-5042, Status=NEW, Assignee=laura-orchestrator
   
   Comment: "Club signup webhook from GHL at 2026-07-03T10:05:00Z
             Club: ABC Rugby Club
             Owner: john@abcrugby.com
             GHL Account: ghl_abc_rugby"

3. LAURA DETECTS (2-min cron)
   Reads KOHD-CLUB-5042, Status=NEW
   Updates: Status → IN_PROGRESS
   Updates: Assignee → (empty, parallel work)
   Posts to Telegram: "🟢 Club 5042 (ABC Rugby) onboarding started"

4. PROFILES EXECUTE IN PARALLEL (5-min cron each)
   
   Mai sees tags [platform-himalaya, club-signup]:
   → Writes welcome blog post (if needed)
   → Posts comment: "[PROFILE: mai-architect] [ACTION: Blog Creation] ✅ Complete [URL: ...]"
   
   Kai sees tags [platform-himalaya, club-signup]:
   → Validates GHL account setup + Spond readiness
   → Posts comment: "[PROFILE: kai-validator] [ACTION: Validation] ✅ GHL ready, Spond ready"
   
   Rai sees tags [platform-himalaya, club-signup]:
   → Runs Himalaya: Send welcome email
   → Posts comment: "[PROFILE: rai-ops] [ACTION: Comms] ✅ Email sent to john@... at 10:15"

5. LAURA DETECTS (2-min cron)
   Reads KOHD-CLUB-5042
   Sees 3 evidence comments from (mai, kai, rai)
   All statuses = ✅
   Updates: Status → ONBOARDING_COMPLETE
   Updates: Assignee → neil-digital-twin
   Reads all comments, summarizes, posts to Telegram:
   
   "🟢 Club 5042 (ABC Rugby Club) ready to go live?
    ✅ Welcome sent
    ✅ Validation passed
    ✅ Blog post ready
    Reply: YES / NO / MODIFY"

6. NEIL DECIDES (Your Laptop, Telegram)
   You read Telegram message on phone
   You reply: "YES ✓"

7. NEIL'S DIGITAL TWIN (Laptop, runs next time you open it)
   Reads your Telegram reply
   Updates Linear: Status → PUBLISHED
   Updates Linear: Assignee → rai-ops
   Posts comment: "Neil approved. Proceeding to deployment."

8. RAI DETECTS (5-min cron, Control Plane)
   Reads KOHD-CLUB-5042, Status=PUBLISHED
   Assigned to rai-ops
   Runs final deployment checks
   Posts comment: "[PROFILE: rai-ops] [ACTION: Deployment Verify] ✅ Live"
   Updates: Status → DEPLOYED

9. LAURA DETECTS (2-min cron)
   Reads KOHD-CLUB-5042, Status=DEPLOYED
   Posts to Telegram: "✅ Club 5042 is LIVE"

TOTAL TIME: ~15 minutes automation
YOUR TIME: 1 Telegram reply
AUDIT TRAIL: Full in Linear comments
```

## Why This Pattern vs Kanban

| Dimension | Linear-First Cron | Kanban Dispatch |
|-----------|---|---|
| **Dispatcher** | Profiles + Linear watchers | Gateway + SQLite board |
| **Work Detection** | Linear status/assignee | Kanban queue + claims |
| **Setup Complexity** | OAuth tokens in .env | Shared SQLite + profiles |
| **Single License** | ✅ Yes (OAuth actors) | ✅ Yes (profiles) |
| **Best For** | Human-initiated, async approvals | High-volume, auto-triggered |
| **Audit Trail** | Linear comments | Kanban comments + Linear |
| **Approval Gates** | Telegram (async) | Must wait for dispatch claim |

**Choose Linear-First Cron if:**
- User needs async approval (Telegram on phone, not blocking)
- Work is primarily human-created (not mass auto-triggered)
- Evidence must live in Linear (not a separate system)
- Desktop PC is always-on orchestrator center

**Choose Kanban if:**
- Work comes from webhooks at high volume
- No human approval gate needed between stages
- Worker pool scales to 100+ nodes
- Dispatch must be fully automatic with no human gate

## Pitfalls

1. **Profiles changing status when they shouldn't**
   - Only Laura changes status
   - Other profiles post evidence comments only
   - Laura reads evidence, decides next stage

2. **Evidence comments not JSON-parseable**
   - Use consistent format so future parsing works
   - Include profile + timestamp + status in every comment

3. **Neil never seeing the Telegram approval gate**
   - Laura must post to Telegram (not silent)
   - Neil approval must flow back to Linear (not forgotten)

4. **Multiple profiles stepping on each other**
   - Different crony intervals (Laura 2min, others 5min)
   - Laura is the only status-changer
   - Each profile watches for assigned + not done

5. **Himalaya on Control Plane instead of Desktop**
   - User-facing comms should be on Desktop
   - Control Plane should be pure ops (no user interaction)

## Verification Checklist

- [ ] Each profile has OAuth token in ~/.hermes/profiles/X/.env
- [ ] Laura is the only profile changing status/assignee
- [ ] Mai/Kai/Rai post evidence comments (structured JSON)
- [ ] Telegram approval gate posts from Laura
- [ ] Neil's approval flows back to Linear (Digital Twin reads and updates)
- [ ] Cron intervals are different (Laura 2min, others 5min)
- [ ] Himalaya installed on kohd-hub (not Control Plane)
- [ ] Evidence comments are parseable (not free-form)
