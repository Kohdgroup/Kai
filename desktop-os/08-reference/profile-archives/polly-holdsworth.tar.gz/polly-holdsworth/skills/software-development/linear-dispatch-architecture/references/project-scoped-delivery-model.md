# Project-Scoped Delivery Model (vs Generic Task Dispatch)

**Status**: NEW SESSION (2026-07-03) — Clarifies fundamental model shift from generic Rai task dispatch to PROJECT-SCOPED epics.

## Problem Statement

Previous sessions assumed **generic task dispatch**: Linear issues flow in → Rai routes by skill → profiles execute in parallel → done.

**Reality (discovered from KOHD workspace)**: The architecture serves **PROJECT-SCOPED DELIVERY**, not generic task routing. Example:

- **KOHD Heritage GTM** (61 issues, 2 main epics):
  - Epic 1: **KS-2999** "Programme Control" (29 subtasks) — Full GTM rollout (WS04-WS12 workshops, plus pilot + scale)
  - Epic 2: **KS-3048** "Platform Readiness" (9 subtasks) — Hermes V3 validation
- **KOHD Membership Cards** (another project, 1000+ nested issues across similar workshop/platform structure)

**The difference**:
- Generic task dispatch: Random issues flow in; dispatcher routes by skill; execution is independent per issue.
- Project-scoped delivery: Epics are committed units (Laura tells Rai "deliver KS-2999 phase 1"); Rai orchestrates skill-coordinated execution; dependencies may exist within the epic; deployment at epic boundaries.

## Architecture Changes

### Intake: Laura is the Sprint Planner

Instead of: "All ready issues flow to Rai; Rai dispatches all."

Do this: "Laura says 'deliver KS-2999 Phase 1 (WS04-WS06) by Friday'; Rai reads that epic scope and dispatches only those issues."

Rai queries for issues with:
- Parent epic = KS-2999
- State != Done
- (Optional) Sprint tag or custom field for phase boundaries

### Dispatch: Skill-Based, Not Random

Rai groups issues by inferred skill:
- **backend** → kai-backend, kai-sre
- **frontend** → freddy-frontend, jane-designer, alex-designer
- **design** → jane-designer, alex-designer, freddy-designer
- **devops** → rai-sre, kai-validator

Query kanban.db: "Who has capacity in this skill? Pick least-loaded."

### Execution: Parallel Within Epic

Multiple skills execute in parallel:
- Backend builds API (3 days)
- Frontend builds UI (2 days)
- Design creates assets (1 day)
- DevOps handles infra (2 days)

All report into the same epic in Linear.

### Completion: Epic-Gated, Then Deploy

When ALL issues in epic = Done:
- Rai posts to Linear: "KS-2999 Phase 1 complete; ready to deploy"
- Trigger deployment automation (GitHub Actions, CD pipeline)
- Customers can now use the delivered solution

Then the **recurring automations** kick in:
- GHL webhook: "New customer signed up" → Creates intake issue → Rai dispatches
- Sunday cron: "Get player stats for {customer}" → Runs data sync profile

## Skill Induction

The workspace doesn't have explicit **Skill** fields yet. Infer from:

**Option A: Issue title/description parsing**
- "Build backend API" → backend
- "Design login UI" → frontend
- "Deploy to prod" → devops

**Option B: Add Linear custom field**
- `Skill: backend | frontend | design | devops | data | ops`
- Rai runs GraphQL query: Filter issues by `skill` field

**Option C: Label-based**
- Tag issues with `skill-backend`, `skill-frontend`, etc.

**Recommendation**: Use **Option B (custom field)** — most explicit, easiest for Rai to query.

## Laura's Role in the Model

Laura is **the sprint orchestrator**, not a worker.

- She sits with you (Neil) in planning.
- You tell her: "Build Heritage membership this quarter."
- She breaks that into epics in Linear (WS04-WS06).
- She tells Rai: "Deliver KS-2999 Phase 1 by Friday."
- Rai reads the epic, dispatches profiles, orchestrates delivery.
- Profiles execute 24/7; you sleep.
- Laura monitors blockers (Telegram standup); escalates to you as needed.

**Laura does NOT execute code.** She is the **orchestration conductor**, not a worker in the pool.

If Laura also has a worker profile (e.g., `laura-orchestrator` + coding skills), that's a separate concern — she can claim kanban tasks for coding work, but her PRIMARY role in the model is orchestration.

## Unattended Execution (While You Sleep)

Both **implementation** and **automations** run 24/7:

```
SHORT TERM (Implementation):
  Rai + Kanban dispatch implementation epics
  Profiles execute (backend, frontend, etc.) in parallel
  If blocker: Profile posts to Linear, Telegram alerts Laura
  Laura decides if escalation needed; posts to Linear; profiles resume
  When epic done: Deploy to prod

LONG TERM (Post-Delivery Automation):
  Customer signs up → GHL webhook → Linear intake issue
  Sunday cron fires → Data sync profile executes
  Results post back to Linear/GHL
  No human involvement needed
```

## Key Differences from Generic Task Dispatch

| Aspect | Generic Dispatch | Project-Scoped Delivery |
|--------|------------------|----------------------|
| **Intake** | All ready issues flow to Rai | Laura chooses epic scope; Rai dispatches that epic only |
| **Grouping** | Issues routed independently | Issues grouped by epic; orchestrated as a unit |
| **Dependencies** | Assumed independent | May have within-epic deps (backend → frontend, etc.) |
| **Completion Signal** | Issue done = issue complete | Epic done = solution ready to deploy |
| **Deployment** | N/A (no deployment concept) | At epic boundaries; production release |
| **Recurring Work** | Each issue is separate | Epics are one-time; separate recurring patterns (webhooks, crons) |

## Implementation Pattern for Rai

```python
# Rai cron (every 60s)

def dispatch_cycle(epic_scope: str):
    # epic_scope = "KS-2999 Phase 1" or similar
    # Set by Laura in Linear (custom field or Slack)
    
    # Phase 1: Read epic scope from Linear
    epic_issues = query_linear(f"parent = {epic_scope} AND state != Done")
    
    # Phase 2: Group by skill
    skill_groups = group_by_skill(epic_issues)
    
    # Phase 3: Dispatch
    for skill, issues in skill_groups.items():
        for issue in issues:
            # Skip if already running
            if issue.state == "running":
                continue
            
            # Query kanban: which profiles alive + have capacity?
            available = query_kanban(f"skill = '{skill}' AND heartbeat < 1h")
            least_loaded = min(available, key=lambda p: count_running_tasks(p))
            
            # Create kanban task
            kanban_create(
                assignee=least_loaded,
                title=issue.title,
                body=issue.description,
                metadata={"linear_issue_id": issue.id}
            )
            
            # Post to Linear
            linear_comment(issue.id, f"Dispatched to {least_loaded}")
    
    # Phase 4: Completion detection
    done_tasks = query_kanban(f"status = done AND updated > 1min_ago")
    for task in done_tasks:
        issue_id = task.metadata["linear_issue_id"]
        update_linear(issue_id, state="Done", summary=task.summary)
    
    # Phase 5: Check if epic is complete
    epic_issues_remaining = query_linear(f"parent = {epic_scope} AND state != Done")
    if not epic_issues_remaining:
        linear_comment(epic_id, "✅ Epic complete; ready to deploy")
        trigger_deploy_pipeline()
```

## Open Questions for Rai Implementation

1. **Who/how does Laura signal which epic to work on?**
   - Custom Linear field (`Active Epic: KS-2999`)?
   - Slack command (`/dispatch kS-2999`)?
   - Manual marking in Linear UI?

2. **Do some issues within epic have hard dependencies?**
   - E.g., "Backend API stub" must complete before "Frontend UI" starts?
   - If yes, Rai needs to detect and respect blocker relationships.

3. **Deployment trigger and destination:**
   - Auto-deploy to staging on epic complete?
   - Manual approval before prod?
   - GitHub Actions, CD pipeline, or custom script?

4. **Recurring automations (post-delivery):**
   - Are they separate from the epic dispatch model?
   - Do they use the same profiles or separate ones?
   - Example: Sunday player stats sync — is that a Rai cron, a profile cron, or a webhook handler?

## Recommended Next Steps

1. Add Linear custom field: `Skill` (enum: backend, frontend, design, devops, etc.)
2. Tag each issue in KOHD Heritage epic with its skill.
3. Design the "active epic" signal mechanism (field, comment keyword, Slack, etc.).
4. Build Rai dispatcher cron to read that signal and run dispatch_cycle().
5. Test with KS-2999 Phase 1 on staging.

---

**Related**: See `references/team-centric-routing-linear-custom-fields.md` for custom field policy when you want team-level abstractions instead of direct skill assignment.
