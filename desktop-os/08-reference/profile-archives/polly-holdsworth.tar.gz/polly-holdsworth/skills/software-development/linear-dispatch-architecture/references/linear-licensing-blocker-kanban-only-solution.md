# Linear Licensing Blocker & Kanban-Only Solution (2026-07-03)

## The Blocker: Enterprise Licensing Model

**Discovery (2026-07-03):**
Linear Enterprise pricing charges **1 paid seat per person assigned to an issue**. This means:
- 80+ individual OAuth profiles = 80+ paid seats = prohibitively expensive
- Original design (distribution of work via Linear assignee field to unique profiles) is **cost-prohibitive**
- Cannot use per-profile OAuth identity for Linear assignee mutations

**Reference**: [Linear Support Documentation](https://linear.app/support) confirms:
> "Yes, every person assigned to an issue must have a paid license if your workspace is on a paid plan. Linear does not support free 'view-only' or 'assignee-only' accounts for external clients or contractors."

## The Solution: Kanban-Only Assignment + Team Leads as OAuth Actors

### Architecture Shift

**Linear's role (intake + output only):**
- Issues created by humans (Laura, Rai) with Business Unit custom field
- Status: Ready for dispatch
- **Assignee: NEVER SET or set to shared "Rai Automation" team account (1 seat)**
- Comments written by Team Leads (Design Team, Marketing Team, etc.) as OAuth actors

**Kanban's role (true dispatch + execution):**
- Rai creates kanban tasks with `assignee="jane-designer"` (profile name, not Linear)
- Kanban dispatcher routes to that profile
- Profile executes, heartbeats, completes
- Result summarized back to Linear

### Cost Model

**Before (infeasible):**
- 80+ profiles × Enterprise seat cost = $$$,$$$ per month

**After (feasible):**
- 1 seat for Rai (reads/writes Linear)
- 3-5 seats for Team Leads (Design Team, Marketing Team, Eng Team, etc.) as OAuth actors for team-level comments
- Total: 4-6 seats

## Implementation Checklist

### Rai Linear Mutation: Explicit Field Allowlist

```python
# In Rai's Linear update logic:
allowed_fields = ["state", "title", "description", "custom_fields"]
mutation_input = {k: v for k, v in issue_update.items() if k in allowed_fields}

# Verify assignee never sneaks in:
assert "assignee" not in mutation_input, "BLOCKER: assignee field must not be in Linear mutation"
```

### Linear Custom Field: Executor Profile (Optional Metadata)

If team-level accountability is insufficient, add a custom field to track executor:

**Field name:** `Executor Profile`
**Type:** Text (read-only, populated by Rai)
**Example values:** `jane-designer`, `kai-backend`, `amelia-ops`

When task completes, Rai:
1. Reads kanban task metadata: `{"executor": "jane-designer", ...}`
2. Updates Linear custom field `Executor Profile` = "jane-designer"
3. Posts team-level comment: "Design Team completed logo redesign. Executor: jane-designer."

### Kanban Assignee: 100% Native

**Kanban task assignment is native v0.18.0:**

```python
kanban_create(
    title="Build payment API",
    assignee="kai-backend",  # Profile name, not Linear user ID
    body="Stripe integration endpoint",
    status="ready"
)
```

**Dispatcher behavior (native):**
1. Reads task: `assignee="kai-backend"`
2. Spawns profile `kai-backend` (wherever it's alive across nodes 01-09)
3. Profile calls `kanban_show()` to read task details
4. Profile executes work
5. Profile calls `kanban_complete(summary="...")` when done

**This does NOT consume a Linear seat.**

## Audit Trail: Dual-Layer Accountability

**Linear level (team):**
```
Issue: "Build payment API" [DONE]
Comment by Design Team (OAuth actor):
  "Completed. Summary: Stripe endpoint live on staging, ready for QA."
```

**Kanban level (individual):**
```
Task: "Build payment API"
Assignee: kai-backend
Heartbeats: 2026-07-03 15:00 UTC, 15:05 UTC, 15:10 UTC (executor alive)
Completed: 2026-07-03 15:27 UTC by kai-backend
Summary: "Stripe endpoint live on staging, ready for QA."
```

**Hermes logs (full detail):**
```
[15:00] ka-backend claimed task on node-06
[15:01] kai-backend: POST /api/payments/webhook → 201
[15:05] kai-backend: Test sync ✓
[15:10] kai-backend: heartbeat OK
[15:27] kai-backend: task complete
```

## When NOT to Use This Pattern

- If individual profile identity in Linear is business-critical (e.g., GDPR audit trail requires "jane signed off on this")
  - *Alternative:* Keep fewer profiles (5-10 core leads), each gets a Linear seat, and use team leads as the primary assignment surface
- If Linear assignee field is already in use for other routing workflows
  - *Alternative:* Migrate to a custom field (e.g., `dispatch_target`) alongside assignee, and don't mutation assignee in Rai

## Open Questions

1. **Kanban dashboard UI**: Does Hermes v0.18.0 provide a native web UI for manually creating/viewing kanban tasks? (Not yet verified; see `hermes-agent` skill.)
2. **Team Leads OAuth setup**: How to register multiple OAuth actors (Design Team, Marketing Team, etc.) in the same Linear workspace? (Linear docs unclear on team-level vs. user-level OAuth.)
3. **Metadata format in kanban**: What custom fields/metadata should a kanban task carry to enable Rai replay? (e.g., `{"linear_issue_id": "...", "executor": "...", "timestamp": ...}`)
