---
name: adf-solution-blueprint
description: Use when a KOHD/ADF project needs a live solution blueprint that documents integrations, dataflows, auth, ownership, and platform dependencies in a versionable, reusable format.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [ADF, blueprint, architecture, integrations, dataflows, auth, documentation, reusable]
    related_skills: [adf-platform-dependency-framework, adf-project-handoff-template, versioned-architecture-repo-bootstrap, linear-native-operating-model, linear-accurate-updates]
---

# ADF Solution Blueprint

## Overview

Use this skill to maintain a live solution blueprint for KOHD and related ADF projects. The blueprint is the durable, versioned narrative of how the system fits together: platforms, integrations, authentication, dataflows, responsibilities, failure modes, and validation points.

It is not a sprint plan. It is not a milestone list. It is the architectural source of truth that Laura, platform owners, and future projects can all reference.

## Companion artifacts
- `docs/kohd-platform-registry.md` — canonical platform inventory
- `docs/kohd-platform-matrix.md` — quick-reference operational matrix
- `docs/kohd-operating-model-index.md` — top-level index for the KOHD ADF operating model

Use the registry for canonical ownership and live status, the matrix for quick lookup, and the index as the landing page. Keep the three artifacts synchronized whenever platform ownership, auth, or dataflow changes, and record review-gate ownership explicitly when the review team differs from the execution team.

## When to Use

- A project spans multiple external platforms and needs an enduring architecture reference
- You need a living document for integrations, auth, and data movement
- The project needs to be documented for future reuse, audits, handoffs, or onboarding
- Platform work is being organized into Linear issues and must stay aligned with a blueprint

## Blueprint Sections

Use the same structure every time:

1. **Purpose and scope**
2. **Actors and ownership**
3. **Platform inventory**
4. **Integration map**
5. **Authentication and access model**
6. **Dataflow map**
7. **Source of truth rules**
8. **Operational triggers and automations**
9. **Validation and monitoring**
10. **Failure modes and recovery**
11. **Open questions / decisions**
12. **Change log**

## Required Content by Section

### 1) Purpose and scope
Explain what the blueprint covers and what is explicitly out of scope.

### 2) Actors and ownership
List the responsible actor or team for each workstream. Keep Laura’s role in delivery planning explicit, and keep platform ownership separate.

### 3) Platform inventory
For each platform, record:
- role in the system
- why it exists
- reusable skill name
- owner / team
- what it depends on

### 4) Integration map
For each integration, document:
- source
- destination
- trigger
- transport method
- data shape / payload notes
- frequency / event model

### 5) Authentication and access model
Record:
- auth mechanism
- credential storage location or policy
- OAuth / API / MCP / UI access method
- rotation or refresh expectations
- audit / identity considerations

### 6) Dataflow map
Describe the important flows end to end:
- intake
- enrichment
- routing
- persistence
- reporting
- feedback loop back into Linear or docs

### 7) Source of truth rules
Say which system owns each class of truth:
- project truth
- customer truth
- CRM truth
- automation truth
- doc truth

### 8) Operational triggers and automations
Explain what events cause movement between platforms or teams.

### 9) Validation and monitoring
Include the first validation step for each platform and how to tell when it is healthy.

### 10) Failure modes and recovery
Record the likely failure modes, how they show up, and the first recovery action.

### 11) Open questions / decisions
Keep unresolved items visible rather than burying them.

### 12) Change log
Every meaningful architecture change should leave a dated note.

## Operating Rules

- Keep the blueprint live and current; do not let it become a stale design artifact.
- Update the blueprint whenever a platform issue changes the integration or auth model.
- Keep the blueprint versioned in git or another controlled repository.
- Mirror important blueprint decisions back into Linear so the live project stays aligned.
- Use the blueprint to drive issue breakdown, not the other way around.

## Recommended KOHD platform inventory

- Linear
- Himalaya
- Google Workspace
- Go High Level
- FlowFuse
- MCP integrations where applicable

## Pitfalls

- Do not mix sprint planning into the blueprint.
- Do not leave platform auth unspecified.
- Do not describe integrations without their source, destination, trigger, and failure mode.
- Do not let the blueprint drift away from the Linear issue structure.
- Do not store secrets in the blueprint.

## Verification Checklist

- [ ] Blueprint has a clear scope statement
- [ ] Every platform has a role, owner, and skill mapping
- [ ] Integrations are documented with source, destination, trigger, and transport
- [ ] Authentication is documented without secrets
- [ ] Dataflows and source-of-truth rules are explicit
- [ ] Failure modes and validation steps are present
- [ ] Change log exists and is updated when architecture changes
- [ ] Blueprint is versioned and mirrored back into Linear when needed
