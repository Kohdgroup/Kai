---
name: linear-native-work-claiming
description: Use when profiles need a native Linear-first method to discover, claim, and heartbeat work from unique per-profile signals while keeping the system of record authoritative.
version: 1.0.1
author: Hermes Agent
license: MIT
platforms: [linux, macos]
metadata:
  hermes:
    tags: [linear, autonomous, dispatch, heartbeat, work-claiming, profiles, control-plane]
    related_skills: [linear-native-operating-model, linear-dispatch-architecture, hermes-agent]
---

# Linear Native Work Claiming

## Overview
Use this skill when the operating model needs to let Hermes profiles pick up work natively from Linear without a bespoke second queue. It defines how profiles heartbeat, how they discover unique work, how they claim it, and how the control plane keeps the record authoritative.

The native principle is:

> shared heartbeat, unique work signal

Profiles should not all stare at the same generic "start". Each profile should see a unique Linear signal that tells it what to pick up next.

## When to Use
- Designing autonomous work pickup in Linear-first systems
- Defining how a profile knows which issue is "its" work
- Keeping control-plane auth separate from worker execution
- Making sure a profile can begin work without manual re-interpretation
- Creating a repeatable native startup path for Laura or any other profile

## Core Model

### 1) Shared heartbeat
Every profile emits or refreshes a heartbeat so the control plane can tell it is alive.

A heartbeat is a lightweight coordination signal, not business truth. It can be represented in Redis, a dispatch board, or another control-plane coordination layer.

### 2) Unique Linear work signal
Each profile gets a unique Linear object that represents its next claimable work.

Examples:
- a profile-specific kickoff issue
- a labeled issue in a profile’s lane
- an issue state that means "claim me"
- an assignment or child issue that belongs to that profile

The work signal must be unique enough that the profile knows exactly what to do next.

### 3) Claim step
When the profile sees its unique signal, it claims the work by doing one of:
- writing a Linear comment/update
- moving the issue to In Progress
- creating the first child breakdown
- taking assignee ownership when scope permits

### 4) Evidence step
The profile records proof of action back into Linear.

Proof can include:
- start comment
- first sprint cut
- readiness or smoke proof
- validation evidence
- blocker note

### 5) Staleness handling
If the heartbeat is stale or the claim never appears:
- the control plane re-evaluates the signal
- the issue is re-dispatched or escalated
- the user can be notified through the chosen feedback channel

## Native Work Claiming Flow
1. Profile heartbeats.
2. Control plane sees the profile is alive.
3. Linear exposes a unique work signal for that profile.
4. Profile claims the issue.
5. Profile performs the first action.
6. Profile writes back evidence.
7. Control plane marks the state as underway.
8. Continued heartbeats keep the work live.
9. When the work is complete, final evidence is written back to Linear.

## Dispatch enforcer pattern
If the human profile is not visibly starting, use a lightweight enforcer to keep the model moving:
- poll the sentinel issue for the profile lane
- post a single nudge when the claim trail is missing
- post a separate nudge for the faceless worker lane
- run on a short cadence such as every few minutes
- stay silent when both lanes already have visible activity

This is a nudge layer, not a second source of truth. It must never replace Linear or become a parallel queue.

## Two claim paths
The operating model must support both of these paths at once:

### Laura claim path
Use this when the work needs human delivery ownership, sprint slicing, or review-gate coordination.
- Laura claims the KOHD kickoff signal.
- Laura’s first visible action is a comment, update, or breakdown.
- The control plane watches for a Laura-authored trail.
- Laura’s claim does not block faceless workers.

### Faceless worker claim path
Use this when the work is pure execution.
- A faceless worker claims the next node, automation, or maintenance item.
- The worker executes the assigned check or job.
- The control plane records evidence and keeps the lane moving.
- Faceless worker dispatch continues even if Laura has not started yet.

The two paths are parallel, not exclusive.
A Laura delay must never prevent faceless worker dispatch.
A faceless worker completion must never be mistaken for Laura’s sprint start.

## KOHD Application
For KOHD and Laura:
- Laura’s unique work signal is the KOHD kickoff issue and first child issue in her lane.
- The visible start state is the kickoff issue moving to active.
- Laura’s first claim should produce a visible Linear trail.
- Her heartbeat after that proves work is actively underway.
- Faceless workers remain eligible for dispatch independently of Laura.

## Operating Rules
- Linear is the system of record.
- Workers do actual work; the control plane coordinates and writes evidence.
- Avoid a second queue if Linear can represent the work signal directly.
- Keep profile-specific signals explicit.
- Do not confuse heartbeat with completion.
- Do not treat a subscribed issue as claimed unless the first action is visible.
- A dispatch enforcer may ping both lanes on a cadence, but it must never conflate Laura start with faceless-worker progress.

## Implementation Hints
- Use Redis or similar coordination state for heartbeat freshness.
- Map each profile to one or more Linear issues or issue markers.
- The dispatcher should prefer the next unique issue for that profile rather than a generic backlog pile.
- If an issue is intended for Laura, make that explicit in the issue title, description, state, or child structure.
- Re-check for visibility before escalating a stalled claim.
- Small cron jobs are acceptable as a native nudge layer when they keep the system moving without creating a second source of truth.

## Failure Modes
- **No unique work signal:** the profile knows it is alive but has nothing clear to claim.
- **Signal exists but no claim:** the profile is not yet actually starting.
- **Claim exists but no heartbeat:** the profile may have stalled or lost coordination.
- **Heartbeat exists but evidence missing:** the work is active but not auditable.

## Verification Checklist
- [ ] Each profile heartbeats
- [ ] Each profile has a unique Linear work signal
- [ ] The claim step is visible in Linear
- [ ] Evidence is written back to Linear
- [ ] Staleness is detectable
- [ ] Re-dispatch/escalation path exists
- [ ] Laura’s signal is unambiguous
- [ ] Faceless-worker dispatch still runs while Laura is pending
