---
name: linear-dispatch-architecture-notes
description: Session-specific notes for KOHD native Linear dispatch, including the visible start-signal pattern used to get Laura underway.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [linear, dispatch, koehd, laura, start-signal, session-notes]
---

# KOHD Native Dispatch Notes

This note captures the session-specific start pattern that proved useful for KOHD.

## Pattern
- create an explicit start-signal issue
- create a kickoff child issue
- subscribe Laura to both
- move the kickoff issue to In Progress when the control plane is ready
- post a control-plane note that the kickoff is active
- only call Laura “underway” when a visible action trail appears on the kickoff issue

## What counts as underway
- Laura-authored comment/update
- sprint-cut artifact
- visible state change tied to the kickoff issue

## Pitfalls
- subscribed is not started
- assignment may be blocked by app scope
- keep the signal in Linear, not just in chat
