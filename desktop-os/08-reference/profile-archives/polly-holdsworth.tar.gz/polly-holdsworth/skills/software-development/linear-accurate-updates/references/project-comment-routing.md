# Linear Project Comment Routing Notes

## Session-derived lesson
When a user refers to the "main project comments" on a Linear project, do **not** assume they mean issue comments or project status updates.

### What was confirmed
- The Linear MCP `mcp_linear_list_comments` tool accepts `projectId`.
- The same tool can target one parent entity at a time: `issueId`, `projectId`, `initiativeId`, `documentId`, or `milestoneId`.
- For a project feed, use `projectId`, not `project`.
- `mcp_linear_get_status_updates` targets **project or initiative status updates** only; it is not the project discussion feed.
- If `get_status_updates` returns none, that does **not** prove the project has no visible project comments.

### Practical correction pattern
1. Fetch the project record first.
2. Use `mcp_linear_list_comments(projectId: ...)` to inspect the project's visible discussion/comments.
3. Use `mcp_linear_get_status_updates(projectId: ...)` only to inspect update posts / health posts.
4. If the user asks to fix author identity, delete/recreate only after positively identifying the exact project-level comment or update.
5. If the MCP path keeps routing to issue comments or returns `Issue not found`, stop and verify the exact entity type before modifying anything.

### Author correction caution
- Do not rewrite a project feed item unless you can see the original id, body, and author.
- If the project page visually shows two comments but the MCP tools do not return them, ask for a screenshot or the exact body text instead of guessing.
- Session lesson: even after the OAuth app path was configured, `mcp_linear_list_comments(projectId=...)` repeatedly misrouted to `Issue not found` and later reported the `linear` MCP server as unreachable after consecutive failures. In that state, do not infer the project feed is empty; wait for recovery or switch to a UI/screenshot-based identification pass.
