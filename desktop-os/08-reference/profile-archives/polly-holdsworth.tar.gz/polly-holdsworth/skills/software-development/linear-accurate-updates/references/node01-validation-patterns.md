# Node01 + Linear OAuth Validation Reference

## Server-hop node01 verification
Use this path for node01 checks during the current validation phase:
- local machine -> control-plane server `192.168.60.10` -> node01 `192.168.60.11`

Observed evidence pattern:
- UTC timestamp from node01
- container image pinned to `nousresearch/hermes-agent:v2026.7.1`
- container state: running / restarting=false / exit=0
- tail of worker logs

## Worker identity proof pattern
For OAuth app / worker identity validation:
1. Query `viewer` first.
2. Create a Linear comment.
3. Query the created comment back.
4. Confirm the `user` fields match the intended worker identity.

This session validated the following worker identities as comment-capable:
- Laura Bennett
- Maya Khan
- Quinn Graham
- Thomas Advani
- Amelia Cross
- Joseph Webb
- Eve Sterling
- Rai Matsuda
- Kai Matsuda
- Mai Matsuda

## Done-done gate pattern for node01
Before scale-out to node02–node09, complete:
- readiness via server hop
- one non-trivial smoke action
- controlled recovery / restart check if requested
- final Linear sign-off from the nearest matching worker identity

## Timeout wrapper pattern
When chaining node01 checks, prefer:
- one step per script, or
- a wrapper that enforces a per-step timeout and continues to the next step on failure/timeout

This prevents a single stall from blocking the rest of the validation sequence.
