# node01 Dispatch Validation Reference

## Purpose
Use node01 as the golden worker for dispatch validation until the control plane + node01 path is fully proven. Keep the Linear trail current and explicitly avoid scale-out language.

## Evidence checklist
Capture all of the following before posting a completion-style Linear comment:
- UTC timestamp on node01
- container image tag
- container state (`running`, `restarting`, `exit code`)
- command executed on node01
- relevant log excerpt showing the command actually ran
- whether the node stayed up after the command

## Proven smoke-test flow from this session
1. Start node01 on `nousresearch/hermes-agent:v2026.7.1`.
2. Verify `docker inspect` shows `running`, `restarting=false`, and `exit=0`.
3. Run `/opt/hermes/bin/hermes doctor` inside the worker container.
4. Confirm the doctor output succeeds and the worker remains running.
5. Post the result to KS-3048 immediately after the host evidence.

## Comment template
```text
Actor: KOHD Human Style Worker as Mai
Current checkpoint:
- Node01 host timestamp: <UTC timestamp>
- Command executed on node01: `<exact command>`
- Container image: `nousresearch/hermes-agent:v2026.7.1`
- Container state: running / restarting=false / exit=0
- Logs show the command ran and the gateway remained up
- No other worker nodes were used
```

## Anti-patterns
- Do not say a dispatch path is proven unless the host evidence supports it.
- Do not imply readiness for other workers from a single-node check.
- Do not leave stale blocker language in the parent or sub-issues.
- Do not post generic progress when a fresh host check is available.
