# Linear OAuth Actor Auth Notes

## Why this matters
Use Linear OAuth actor authorization when you need comments or issue mutations to appear as an app/service-account identity instead of a personal user.

## Key doc-backed facts
- Default Linear API auth treats the authenticating user as the actor.
- OAuth actor authorization adds `actor=app` to the OAuth authorization URL.
- With `actor=app`, mutations such as creating issues, comments, and status changes come from the app itself.
- Linear docs describe this mode as particularly useful for agents and service accounts.
- Linear docs also allow `createAsUser` and `displayIconUrl` on `issueCreate` and `commentCreate` to render a custom application identity.
- This is the right path when you want KOHD-style worker comments without assigning a new human Linear user.

## No-extra-licenses rule
- Do not create a new human Linear user just to represent a worker.
- Do not consume an extra human seat for KOHD worker comments.
- Prefer app identity via OAuth actor authorization.

## Practical identity pattern
Recommended display name for validation comments:
- `KOHD Human Style Worker as Mai`

Recommended test comment shape:
- `Actor: KOHD Human Style Worker as Mai`
- include the live checkpoint and host evidence
- keep the issue/parent issue current
