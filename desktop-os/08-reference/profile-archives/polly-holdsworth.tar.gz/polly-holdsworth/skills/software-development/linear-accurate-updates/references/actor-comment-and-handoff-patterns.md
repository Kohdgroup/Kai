# Actor comment and fresh-handoff patterns

Session-derived notes for the Linear operating model.

## Use case
Use this pattern when a project is being groomed for handoff to Laura / sprint planning and the user explicitly wants documentation to be visible in Linear.

## Pattern
1. State clearly that the project is a fresh review.
2. Separate shared framework work from delivery work.
3. Create or update a grooming checkpoint issue in the delivery team.
4. Add actor comments to the project and checkpoint issue.
5. Write a project update summarizing the structural split.
6. Only hand over items that are genuinely sprint-ready.
7. Leave the rest in grooming/backlog until dependencies are satisfied.

## Actor comment shape
- First line: `Actor: KOHD Human Style Worker as <name>`
- Follow with `Current checkpoint:`
- Then 2-4 bullets for what changed and what remains

## Good practice
- Use Mai for setup / governance / framework splits.
- Use Laura for readiness / sprint planning checkpoints.
- Use the project update for the running narrative.
- Use the grooming issue for the concrete handoff boundary.

## Avoid
- Silent changes with no comment trail
- Assuming prior readiness without saying the review is fresh
- Pulling shared framework work into sprint planning unless it is explicitly in scope
- Handoffs that do not name what remains in grooming

## Example
```text
Actor: KOHD Human Style Worker as Mai
Current checkpoint:
- EcoPUK is being treated as a fresh review
- Platform integrations are being split into a reusable framework
- Laura will only plan from the ready delivery slice
```
