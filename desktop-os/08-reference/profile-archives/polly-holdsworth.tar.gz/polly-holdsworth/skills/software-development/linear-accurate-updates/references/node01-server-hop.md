# Node01 Server-Hop Validation Notes

## Purpose
When validating node01, use the control-plane server (192.168.60.10) as the SSH hop instead of direct SSH from the local machine.

## Observed working path
- Local machine -> control-plane server (192.168.60.10) -> node01 (192.168.60.11)
- Direct local SSH to node01 can fail if local credentials are not provisioned for node01.
- The server-side hop successfully captured the node01 readiness evidence.

## Evidence pattern to capture
- UTC timestamp from node01
- Worker container image
- Container runtime state (running / restarting / exit code)
- Tail of worker logs

## Recommended probe shape
Use the control-plane server to run:
- `date -u +%Y-%m-%dT%H:%M:%SZ`
- `docker inspect hermes-worker --format ...`
- `docker logs --tail 20 hermes-worker`

## Operational rule
Treat the server-hop path as the default verification path for node01 during the current validation phase unless the user explicitly requests another route.
