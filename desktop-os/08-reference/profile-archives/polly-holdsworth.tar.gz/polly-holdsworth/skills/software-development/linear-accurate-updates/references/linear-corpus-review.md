# Linear corpus review notes

Use this when the user asks for a breadth review across *all* Linear issues, including completed and archived issues.

## Reliable query shape
- Prefer the GraphQL `issues` connection, not only search endpoints.
- Include `includeArchived: true` when the goal is a full corpus census.
- Paginate through `first`/`after` until `pageInfo.hasNextPage` is false.
- Fetch at least: `id`, `number`, `title`, `completedAt`, `archivedAt`, `state { name type }`, `team { key name }`, `project { name }`, `labels { nodes { name } }`, `updatedAt`, `createdAt`.

## Why this matters
- `searchIssues` / `issueSearch` is useful for targeted lookups, but it is not the right primitive for a complete backlog census.
- Completed and archived issues are essential when the goal is to understand the breadth of what the team is building.
- A corpus review should report both totals and representative samples by team/project/state.

## Output pattern
A useful review usually includes:
- total issue count
- open / completed / archived counts
- top teams by issue volume
- top projects by issue volume
- recent completions as evidence of active themes
- a short synthesis of the dominant workstreams

## Quick GraphQL example
```graphql
query Issues($first:Int!, $after:String, $includeArchived:Boolean) {
  issues(first:$first, after:$after, includeArchived:$includeArchived, orderBy: updatedAt) {
    nodes {
      id
      number
      title
      completedAt
      archivedAt
      state { name type }
      team { key name }
      project { name }
      labels { nodes { name } }
      updatedAt
      createdAt
    }
    pageInfo { hasNextPage endCursor }
  }
}
```
