# Linear actor identity: KOHD as worker

## Durable finding
- Linear's default API auth treats the authenticating user as the actor.
- For worker-style comments/actions, use **OAuth actor authorization** so the action is performed by the app, not the user.
- The docs indicate `actor=app` on the OAuth authorization URL enables app-as-actor behavior.
- Linear also supports optional display metadata for app-authored actions:
  - `createAsUser`
  - `displayIconUrl`
- This is the preferred path when the user wants comments/updates to show as a worker identity such as **KOHD Human Style Worker as Mai** rather than the personal account owner.

## Practical implication
- Personal API keys are fine for admin/debug work, but not for persistent worker-identity comments.
- For human-style worker comments that must not appear as Neil, use a Linear app integration with OAuth actor authorization.

## Validation clue
If a comment appears as the account owner, the auth flow is still user-actor based. If it appears as app/user-via-application, actor auth is working.