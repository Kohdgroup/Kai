# Linear OAuth worker-auth notes

Source of truth: Linear developer docs for OAuth 2.0 authentication and OAuth actor authorization.

## Proven pattern
- Create a dedicated Linear OAuth2 application for the worker.
- Use the OAuth authorization URL with `actor=app`.
- Include the standard OAuth params: `client_id`, `redirect_uri`, `response_type=code`, and `scope`.
- Use only the minimum write scopes needed for the action.
- Exchange the auth code for access / refresh tokens server-side.
- Use the app token for GraphQL mutations such as `commentCreate`.
- Optionally set `createAsUser` and `displayIconUrl` on `commentCreate` or `issueCreate` so the action renders as a named worker/app identity.

## Verification pattern
1. Query `viewer` with the token.
2. Create a test comment on a known issue.
3. Query the created comment back.
4. Confirm the `user` on the comment is the OAuth app identity, not the human account that owns the browser session or personal API key.

## Operational caution
- A personal API key authenticates as its owning human account.
- Do not assume a worker label on the key is enough to change the Linear actor.
- For billing, describe the result conservatively as “no extra human seat implied” unless the workspace admin has separately confirmed plan policy.

## Test comment template
```text
KOHD worker validation:
- node01 is the golden worker for dispatch testing
- hermes-worker is running on `nousresearch/hermes-agent:v2026.7.1`
- host evidence and `hermes doctor` smoke test both completed successfully
- no restart loop observed during the test window
```
