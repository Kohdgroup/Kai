---
name: linear-accurate-updates
description: Use when updating Linear issues for Hermes or other human-actor workflows. Keep issue status, sub-issues, comments, and acceptance criteria current, avoid stale blockers, and prefer evidence-backed, actor-based updates.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [linear, issues, updates, validation, actors, accuracy]
    related_skills: [hermes-agent, hermes-agent-skill-authoring]
---

# Accurate Linear Updates

## Overview
Use this skill whenever you are making or revising Linear updates for the Hermes operating model. The goal is to keep Linear as the live system of record without stale blocker language, placeholder tickets, or progress claims that outlive the actual state of the stack.

This skill exists to keep updates grounded in current evidence and to make the issue trail usable for human and automated validation.

## When to Use
- Updating a live Linear issue with current deployment or validation progress
- Creating or revising setup/config issues that must support real test criteria
- Writing actor-based comments from Mai, Kai, Rai, Laura, Eve, Quinn, Maya, Thomas, Amelia, or Joseph
- Retiring or renaming stale blocker issues whose language no longer matches reality
- Preparing issues that will later drive test scripts or done-done sign-off
- Inspecting project-level comments vs project status updates; the two are different entities and must not be conflated

## Project Feed Routing Pitfall
When the user says "the main project comments" or points at a project feed:
- First determine whether they mean **project discussion comments** or **project status updates**.
- Use the correct Linear entity type before mutating anything.
- If a project feed is visible in the UI but the MCP path returns empty, `Issue not found`, or an unreachable-server error, do **not** infer that the feed is empty.
- Stop and verify the exact visible bodies/ids from the UI or a screenshot before deleting or recreating anything.
- Treat a zero-result status-update query as evidence only for status updates, not for project discussion comments.

## Core Rules
1. **Write only current truth.** If a blocker is resolved, rename it and say so. Do not leave “not deployed” or “not configured” language on an issue that is already past that state.
2. **Use actor mode for comments.** Every comment should clearly come from the relevant actor voice, even when the agent is speaking for a worker persona.
3. **Prefer evidence over assertion.** Comment updates should cite concrete checks: container state, API reachability, issue IDs, project IDs, node reachability, or completed validation steps.
4. **Keep sub-issues aligned to setup reality.** Setup/config tickets should contain business requirement, acceptance criteria, and done-done validation criteria. Avoid placeholders.
5. **Update the anchor issue continuously.** The parent validation issue (for example KS-3048) should always reflect the latest checkpoint and remaining blockers.
6. **Defer future-stage scope.** Only document the current phase unless the user explicitly asks for next-stage planning.
7. **Use the worker that matches the workstream.** Do not default to a single human identity. For Linear actor-mode comments, choose the nearest matching worker from the Mai/Kai/Rai mapping for the task phase and keep the label consistent with the work being described.
8. **Treat the current golden-worker or test-dispatch node as a separate phase.** If one node is designated as the only test target (for example node01), explicitly scope the issue comments and sub-issues to that node and say that scale-out is blocked until that node is proven.
9. **Prefer one-issue-at-a-time updates when freshness matters.** When a batch risks stale or partial truth, update the affected issue individually instead of grouping several comments together.
10. **Keep dispatch scope explicit in the record.** If the user has said all test work must flow through a single node, restate that rule in the anchor issue and in each relevant sub-issue.
11. **Use OAuth actor authorization for worker identities when available.** If the task is to make Linear actions appear as a worker/app instead of a human user, prefer a Linear OAuth2 app with `actor=app` over a personal API key.
12. **Do not assume a personal API key can impersonate a worker.** A bearer key may validate as the human account that owns it; verify the `viewer` and the created comment author before claiming worker identity.
13. **Keep billing claims bounded.** The app-actor path avoids creating a new human account in the workflow, but billing / seat implications should be stated as “no extra human seat implied” unless the workspace admin policy has been verified separately.
14. **Verify worker identity by round-tripping the created comment.** After a test comment, query the comment back and confirm the author fields resolve to the app/worker identity, not the personal account.
15. **Treat secrets as transient proof material, not skill content.** Never store Linear client secrets, access tokens, or refresh tokens in the skill text or references; rotate them after ad hoc testing.
16. **Use the control-plane server as the hop for node01 checks.** Capture node01 evidence by running checks from 192.168.60.10 through its SSH hop to node01, and keep the hop explicit in the evidence trail.
17. **Validate OAuth worker identities by round-tripping.** For worker-authored Linear actions, query `viewer` first, post the comment, then query the created comment back to confirm the author fields match the intended worker/app identity.
18. **Use a nearest-matching worker for the workstream.** For node01 validation, pick the human worker identity that matches the phase (for example Kai for pre-prod/validation) rather than a fixed default.
19. **Build a node01 done-done gate before scale-out.** Prove readiness, a real smoke action, a controlled recovery check, and a final Linear sign-off before unblocking node02–node09.
20. **Keep runnable validation scripts alongside the skill.** Prefer reusable scripts for readiness, smoke, and Linear sign-off so later sessions can re-run the same checks without retyping the flow.
21. **Use per-step timeouts and freshness checks.** When chaining node validation steps, prefer a wrapper that times out each step independently and re-checks the live state before the next action so a stalled step does not produce stale conclusions.
22. **Treat boot/power cycles as freshness boundaries.** If node01 reboots or a worker container exits unexpectedly, re-verify container state, logs, and restart policy before writing done-done language.
23. **Prefer a server-hop validation path when the environment uses one.** If node evidence is meant to come through the control-plane server, make that hop explicit in scripts and comments so direct-access failures do not masquerade as node failures.
24. **Prefer an all-in-one wrapper only when it preserves per-step timeouts.** A single runner is fine if each stage still times out independently and the script continues to the next step after a stall or failure.
25. **Keep a concise node-validation reference file for repeatability.** The session-specific validation pattern belongs in `references/node01-validation-patterns.md` so later sessions can re-run the same hop, smoke, timeout, recovery, boot-persistence, and sign-off checks.
26. **Treat clean-room proof as artifact hygiene, not a generic purge.** The goal is to show the worker is not relying on inherited tarballs, bootstrap bundles, or stale runtime leftovers; expected Hermes state files (for example the active `.env` under the Hermes home) are not automatically evidence of contamination.

## Update Pattern
For each Linear update, follow this order:
1. Identify the specific issue or project entity and current state.
2. Verify the current fact from a live source or tool result.
3. Decide whether the issue/project should be updated, renamed, commented on, archived, or left untouched.
4. Make the smallest change that preserves accuracy.
5. Re-read the entity after updating when possible.

## Corpus Review Pattern
When the user asks for a review of *all* Linear work, do not stop at targeted search results.
1. Query the `issues` connection directly.
2. Set `includeArchived: true`.
3. Page through the full result set with `after` until complete.
4. Summarize totals, status mix, top teams, top projects, and recent completions.
5. Use targeted search only to enrich or verify a subset after the census is complete.

## Project Comment Cleanup Pattern
When the user asks to fix author identity on project-level comments or updates:
1. Determine whether the visible trail is **project discussion comments** or **project status updates**.
2. Use the matching Linear entity type; do not assume `get_status_updates` covers all visible project comments.
3. If the MCP route returns `Issue not found`, an empty list, or an unreachable-server error, stop and verify the visible project feed from the UI/screenshot instead of guessing.
4. Only delete/recreate after you have the exact id, body, and current author for the specific item.
5. Prefer one current correction comment over a long historical trail.

- See `references/linear-corpus-review.md` for the canonical query shape and review checklist.
- See `references/actor-handoff-cleanup.md` for the cleanup and stale-artifact removal pattern used when grooming projects for Laura handoff.
- See `references/project-comment-routing.md` for the project-comment vs status-update routing rules that prevent accidental issue-comment lookups.

## Comment Pattern
Use short, structured comments with:
- actor name
- current checkpoint
- what changed since the last update
- what remains

Default actor framing for worker-style updates:
- Use **KOHD Human Style Worker as Mai** unless the user explicitly asks for another human role.
- Do **not** attribute worker-authored comments to Neil.
- Put the actor label on the first line when the user wants to validate the author identity.
- Prefer one clear comment over a long chain of incremental notes when the intent is a single status update.
- When the user asks for thorough documentation, write the comment in Linear first-class prose; do not rely on silent field edits alone.

Example:

```text
Actor: KOHD Human Style Worker as Mai
Current checkpoint:
- Control plane is live
- Linear access is confirmed
- Worker nodes are reachable
- Next: worker rollout validation
```

## Stale-Data Guardrails
- Do not keep historical blocker titles if the blocker has been resolved.
- Do not leave “placeholder” issue titles as if they were final requirements.
- If a sub-issue was created as a placeholder, expand it or clearly mark it as a scaffold until real requirements are added.
- If the parent issue is current but child issues are stale, update the child issues immediately; do not let the parent appear healthy while the subtree drifts.
- When the user says stale data is dangerous, treat it as a hard requirement for immediate cleanup.
- If progress is being reported, tie it to a fresh checkpoint (container state, logs, issue timestamp, or explicit verification) rather than a vague "still working" summary.
- If the user asks to remove old comments/artifacts from a project, delete stale comments first, then archive obsolete project updates, and verify the issue comment trail is clean afterward.

## Verification Checklist
- [ ] Updated issue titles still match reality
- [ ] Issue descriptions contain business requirement, acceptance criteria, and done-done criteria when appropriate
- [ ] Comments are actor-based and current
- [ ] Resolved blockers have been renamed or rewritten so they do not mislead future readers
- [ ] Parent validation issue reflects the latest checkpoint
- [ ] No future-stage scope was added unless requested
