# Actor handoff and cleanup patterns

Session-derived pattern for EcoPUK / BIZOPS grooming and handoff.

## What worked
- Treat the project as fresh unless the user explicitly says prior assumptions should stand.
- Keep reusable platform integrations in a shared framework project rather than duplicating them in delivery projects.
- Use short actor comments to record current checkpoint, next step, and handoff rule.
- When the user wants a clean sprint, remove stale comments and archived project updates from the active handoff trail.
- If a comment thread becomes confusing or redundant, delete the obsolete comments and leave only the current handoff note.
- If a project update is no longer useful, archive it after verifying the live state.
- Keep sprint planning with Laura autonomous; only intervene if Laura does not start or the workflow fails to activate.

## Useful Linear mutation patterns discovered
- `commentCreate` accepts `issueId`, `projectId`, `body`, and `createAsUser` only when the API actor mode supports it.
- If `createAsUser` fails, fall back to a normal comment with explicit actor text in the body.
- `commentDelete(id)` removes stale comments cleanly.
- `projectUpdateArchive(id)` removes old project-update artifacts from the visible trail.
- `issueUpdate(id, input)` is the right way to rename issues and simplify confusing titles/descriptions.

## Cleanup checklist
1. Read the live issue/project comments first.
2. Delete obsolete comments and stale handoff artifacts.
3. Rewrite issue titles/descriptions so the current scope is obvious.
4. Leave one current handoff comment rather than many historical notes.
5. Verify the issue/project after cleanup.

## Laura handoff rule
- Laura owns autonomous sprint planning.
- The assistant should groom, clean, and document.
- Only step in on Laura-related work if Laura fails to start or the pipeline needs fixing.

## Notes
This reference is intentionally narrow and session-specific; it records the cleanup pattern that emerged while grooming CD__ecopuk.
