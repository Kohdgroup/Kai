---
name: adf-project-handoff-template
description: Use when a Linear project needs a repeatable handoff artifact so Laura can begin sprint planning from a clean, explicit starting point. Clean stale artifacts, record the platform inventory, and write the standard handoff note in a reusable format.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [linear, handoff, laura, sprint-planning, reusable, template, ADF]
    related_skills: [linear-native-operating-model, linear-accurate-updates, linear-freshness-guard, adf-platform-dependency-framework]
---

# ADF Project Handoff Template

## Overview

Use this skill to produce a standard Linear handoff artifact for ADF-style projects. The artifact gives Laura a clean starting point, documents the platform dependency inventory, and keeps the handoff pattern reusable for future projects.

The goal is not to plan the sprint yourself. The goal is to prepare the project so Laura can plan it autonomously with no stale scaffolding, unclear ownership, or hidden platform dependencies.

## When to Use

- A project is ready to be handed to Laura for autonomous sprint planning
- Old comments, milestones, phase labels, or other scaffolding need to be cleaned first
- You need a repeatable handoff note that can be reused on future projects
- The project depends on external platforms that should be listed explicitly before Laura starts slicing work

## Workflow

### 1) Verify the live project state
Check the current Linear project for:
- milestones
- project comments / updates
- stale phase wording
- project relations
- unresolved blockers

If any of these are still active, clean them before writing the handoff artifact.

### 1b) Verify a visible start path exists for Laura
A handoff is not complete until Laura has a visible Linear path she can act on. If direct assignee/actioner writes are blocked by auth scope, create the strongest available surrogate start path:
- a clear start-signal issue
- Laura as subscriber/watcher on the start-signal issue
- a first actionable child issue under that signal
- a project update that names the start state and the available source artifacts
- a follow-up note that states which issue should show the first sign of movement

Do not claim Laura has started until there is an issue-level trail, not only a project update.

See `references/laura-start-signal-path.md` for the reusable Linear start-path pattern used when direct ownership writes are unavailable.

### 2) Record the dependency inventory
List the platforms the project depends on and map each one to its reusable skill or workstream.

For each platform capture:
- platform name
- why it matters
- skill to reuse or create
- first validation step
- likely failure mode

### 3) Write the handoff artifact in Linear
Create one clean project update using this structure:

```text
Actor: Platform Architect
Handoff: <project name> is ready for Laura to begin sprint planning from a clean starting point.

Platform inventory:
- <platform> — <role>
- <platform> — <role>

Reusable framework:
- Use separate platform workstreams under the anchor project
- Keep platform-specific validation, auth, and failure modes in the platform skills
- Do not use milestone scaffolding for sprint planning
- Laura owns sprint slicing from the live work, dependencies, and readiness

Next action for Laura:
- convert the live project into sprint-sized slices
- identify blockers, assumptions, and dependencies per platform
- return the first proposed sprint cut for review
```

### 4) Keep the handoff reusable
Store the handoff wording and platform inventory in a reusable skill or reference file so future projects can follow the same pattern without inventing a new process.

The reusable handoff set should usually include:
- a platform registry
- a solution blueprint
- a platform matrix
- an operating-model index
- review gates separated from execution workstreams

If the project uses multiple Linear teams, keep review-gate issues in the review team and execution workstreams in the delivery/backlog team; connect them by update or relation rather than forcing an invalid team/project pairing.

When direct cross-team relations are blocked by auth, fall back to a visible start-signal issue plus a child kickoff issue and a project update that names the observable next step. See `references/laura-start-signal-path.md`.

### 5) Verify the result
After posting the handoff artifact, re-read the project to ensure:
- the handoff note is present
- the stale artifacts are gone
- the platform inventory is explicit
- Laura’s ownership of sprint slicing is unambiguous

## Pitfalls

- Do not write the sprint plan yourself; that is Laura’s role.
- Do not leave stale milestones or phase language in place if they confuse the handoff.
- Do not hide the platform inventory in a private note that future sessions cannot reuse.
- Do not hand off the project before verifying the live state.

## Verification Checklist

- [ ] Live project state was checked first
- [ ] Stale artifacts were cleaned
- [ ] Platform inventory was recorded
- [ ] A standard handoff note was written in Linear
- [ ] Laura’s sprint-planning role was made explicit
- [ ] The handoff pattern was saved for reuse
