# Laura Start Signal Path

Use this reference when Laura must begin autonomously but direct assignee/actioner writes are not available or not reliable in the current Linear auth scope.

## Goal
Make the start state visible in Linear with an issue-level trail that Laura can act on immediately.

## Minimum viable visible path
1. Create a clear start-signal issue.
2. Subscribe Laura to the start-signal issue.
3. Create a first actionable child issue under the signal.
4. Post a project update that names the source artifacts and the start state.
5. Add a follow-up note that tells the team which issue should show the first sign of movement.

## What counts as started
Do not claim Laura has started until at least one of the following is visible:
- a Laura-authored issue/comment/update
- movement on the actionable child issue
- a project update explicitly noting Laura has begun

## What not to do
- Do not rely on project updates alone if issue-level actions are possible.
- Do not claim ownership from a notification artifact unless the issue trail also exists.
- Do not mark the start as complete until the issue trail is visible and current.

## Reusable wording
- "Laura can begin sprint slicing from the registry, blueprint, matrix, and operating-model index."
- "BIZOPS-105 is the official start signal."
- "BIZOPS-106 is the first actionable kickoff child issue."
- "Laura is subscribed to both issues."
- "The next observable sign of movement should appear on BIZOPS-106."

## Why this matters
This path is the lowest-friction way to start Laura when the control plane cannot write a direct assignee or actor trail. It keeps the start state explicit without pretending the work has already begun.
