---
name: hermes-profiles
description: |
  Create and deploy role-based Hermes profiles across multiple machines with
  multi-tier orchestration support (Laptop/Desktop/Control Plane). Includes
  export/import distribution, security best practices, and production deployment
  verification.
trigger: |
  User needs to:
  • Create multiple profiles for different roles/machines
  • Export profiles for distribution and deployment
  • Set up autonomous multi-profile orchestration across tiers
  • Secure profile distribution (token redaction, .env management)
keywords:
  - profile creation
  - multi-tier deployment
  - export/import
  - autonomous orchestration
  - distributed agents
---

# Hermes Profiles: Creation, Distribution, and Deployment

This skill captures the complete workflow for designing, creating, and deploying
role-based Hermes profiles across a multi-tier infrastructure (Laptop/Desktop/
Control Plane with autonomous orchestration).

## Class Overview

**Profile := Identity + Configuration + Responsibilities**

Each profile represents:
- An OAuth actor identity (for Linear, Telegram, etc.)
- A distinct role with clear responsibilities
- Isolated session store and memory
- Pre-configured tools and cron intervals
- Deployment target (Laptop/Desktop/Control Plane)

**Multi-Profile System := Coordinated Autonomous Workforce**

Profiles are deployed across tiers:
- **Laptop**: Awake-only, interactive (your digital twin)
- **Desktop**: Always-on 24/7, multiple profiles executing in parallel
- **Control Plane**: Headless autonomous ops (no UI needed)

All coordinate via Linear (system of record) and async messaging (Telegram/email).

## Profile Lifecycle

### 1. Design Phase

**Define roles and responsibilities** before creating profiles.

Ask:
- What tiers are needed? (Laptop/Desktop/Control Plane)
- What are the distinct roles? (orchestrator, designer, validator, communicator, ops)
- What are the responsibilities per role?
- What cron interval makes sense per role?
  - Orchestrator/router: 2-5 min (high frequency, low cost)
  - Executors: 5-10 min (moderate frequency)
  - Ops: 5 min (responsive to deployment signals)

**Example Matrix:**

| Profile | Tier | Role | Cron | Gateway | Responsibility |
|---------|------|------|------|---------|---|
| neil-digital-twin | Laptop | You/Digital Twin | None (interactive) | No | Create issues, explore, approve decisions |
| laura-orchestrator | Desktop | Router/Scrum Master | 2 min | Yes | Read Linear, route work, coordinate execution |
| mai-architect | Desktop | Strategist/Architect | 5 min | Yes | Design, write, make strategic decisions |
| kai-validator | Desktop | QA/Validator | 5 min | No | Test, validate, publish |
| rai-ops | Control Plane | Operations | 5 min | No | Smoke tests, deployment checks, autonomous ops |

### 2. Creation Phase

**Create profile directory structure** for each profile.

```bash
hermes profile create [name]
```

The profile gets:
```
~/.hermes/profiles/[name]/
├─ .env                  ← Secrets (LINEAR_API_TOKEN, etc.)
├─ config.yaml           ← Model + tools + display settings
├─ PROFILE.md            ← Role description + setup guide
├─ sessions/             ← Session history (auto-created)
└─ skills/               ← Profile-specific skills (optional)
```

### 3. Configuration Phase

**Set .env secrets per profile** using token redaction pattern.

```bash
# Template approach (safe for distribution):
cat > ~/.hermes/profiles/[name]/.env <<'EOF'
# Profile: [name]
# Tier: [laptop|desktop|control-plane]

LINEAR_API_TOKEN=[REDACTED - INSERT YOUR TOKEN FROM LINEAR OAUTH]
LINEAR_WORKSPACE_ID=[REDACTED - GET FROM SETTINGS]
TELEGRAM_BOT_TOKEN=[REDACTED - INSERT IF NEEDED]
HIMALAYA_ACCOUNT_NAME=[name]@kohd.local
EOF
```

**Then fill in actual values:**
```bash
hermes --profile [name] auth add linear
```

**Set config.yaml per profile:**
- Model: `anthropic/claude-haiku-4.5` (Haiku is fast, low cost)
- Tools: Optimize per role (e.g., Designer needs vision; Orchestrator needs messaging)
- Memory: Enable (persistent across sessions)
- Gateway: Enable for Desktop profiles that need async messaging

### 4. Documentation Phase

**Create PROFILE.md per profile** with role description.

Content to include:
- Identity (name, tier, role)
- Description (what this profile does)
- Responsibilities (bulleted list)
- Tools available (from config.yaml)
- Configuration details (model, gateway, cron interval)
- Setup instructions (how to set Linear token, etc.)

**Template in references/PROFILE.md.template**

### 5. Batch Export Phase

**Export all profiles for distribution:**

```bash
for profile in neil-digital-twin laura-orchestrator mai-architect kai-validator rai-ops; do
  hermes profile export $profile
done
```

Creates `.tar.gz` archives at `~/.hermes/profiles/[name]-export.tar.gz`

### 6. Documentation Package Phase

**Create accompanying documentation** before distribution.

Minimum files:
- `README.md` — 30-second overview
- `QUICK_REFERENCE.md` — 1-page cheat sheet (all key commands)
- `DEPLOYMENT_GUIDE.md` — Step-by-step setup for each system
- `DEPLOYMENT_CHECKLIST.md` — Pre-flight, import, config, verify, launch
- `MANIFEST.json` — Package metadata (profiles, tiers, checksums)
- `CHECKSUMS.md5` — MD5 hashes for verification

See `references/documentation-structure.md` for content templates.

### 7. Verification Phase

**Verify all profiles before deployment:**

```bash
# Check imports
hermes profile list          # All profiles present?

# Test Linear connection
hermes --profile [name] chat -q "Show me all Linear issues"

# Verify cron setup
hermes --profile [name] cron list

# Verify gateway (if Desktop)
hermes --profile [name] gateway status

# Check for errors in logs
tail -50 ~/.hermes/logs/gateway.log
```

### 8. Deployment Phase

**Deploy to target systems via import:**

**Laptop:**
```bash
hermes profile import neil-digital-twin-export.tar.gz
hermes --profile neil-digital-twin auth add linear
```

**Desktop:**
```bash
for f in laura-orchestrator mai-architect kai-validator quinn-support amelia-comms; do
  hermes profile import ${f}-export.tar.gz
  hermes --profile $f auth add linear
done
hermes profile use mai-architect        # Set primary identity
hermes desktop                          # Launch all profiles
```

**Control Plane:**
```bash
hermes profile import rai-ops-export.tar.gz
hermes --profile rai-ops auth add linear
```

## Multi-Tier Architecture Pattern

### Tier 1: Laptop (Your Machine)

**Role**: Digital Twin + Decision Maker

- **Identity**: neil-digital-twin (or your-name-digital-twin)
- **Cron**: None (interactive only)
- **Gateway**: No Telegram/external services
- **Awake**: Only when you actively use the laptop (sleeps when closed)
- **What it does**:
  - You create Linear issues
  - You explore and understand work
  - You approve milestone decisions (via Telegram on phone)
- **Why separate**: Keeps personal reasoning private, doesn't drain laptop battery

### Tier 2: Desktop (Always-On Orchestration + Execution)

**Role**: 24/7 Autonomous Workforce

- **Profiles**: 
  - Orchestrator (e.g., laura-orchestrator) — routes work every 2 min
  - Executors (e.g., mai-architect, kai-validator, quinn-support, amelia-comms) — execute every 5-10 min
  - Primary identity: Usually the executor with broadest scope (e.g., mai-architect)

- **Why Desktop**:
  - Stays powered on 24/7
  - Multiple profiles run cron jobs in parallel (no blocking)
  - Gateway handles webhooks + async messaging
  - Profiles personalize responses (each is an OAuth actor in Linear)

- **Cron Pattern**:
  - Orchestrator (Laura): 2 min → read Linear for new work, route to next profile
  - Executors: 5 min → check if assigned, execute, post evidence
  - Comms: 10 min → batch messaging tasks

### Tier 3: Control Plane (Headless Autonomous Ops)

**Role**: Deployment + Verification (No Human Loop)

- **Profile**: rai-ops (or your-rai-operator)
- **Cron**: Every 5 min
- **Gateway**: No external messaging (ops-only)
- **Headless**: No Hermes Desktop UI needed
- **What it does**:
  - Detects "ready-for-deployment" signal in Linear
  - Runs smoke tests
  - Posts verification evidence
  - Updates Linear status
  - Autonomous (no human approval in this loop)

## Security Best Practices

### Token Redaction Pattern

**Before distribution, redact all secrets:**

```yaml
# In .env template:
LINEAR_API_TOKEN=[REDACTED - INSERT YOUR TOKEN FROM LINEAR OAUTH]
LINEAR_WORKSPACE_ID=[REDACTED - GET FROM LINEAR WORKSPACE SETTINGS]
TELEGRAM_BOT_TOKEN=[REDACTED - INSERT IF NEEDED]
```

**After distribution, receiver fills in actual values:**
```bash
# User does this on their machine:
nano ~/.hermes/profiles/laura-orchestrator/.env
# Manually insert: LINEAR_API_TOKEN=lin_***
```

### OAuth Per Profile (Not Personal API Keys)

**DO:**
- Create one Linear OAuth application per profile
- Store OAuth token per profile in .env
- Each profile appears as distinct actor in Linear
- Audit trail shows "mai-architect updated status", "laura-orchestrator added comment"

**DON'T:**
- Use personal API key across profiles
- Store credentials in git
- Use same OAuth token for multiple profiles (loses audit trail)

### .env Git Ignoring

Profiles are version-controlled, but secrets are not:

```bash
# In repo .gitignore:
.env
~/.hermes/profiles/*/.env
```

Only commit:
- PROFILE.md (role descriptions, public)
- config.yaml (tools + model settings, public)
- scripts/ (if any, public)

Never commit:
- .env (has tokens)
- sessions/ (private conversations)

## Documentation Strategy

When distributing profiles as a package, include 5-6 documents:

### 1. INDEX.txt (Start Here)
- Contents overview
- Quick links to each document
- File listing with sizes

### 2. README.md (30-second Overview)
- Architecture diagram (text or ASCII)
- Quick deployment steps
- Profile roles at a glance
- Key features checklist

### 3. QUICK_REFERENCE.md (1-page Cheat Sheet)
- All key commands in one place
- Profile names and roles (table)
- Import commands (copy-paste ready)
- Troubleshooting quick fixes

### 4. DEPLOYMENT_GUIDE.md (Comprehensive Setup)
- Tier-specific setup instructions
- OAuth token generation
- Configuration per profile
- Verification steps
- Troubleshooting deep dives

### 5. DEPLOYMENT_CHECKLIST.md (Step-by-Step Verification)
- Pre-flight checks
- Import phase checklist
- Configuration phase checklist
- Launch phase checklist
- Success criteria
- Rollback procedure

### 6. MANIFEST.json (Machine-Readable Metadata)
```json
{
  "version": "1.0",
  "created": "2026-07-03",
  "profiles": [
    {
      "name": "neil-digital-twin",
      "tier": "laptop",
      "role": "Digital Twin",
      "file": "neil-digital-twin-export.tar.gz"
    }
  ],
  "checksums": "CHECKSUMS.md5"
}
```

## Workflow Example: Linear-Driven Automation

After deployment, profiles execute this loop:

```
Neil (Laptop)
  └─ Creates Linear issue: Status=NEW, Tag=#new-project
     ↓
Laura (Desktop, 2-min cron)
  └─ Detects Status=NEW
  └─ Routes based on tag/type
  └─ Updates Status=IN_PROGRESS
  └─ Assigns to next profile
  └─ Posts "Starting work" to Telegram
     ↓
Mai/Kai/Quinn/Amelia (Desktop, 5-10 min cron)
  └─ Detects assignment
  └─ Executes work (design, test, support, comms)
  └─ Posts evidence to Linear comment
  └─ Updates custom fields
  └─ Clears assignment (ready for next step)
     ↓
Laura (2-min cron, detects completion)
  └─ Posts progress to Neil's Telegram
  └─ Waits for Neil's approval
     ↓
Neil (Phone, async)
  └─ Replies: "YES" or "revise"
  └─ Telegram → Updates Linear Status
     ↓
Rai (Control Plane, 5-min cron)
  └─ Detects Status=READY_FOR_DEPLOYMENT
  └─ Runs smoke tests
  └─ Posts verification evidence
  └─ Updates Status=DEPLOYED
  └─ Done

Full cycle: 15-20 minutes
```

## Pitfalls & Gotchas

### Pitfall 1: Forgetting .env Reset
**Problem**: Exported profiles contain [REDACTED] tokens. After import, the receiver forgets to fill them in. Laura can't connect to Linear.

**Fix**: Document prominently:
```
AFTER IMPORT, RUN:
  hermes --profile [name] auth add linear
```

Add to DEPLOYMENT_CHECKLIST.md as first step.

### Pitfall 2: Profiles Blocking Each Other
**Problem**: Cron job on laura-orchestrator hangs, blocks other profiles from running.

**Fix**: Cron jobs must run independently. Set conservative timeouts:
```yaml
agent:
  max_turns: 30  # Not 90 (long conversations stall cron)
  tool_use_enforcement: true
```

Each profile's cron should complete in < 1 minute. If a task needs 10 min, create a background task, not a cron job.

### Pitfall 3: Single Point of Failure
**Problem**: Desktop PC dies, entire automation stops.

**Fix**: Design for graceful degradation:
- Rai-ops on separate Control Plane (if possible)
- Laptop (Neil) is always-on-when-needed (not continuous)
- Desktop can be restarted without losing work (Linear is source of truth)

### Pitfall 4: Token Leakage
**Problem**: Developer accidentally commits .env file with LINEAR_API_TOKEN.

**Fix**: 
- Never store original .env in version control
- Use [REDACTED] templates only
- Add to .gitignore and verify
- Use git-secrets or similar to prevent commits

### Pitfall 5: Role Ambiguity
**Problem**: Two profiles think they should handle the same type of work. Duplicated effort or missed work.

**Fix**: Document responsibilities clearly. Use Linear tags/fields to disambiguate:
- Tag #platform-design → mai-architect
- Tag #qa-testing → kai-validator
- Tag #support-triage → quinn-support

Each profile's cron job checks for its specific tag. No overlap.

## Implementation Checklist

When creating a new multi-profile system:

- [ ] Define roles and responsibilities matrix
- [ ] Design cron intervals per role (orchestrator 2-5 min, executors 5-10 min)
- [ ] Create profile directories with .env, config.yaml, PROFILE.md
- [ ] Set up OAuth tokens per profile (via Linear workspace settings)
- [ ] Export all profiles to .tar.gz
- [ ] Create documentation package (README, QUICK_REFERENCE, DEPLOYMENT_GUIDE, CHECKLIST)
- [ ] Generate checksums (md5sum)
- [ ] Test one complete cycle (create issue → route → execute → approve → deploy)
- [ ] Verify logs for errors (tail ~/.hermes/logs/gateway.log)
- [ ] Document deployment procedures in DEPLOYMENT_GUIDE.md
- [ ] Create rollback procedure (in DEPLOYMENT_CHECKLIST.md)

## See Also

- `hermes-agent` — General Hermes configuration and setup
- `linear-dispatch-architecture` — Linear-driven workflow automation (system of record pattern)

