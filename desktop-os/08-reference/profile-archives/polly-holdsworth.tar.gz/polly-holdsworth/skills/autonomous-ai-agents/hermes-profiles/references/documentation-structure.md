# Documentation Structure for Profile Distribution

When distributing exported profiles as a deployment package, use this 6-file structure.

## File: INDEX.txt

**Purpose**: Entry point. File listing, quick navigation.

**Content**:
- Package size and file count
- List all 7 profiles with deployment targets
- Quick start commands (copy-paste)
- Architecture diagram (ASCII)
- Next steps (read order)

**Length**: ~1 page

**Tone**: Highly structured, scannable, actionable

**Example**:
```
╔════════════════════╗
║ PROFILE PACKAGE   ║
╚════════════════════╝

📦 13 Files (96KB total)

PROFILES:
  ✓ neil-digital-twin-export.tar.gz      → Your Laptop
  ✓ laura-orchestrator-export.tar.gz     → kohd-hub Desktop
  ...

DOCUMENTATION:
  1. INDEX.txt (this file)
  2. README.md (30-second guide)
  3. QUICK_REFERENCE.md (1-page cheat)
  ...

QUICKSTART:
  $ hermes profile import neil-digital-twin-export.tar.gz
  $ hermes --profile neil-digital-twin auth add linear
  ...
```

---

## File: README.md

**Purpose**: 30-second overview. Decision-maker summary.

**Content**:
- What you have (7 profiles, 3 tiers)
- Architecture overview (text diagram)
- 30-second deployment steps
- Key features checklist
- Success criteria after deployment

**Length**: ~2-3 pages

**Tone**: Executive summary, high-level

**Example**:
```markdown
# 7-Profile Hermes Deployment Package

## Architecture

YOUR LAPTOP
  └─ neil-digital-twin (You)

kohd-hub DESKTOP (Always-On)
  ├─ laura-orchestrator (Router)
  ├─ mai-architect (Designer)
  ├─ kai-validator (QA)
  └─ ...

CONTROL PLANE (Headless)
  └─ rai-ops (Ops)

## Quick Deploy

1. Import profiles
2. Set Linear tokens
3. Launch Desktop
4. Done

## What You Get

✓ 7 autonomous agents
✓ Coordinated via Linear
✓ Role-based responsibilities
✓ 24/7 execution
```

---

## File: QUICK_REFERENCE.md

**Purpose**: 1-page cheat sheet. All key commands, no explanation.

**Content**:
- Profile names and roles (table)
- Import commands (copy-paste)
- Test commands
- Troubleshooting quick fixes
- Cron verification
- Log viewing

**Length**: Exactly 1 page (or compress to fit)

**Tone**: Reference, minimal prose, maximum scanability

**Format**: Tables, bullet lists, code blocks

**Example**:
```markdown
# Quick Reference

## Profiles

| Name | Tier | Role |
|------|------|------|
| neil-digital-twin | Laptop | You |
| laura-orchestrator | Desktop | Router |
| mai-architect | Desktop | Designer |

## Import

$ hermes profile import [name]-export.tar.gz
$ hermes --profile [name] auth add linear

## Test

$ hermes --profile [name] chat -q "Test"

## Troubleshoot

| Issue | Command |
|-------|---------|
| Profile missing | hermes profile list |
| Linear broken | hermes --profile [name] chat -q "Linear test" |
| Cron stuck | hermes --profile [name] cron list |
```

---

## File: DEPLOYMENT_GUIDE.md

**Purpose**: Step-by-step setup for each tier. Comprehensive, thorough.

**Content**:
- System requirements
- Tier-specific deployment (Laptop, Desktop, Control Plane)
- OAuth token generation
- Configuration per profile (.env, config.yaml)
- Verification for each tier
- Troubleshooting deep dives
- Post-deployment monitoring

**Length**: ~8-15 pages

**Tone**: Detailed, no ambiguity, explanatory

**Structure per tier**:
```markdown
### Laptop (neil-digital-twin)

1. Prerequisites
   - Hermes CLI installed
   - SSH access (if remote)

2. Import
   - hermes profile import neil-digital-twin-export.tar.gz
   - Verify: hermes profile list

3. Configure
   - hermes --profile neil-digital-twin auth add linear
   - Verify: grep LINEAR_API_TOKEN ~/.hermes/profiles/neil-digital-twin/.env

4. Test
   - hermes --profile neil-digital-twin chat -q "Test"

5. Verify
   - [ ] Profile imported
   - [ ] Linear token set
   - [ ] Chat works

### Desktop (kohd-hub) — 5 Profiles

[Similar structure for 5 profiles...]

### Control Plane (rai-ops)

[Similar structure...]
```

---

## File: DEPLOYMENT_CHECKLIST.md

**Purpose**: Pre-flight to launch verification. Step-by-step checklist to ensure nothing is missed.

**Content**:
- Pre-flight checks (requirements met?)
- Import checklist (all 7 profiles?)
- Config checklist (tokens set, cron verified?)
- Verification checklist (Linear connected? Cron running?)
- Launch checklist (everything started?)
- Post-launch success criteria
- Rollback procedure (if something fails)

**Length**: ~5-8 pages

**Tone**: Checkbox-driven, binary pass/fail, actionable fixes

**Format**: Checklist with [ ] boxes, clear "Fix" steps

**Example**:
```markdown
## Import Phase

### Laptop (neil-digital-twin)
- [ ] neil-digital-twin-export.tar.gz downloaded
- [ ] hermes profile import neil-digital-twin-export.tar.gz
- [ ] hermes profile list | grep neil-digital-twin
  [ ] If not found: Check ~/. hermes/profiles/, try again

### Desktop (all 5 profiles)
- [ ] All 5 .tar.gz files downloaded
- [ ] hermes profile import laura-orchestrator-export.tar.gz
- [ ] hermes profile import mai-architect-export.tar.gz
  [ ] If failed: Check disk space (du -sh ~/.hermes/)
- [ ] ... (repeat for each)
- [ ] Final: hermes profile list | wc -l
  [ ] Must show ≥5

## Configuration Phase

### Set Linear Tokens
- [ ] hermes --profile neil-digital-twin auth add linear
- [ ] hermes --profile laura-orchestrator auth add linear
  [ ] If error: Check Linear workspace settings for token
- [ ] ... (repeat for each)

## Verification Phase

### Test Linear Connection
- [ ] hermes --profile neil-digital-twin chat -q "Show Linear issues"
  [ ] If error: Verify LINEAR_API_TOKEN in ~/.hermes/profiles/neil-digital-twin/.env
- [ ] ... (repeat for each)

## Launch Phase

### Start Desktop
- [ ] hermes profile use mai-architect
- [ ] hermes desktop
- [ ] tail -f ~/.hermes/logs/gateway.log
  [ ] No ERROR messages in first 30 seconds?

## Success Criteria

✅ All 7 profiles imported
✅ All 7 Linear connections working
✅ Desktop launched without errors
✅ Cron jobs running every 2-5 min
✅ No ERROR in gateway.log after 5 min
```

---

## File: MANIFEST.json

**Purpose**: Machine-readable metadata. Validation, verification.

**Content**:
```json
{
  "version": "1.0",
  "created": "2026-07-03",
  "profiles": [
    {
      "name": "neil-digital-twin",
      "tier": "laptop",
      "role": "Digital Twin",
      "file": "neil-digital-twin-export.tar.gz",
      "size": "2.1K",
      "checksum": "md5sum in CHECKSUMS.md5"
    },
    ...
  ],
  "deploymentTiers": {
    "laptop": { "profiles": ["neil-digital-twin"], "alwaysOn": false },
    "desktop": { "profiles": ["laura", "mai", "kai", ...], "alwaysOn": true },
    "controlPlane": { "profiles": ["rai-ops"], "alwaysOn": true, "headless": true }
  },
  "numberOfProfiles": 7,
  "totalSize": "96K",
  "checksumFile": "CHECKSUMS.md5"
}
```

**Length**: ~30 lines

**Tone**: Structured, JSON-formatted

---

## File: CHECKSUMS.md5

**Purpose**: Integrity verification. All 7 profile archives hashed.

**Content**:
```
7a1dbf1900b48b4441b6464e375e2a08  amelia-comms-export.tar.gz
e78e936e8e22153f8f3444c844354d66  kai-validator-export.tar.gz
db1d3c83f85cf8ba1b7fd1b16c30bb75  laura-orchestrator-export.tar.gz
c18910ac3e4667121d2ed5c54eba654c  mai-architect-export.tar.gz
...
```

**Verification command**:
```bash
md5sum -c CHECKSUMS.md5
```

**Length**: 7 lines (1 per profile)

---

## Document Reading Order (for user)

1. **INDEX.txt** — Orient & navigate (2 min)
2. **README.md** — Understand what you have (5 min)
3. **QUICK_REFERENCE.md** — All commands at a glance (2 min)
4. **DEPLOYMENT_GUIDE.md** — Follow step-by-step (30 min, tier by tier)
5. **DEPLOYMENT_CHECKLIST.md** — Verify each step as you go (20 min)

**Total time to deploy**: ~1 hour (including careful reading + setup)

---

## Tips for Writing These Documents

### INDEX.txt
- Make it scannable (lots of whitespace, bullet points, boxes)
- File listing with sizes
- Quick navigation links to other docs
- One "next step" call-to-action

### README.md
- Start with the problem solved (what you get)
- Then the how (30-second overview)
- ASCII diagram is valuable (even if crude)
- Success criteria at the end

### QUICK_REFERENCE.md
- Minimize prose
- Use tables for anything with 3+ items
- Code blocks for commands (with $ prompt)
- Troubleshooting = shortest Problem → Command → Fix

### DEPLOYMENT_GUIDE.md
- Assume reader has read README but not done setup
- Each section is independent (can jump to Control Plane section if needed)
- Explain the why once, then give commands
- Troubleshooting section per tier
- Post-deployment monitoring section

### DEPLOYMENT_CHECKLIST.md
- Every step is a [ ] checkbox
- Checklist never has prose at the top (start with checks)
- If a check fails, provide the exact fix command
- Binary pass/fail (not shades of gray)

### MANIFEST.json
- Machine-readable only (no comments)
- Include size, checksum, tier info
- Mirror what's in README (profiles, roles, tiers)

### CHECKSUMS.md5
- Output of `md5sum *.tar.gz`
- No human text, just hashes
- Cmd to verify: `md5sum -c CHECKSUMS.md5`

