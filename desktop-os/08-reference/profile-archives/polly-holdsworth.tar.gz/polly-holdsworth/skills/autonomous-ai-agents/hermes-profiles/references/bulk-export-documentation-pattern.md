# Bulk Export + Documentation Packaging Pattern

**Session**: 2026-07-03 KOHD Deployment  
**Context**: Created 7 production profiles with complete documentation package for export/distribution

## Pattern Overview

When deploying multiple profiles as a cohesive system, export all profiles + accompanying documentation as a single distributable package.

**Workflow:**
1. Create all profiles locally
2. Export all to `.tar.gz` archives
3. Create comprehensive documentation (README, guides, checklists)
4. Generate manifest + checksums
5. Distribute entire package as one bundle

## Directory Structure

```
/tmp/hermes-profile-exports/
├─ Profiles (7):
│  ├─ neil-digital-twin-export.tar.gz
│  ├─ laura-orchestrator-export.tar.gz
│  ├─ mai-architect-export.tar.gz
│  ├─ kai-validator-export.tar.gz
│  ├─ rai-ops-export.tar.gz
│  ├─ quinn-support-export.tar.gz
│  └─ amelia-comms-export.tar.gz
│
├─ Documentation (7):
│  ├─ INDEX.txt                          ← Start here
│  ├─ README.md                          ← 30-second overview
│  ├─ QUICK_REFERENCE.md                 ← 1-page cheat sheet
│  ├─ DEPLOYMENT_GUIDE.md                ← Full step-by-step
│  ├─ DEPLOYMENT_CHECKLIST.md            ← Pre-flight to launch
│  ├─ DELIVERY_COMPLETE.md               ← Summary + next steps
│  └─ NEXT_PHASE.md                      ← Phase 2 roadmap
│
├─ Advanced:
│  └─ ADF_LINEAR_SCHEMA.md               ← Automation design
│
└─ Verification:
   ├─ MANIFEST.json                      ← Package metadata
   └─ CHECKSUMS.md5                      ← MD5 verification
```

## Files to Create

### 1. BUILD SCRIPT (for automation)

```bash
#!/bin/bash
# export_kohd_profiles.sh

EXPORT_DIR="/tmp/hermes-profile-exports"
mkdir -p "$EXPORT_DIR"

# Export all profiles
for profile in neil-digital-twin laura-orchestrator mai-architect kai-validator rai-ops quinn-support amelia-comms; do
  echo "Exporting $profile..."
  hermes profile export $profile
  mv ~/.hermes/profiles/${profile}-export.tar.gz "$EXPORT_DIR/"
done

echo "✓ All profiles exported"
```

### 2. INDEX.txt (Package overview)

```
Package contents summary + file listing.
See README.md for quick start.
```

### 3. README.md (30-second)

**Include:**
- What is this? (7 profiles, complete KOHD deployment)
- Why this structure? (3-tier: Laptop/Desktop/Control Plane)
- Quick start commands (copy-paste ready)
- Profiles at a glance (table of name, tier, role)

**Key section: Quick Start**
```bash
# Laptop
hermes profile import neil-digital-twin-export.tar.gz
hermes --profile neil-digital-twin auth add linear

# kohd-hub Desktop
for f in laura-orchestrator mai-architect kai-validator quinn-support amelia-comms; do
  hermes profile import ${f}-export.tar.gz
  hermes --profile $f auth add linear
done
hermes profile use mai-architect
hermes desktop

# Control Plane
hermes profile import rai-ops-export.tar.gz
hermes --profile rai-ops auth add linear
```

### 4. QUICK_REFERENCE.md (1-page)

**Include:**
- All key commands in one place
- Profile names and roles (table)
- Cron intervals
- Troubleshooting quick fixes (1-2 lines each)

### 5. DEPLOYMENT_GUIDE.md (Comprehensive)

**Sections:**
- System Requirements (Hermes CLI version, OS, network)
- Tier-specific setup (Laptop vs Desktop vs Control Plane)
- Pre-import verification (space, permissions, backups)
- Import procedure (step-by-step for each system)
- Configuration (Linear OAuth tokens, Telegram gateway)
- Verification (test Linear connection, verify cron)
- Troubleshooting (common errors + fixes)

### 6. DEPLOYMENT_CHECKLIST.md (Step-by-step)

**Phases:**
- Pre-flight (Hermes version, disk space, network)
- Import (each profile imported successfully)
- Configuration (OAuth tokens added, .env verified)
- Verification (cron jobs running, Linear queries working)
- Launch (Desktop app starts, all profiles visible)
- Success Criteria (all profiles pass health check)

**Include:** Rollback procedure if something fails.

### 7. ADF_LINEAR_SCHEMA.md (Advanced)

**Include:**
- Analysis of actual backlog (team counts, status distribution)
- Exact routing rules per profile
- Evidence format (JSON blocks in comments)
- Profile watch conditions (cron queries)
- Neil's approval gates (Telegram format)
- Complete workflow examples (end-to-end scenarios)

### 8. MANIFEST.json (Machine-readable)

```json
{
  "version": "1.0",
  "created": "2026-07-03",
  "hermes_version": "3.x+",
  "profiles": [
    {
      "name": "neil-digital-twin",
      "tier": "laptop",
      "role": "Digital Twin / You",
      "file": "neil-digital-twin-export.tar.gz",
      "responsibilities": ["Create issues", "Explore work", "Approve decisions"]
    },
    {
      "name": "laura-orchestrator",
      "tier": "desktop",
      "role": "Orchestrator / Router",
      "file": "laura-orchestrator-export.tar.gz",
      "cron_interval_min": 2,
      "responsibilities": ["Route work", "Coordinate profiles", "Post updates"]
    },
    ...
  ],
  "documentation": {
    "quick_start": "README.md",
    "commands": "QUICK_REFERENCE.md",
    "deployment": "DEPLOYMENT_GUIDE.md",
    "verification": "DEPLOYMENT_CHECKLIST.md",
    "advanced": "ADF_LINEAR_SCHEMA.md"
  },
  "checksums": "CHECKSUMS.md5"
}
```

### 9. CHECKSUMS.md5

```bash
# Generate
cd /tmp/hermes-profile-exports
md5sum *.tar.gz > CHECKSUMS.md5

# Verify after distribution
md5sum -c CHECKSUMS.md5
```

## Security Considerations

### Secret Redaction Template

All profiles use `.env` template with [REDACTED] placeholders:

```bash
# Template (safe to distribute)
LINEAR_API_TOKEN=[REDACTED - INSERT YOUR TOKEN]
LINEAR_WORKSPACE_ID=[REDACTED - INSERT YOUR WORKSPACE ID]

# Receiver fills in:
LINEAR_API_TOKEN=lin_api_...
LINEAR_WORKSPACE_ID=...
```

### Git Safeguards

**In .gitignore:**
```
.env
~/.hermes/profiles/*/.env
```

**Profiles are version-controlled, secrets are not.**

## Distribution Checklist

Before packaging for distribution:

- [ ] All 7 profiles created and tested locally
- [ ] Each profile's .env uses [REDACTED] template
- [ ] All profiles export successfully to .tar.gz
- [ ] Documentation complete (7 files)
- [ ] README.md has working copy-paste commands
- [ ] DEPLOYMENT_GUIDE.md covers all tiers
- [ ] DEPLOYMENT_CHECKLIST.md has success criteria
- [ ] MANIFEST.json accurate and complete
- [ ] CHECKSUMS.md5 generated and verified
- [ ] Package size documented
- [ ] Backup of export directory created

## Pain Points Avoided

**This pattern addresses:**

1. **User imports profiles but forgets tokens** → Clear [REDACTED] placeholders + documented `auth add` step in README

2. **Documentation is scattered** → Organized with clear reading order (INDEX → README → QUICK_REFERENCE → GUIDE → CHECKLIST)

3. **Hard to verify all profiles work** → DEPLOYMENT_CHECKLIST.md has explicit verification for each profile

4. **Secrets accidentally committed** → .env template approach + gitignore instruction

5. **User doesn't know where to start** → INDEX.txt + README.md provide 30-second orientation

6. **Too much information to absorb** → Split into layers: Quick (README), Reference (QUICK_REFERENCE), Deep (GUIDE + CHECKLIST + SCHEMA)

## Variations

**For smaller deployments (2-3 profiles):**
- Still use packaging pattern (applies at any scale)
- Reduce documentation to README + QUICK_REFERENCE + GUIDE

**For larger deployments (10+ profiles):**
- Group profiles by tier (Laptop/, Desktop/, Control Plane/)
- Create tier-specific guides
- Increase verification step detail

**For open-source distribution:**
- Add LICENSE file
- Add CONTRIBUTING.md
- Use semantic versioning in MANIFEST.json
- Archive on GitHub releases with checksums
