# Multi-Profile Cron Patterns for Autonomous Orchestration

This document captures tested cron interval patterns and watch-rule logic used
in production multi-profile systems (Laptop/Desktop/Control Plane).

## Golden Rule

**Cron intervals must be independent and non-blocking.**

If Laura's 2-minute cron hangs, Mai's 5-minute cron should still fire. Profiles
must not starve each other.

Use `max_turns` limit to prevent any single profile from running too long:

```yaml
# In config.yaml (all profiles):
agent:
  max_turns: 30        # Not 90 (long conversations stall cron)
```

Each cron job should complete in < 60 seconds.

---

## Tier 1: Laptop (Your Machine)

### neil-digital-twin Profile

**Cron**: None (interactive only)

Why: Laptop power state is user-dependent. No background processes.

**When you interact**:
```bash
hermes --profile neil-digital-twin chat -q "Create Linear issue: [details]"
```

**Role in workflow**:
- You create issues manually
- You specify initial tags (e.g., #design, #testing, #support)
- Laura detects them in next 2-min cycle

---

## Tier 2: Desktop (Always-On 24/7)

### Orchestration Layer: Laura (Router)

**Cron Schedule**: `*/2 * * * *` (Every 2 minutes)

**What Laura does**:

```
1. Query Linear API:
   GET /issues?status=NEW limit=100

2. For each issue:
   a. Read tags (e.g., #design, #testing, #qa, #support, #communication)
   b. Pick next profile based on tag:
      - #design → assign to mai-architect
      - #testing → assign to kai-validator
      - #support → assign to quinn-support
      - #communication → assign to amelia-comms
      - #ops → assign to rai-ops
   c. Update issue: status=IN_PROGRESS, assignee=next-profile
   d. Post comment: "Routing to [profile] for [work type]"

3. Check for completed work:
   Query: status=AWAITING_APPROVAL
   Action: If all tasks done, post Telegram to Neil: "Ready? YES/NO"

4. Check for Neil's approval:
   From Telegram: Detect "YES" or "revise"
   Action: Update Linear status=PUBLISHED or status=REVISE

5. Post summary to Telegram:
   "2 issues queued, 1 in progress, 1 awaiting approval"
```

**Cron Job Creation**:

```bash
hermes --profile laura-orchestrator cron create "*/2 * * * *" \
  --prompt "Read Linear for STATUS=NEW. Route each to next profile. Post progress to Telegram."
```

**Watch Rules** (in prompt or as Linear API queries):

```yaml
triggers:
  - status: NEW
    action: route_to_profile
  - status: AWAITING_APPROVAL
    all_subtasks_done: true
    action: post_telegram_approval_gate
  - telegram_message: "YES"
    update_linear: status=PUBLISHED
  - telegram_message: "revise"
    update_linear: status=IN_PROGRESS
```

**Linear Workflow** (as seen by Laura):

```
Issue Creation (Neil)
  Status: NEW
  Tags: #design
  ↓ (Laura detects in 2 min)
Laura Routes
  Status: IN_PROGRESS → Assigned to mai-architect
  ↓ (Mai detects in 5 min)
Mai Executes
  Posts evidence comment
  ↓ (Laura detects completion in 2 min)
Laura Detects Completion
  Status: AWAITING_APPROVAL
  Posts Telegram to Neil
  ↓ (Neil replies in seconds/minutes)
Neil Approves
  Telegram: "YES"
  ↓ (Laura sees in next 2-min cycle)
Laura Routes to Deployment
  Status: PUBLISHED
  Assigned to rai-ops
  ↓ (Rai detects in 5 min on Control Plane)
Rai Deploys
  Status: DEPLOYED
  Posts verification
  ↓ (Done)
```

---

### Execution Layer: Mai, Kai, Quinn, Amelia (Executors)

**Cron Schedule**: `*/5 * * * *` (Every 5 minutes)

Each executor profile (Mai, Kai, Quinn, Amelia) follows the same pattern.

**Example: mai-architect**

```bash
hermes --profile mai-architect cron create "*/5 * * * *" \
  --prompt "Check Linear for issues assigned to me. Design and write content. Post evidence."
```

**What Mai does (every 5 min)**:

```
1. Query Linear API:
   GET /issues?assignee=mai-architect limit=100

2. For each issue:
   a. Read: title, description, tags, custom fields
   b. Do work: design, write documentation, create content
   c. Generate evidence: "Designed [component]. See [doc url]"
   d. Post comment to Linear with evidence
   e. Update custom field: "design_status"=COMPLETE
   f. Clear assignee: assignee=null (ready for next profile)

3. Mark done in Linear:
   POST /issues/[id]/comments {"body": "Design complete. Evidence: [...]"}
   PATCH /issues/[id] {"assignee": null}
```

**Watch Rules**:

```yaml
triggers:
  - assignee: mai-architect
    action: do_work
  - work_complete: true
    action: post_evidence_comment
    then: clear_assignee
```

**Execution Interval**: 5 minutes is enough for:
- Small designs (< 5 min)
- Documentation (< 5 min)
- Blog post drafts (< 5 min)

For longer work, create background tasks (not cron jobs).

**Kai (validator), Quinn (support), Amelia (comms)**: Same pattern, with role-specific work.

---

## Tier 3: Control Plane (Always-On 24/7, Headless)

### rai-ops Profile

**Cron Schedule**: `*/5 * * * *` (Every 5 minutes)

**What Rai does**:

```
1. Query Linear API:
   GET /issues?tag=ready-for-deployment limit=100

2. For each issue:
   a. Run smoke tests against target environment
   b. Generate verification report
   c. Post evidence comment to Linear with results
   d. If all tests pass:
      - Update: status=DEPLOYED
      - Post: "Deployment verified. [Evidence]"
   e. If tests fail:
      - Update: status=DEPLOYMENT_FAILED
      - Post: "Deployment issue: [Error details]"

3. Alert Neil (optional):
   - If deployment fails: Send Telegram alert
   - If deployment succeeds: Post to #announcements channel (or equivalent)
```

**Cron Job Creation**:

```bash
hermes --profile rai-ops cron create "*/5 * * * *" \
  --prompt "Check Linear for ready-for-deployment. Run smoke tests. Post verification."
```

**Watch Rules**:

```yaml
triggers:
  - tag: ready-for-deployment
    status: PUBLISHED
    action: run_smoke_tests
  - smoke_tests_pass: true
    action: update_status=DEPLOYED
  - smoke_tests_fail: true
    action: update_status=DEPLOYMENT_FAILED
    then: alert_neil
```

**No Telegram**: Rai is ops-only. Posts evidence to Linear, not to human channels.

---

## Full Workflow Timeline

**Assuming**:
- issue created at T+0
- All profiles running on schedule

Timeline:

```
T+0:00  Neil creates issue: Status=NEW, Tag=#design
T+2:00  Laura detects (2-min cron) → assigns to mai-architect
T+5:00  Mai detects (5-min cron) → does work → posts evidence
T+7:00  Laura detects completion (2-min cron) → posts Telegram
T+7:30  Neil replies: "YES" (on phone)
T+8:00  Laura detects approval (2-min cron) → assigns to rai-ops, Status=PUBLISHED
T+10:00 Rai detects (5-min cron) → runs smoke tests → Status=DEPLOYED
T+10:30 Done

Total: 10.5 minutes (from creation to deployment)
```

---

## Cron Interval Selection Matrix

| Profile | Role | Frequency | Why |
|---------|------|-----------|-----|
| Laura | Router | 2 min | High frequency needed to detect + route fast |
| Mai | Designer | 5 min | Moderate; designs take 1-2 min, check often |
| Kai | Validator | 5 min | Tests take 2-3 min, check frequently |
| Quinn | Support | 5 min | Support tickets are time-sensitive |
| Amelia | Comms | 10 min | Batch messaging; less time-critical |
| Rai | Ops | 5 min | Deployments are critical; check often |

**Rule of thumb**: If work takes N minutes, cron interval should be N/2 or less.

---

## Preventing Cron Starvation

**Problem**: One profile's cron job runs long (hangs), blocking others.

**Solution**: Add timeout + max_turns limit.

```yaml
# config.yaml (all profiles):
agent:
  max_turns: 30        # Stops after 30 turns (prevents infinite loops)
  tool_use_enforcement: true

terminal:
  timeout: 60          # 60 sec max per terminal command
```

**Profile-level timeout**:

```bash
# Create cron with timeout
hermes --profile laura-orchestrator cron create "*/2 * * * *" \
  --timeout 59 \
  --prompt "Route work"
```

**Result**: If Laura's job takes > 59 sec, it stops and retries in 2 min.

---

## Monitoring Cron Health

### View All Cron Jobs

```bash
hermes --profile [NAME] cron list
```

**Output**:
```
Cron Jobs for profile: [NAME]
  Job 1: "*/2 * * * *"  (every 2 min)    Status: Running    Last run: 20s ago
  Job 2: "*/5 * * * *"  (every 5 min)    Status: Running    Last run: 45s ago
```

### Check Job History

```bash
hermes --profile [NAME] cron log [job_id]
```

### Monitor Logs in Real-Time

```bash
tail -f ~/.hermes/logs/gateway.log | grep -E "laura|mai|kai"
```

Expected output (every 2-5 min):
```
[2026-07-03 10:15:00] laura-orchestrator: Running cron job
[2026-07-03 10:15:05] laura-orchestrator: Update status=IN_PROGRESS for issue #123
[2026-07-03 10:15:10] laura-orchestrator: Posted to Telegram
[2026-07-03 10:15:12] laura-orchestrator: Cron job complete (12s)
```

---

## Common Issues & Fixes

### Issue: Cron job not firing

```bash
# Check if cron is enabled
hermes --profile [NAME] cron list

# If empty, create a test job
hermes --profile [NAME] cron create "*/5 * * * *" --prompt "Test"

# If still empty, check config
cat ~/.hermes/profiles/[NAME]/config.yaml | grep cron
```

### Issue: Cron job hangs

```bash
# Check logs
tail -100 ~/.hermes/logs/gateway.log

# Look for: "Timeout" or "max_turns exceeded"

# Kill the job
hermes --profile [NAME] cron kill [job_id]

# Then restart
hermes --profile [NAME] cron create "*/2 * * * *" --prompt "Route work"
```

### Issue: Profiles stepping on each other

```bash
# Check for overlapping intervals
# Laura: */ 2 → fires at 0, 2, 4, 6, ...
# Mai: */5 → fires at 0, 5, 10, 15, ...
# They collide at T=0, 10, 20, ... but that's OK (profiles run in parallel threads)

# If there's a race condition:
# Offset the start times
hermes --profile mai-architect cron create "1-59/5 * * * *" --prompt "..."
# This fires at 1, 6, 11, 16, ... (offset by 1 min)
```

---

## Best Practices

1. **Laura is the router**: She should run frequently (2 min)
2. **Executors are independent**: They watch for their own assignments (5 min)
3. **Rai is autonomous ops**: No human approval in the ops loop (5 min)
4. **No blocking**: Each job must complete in < 60 sec
5. **Evidence in Linear**: All profiles post results to Linear (system of record)
6. **Telegram for decisions**: Only async approval gates use Telegram (Neil's phone)
7. **Monitor logs**: Daily check of gateway.log for ERROR or FAILED

---

## Reference: Cron Syntax

Linux cron format: `minute hour day month weekday`

```
*/2 * * * *      → Every 2 minutes
*/5 * * * *      → Every 5 minutes
*/10 * * * *     → Every 10 minutes
0 * * * *        → Every hour (at 0 minutes)
0 0 * * *        → Daily at midnight
```

More: `man cron` or https://crontab.guru

