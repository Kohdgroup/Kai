#!/bin/bash
# Verify Hermes fleet connectivity and readiness
# Run on control plane before deploying Kanban dispatch

set -e

echo "=== Distributed Hermes Fleet Connectivity Check ==="
echo

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

PASS=0
FAIL=0

check() {
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓${NC} $1"
        ((PASS++))
    else
        echo -e "${RED}✗${NC} $1"
        ((FAIL++))
    fi
}

# Extract SSH hosts from config.yaml
NODES=$(hermes config 2>/dev/null | grep -A 10 "ssh:" | grep "- " | awk '{print $2}' | sed 's/:.*//' || echo "")

if [ -z "$NODES" ]; then
    echo -e "${YELLOW}Warning: No SSH hosts found in config.yaml${NC}"
    echo "Ensure terminal.backend: ssh is set with a list of hosts."
    exit 1
fi

echo "Detected nodes: $NODES"
echo

# Check control plane
echo "=== Control Plane ==="
hermes --version > /dev/null 2>&1
check "Hermes installed"

hermes kanban --version > /dev/null 2>&1 || true
echo "Kanban board ready"

[ -d ~/.hermes/kanban ] || mkdir -p ~/.hermes/kanban
check "Kanban directory writable"

# Check kanban.db access
KANBAN_PATH=$(hermes config | grep -A 5 "kanban:" | grep "db_path:" | awk '{print $2}' || echo "")
if [ -z "$KANBAN_PATH" ]; then
    KANBAN_PATH="$HOME/.hermes/kanban.db"
fi

if [ -f "$KANBAN_PATH" ] || [ -d "$(dirname "$KANBAN_PATH")" ]; then
    check "Kanban DB path accessible ($KANBAN_PATH)"
else
    echo -e "${RED}✗${NC} Kanban DB path not writable: $KANBAN_PATH"
    ((FAIL++))
fi

echo

# Check worker nodes
echo "=== Worker Nodes ==="
echo "Testing SSH connectivity..."

for NODE in $NODES; do
    # Extract user@host
    USER_HOST=$NODE
    if [[ ! "$USER_HOST" =~ "@" ]]; then
        USER_HOST="root@$NODE"
    fi

    # Test SSH connectivity
    if ssh -o ConnectTimeout=5 "$USER_HOST" "echo OK" > /dev/null 2>&1; then
        echo -e "${GREEN}✓${NC} SSH to $USER_HOST"
        ((PASS++))

        # Check Hermes version
        VERSION=$(ssh "$USER_HOST" "hermes --version 2>/dev/null | head -1" || echo "not installed")
        echo "  └─ Hermes: $VERSION"

        # Check kanban.db mount
        if ssh "$USER_HOST" "[ -f '$KANBAN_PATH' ] || [ -d '$(dirname $KANBAN_PATH)' ]"; then
            echo -e "  ${GREEN}✓${NC} Kanban DB mount"
            ((PASS++))
        else
            echo -e "  ${RED}✗${NC} Kanban DB mount not accessible at $KANBAN_PATH"
            ((FAIL++))
        fi

        # Check profiles
        PROFILES=$(ssh "$USER_HOST" "ls -1 ~/.hermes/profiles/ 2>/dev/null | wc -l" || echo "0")
        echo "  └─ Profiles installed: $PROFILES"
    else
        echo -e "${RED}✗${NC} SSH to $USER_HOST (connection failed)"
        ((FAIL++))
    fi

    echo
done

# Summary
echo "=== Summary ==="
echo -e "${GREEN}Passed: $PASS${NC}"
if [ $FAIL -gt 0 ]; then
    echo -e "${RED}Failed: $FAIL${NC}"
    exit 1
else
    echo "All checks passed. Fleet is ready for Kanban dispatch."
    exit 0
fi
