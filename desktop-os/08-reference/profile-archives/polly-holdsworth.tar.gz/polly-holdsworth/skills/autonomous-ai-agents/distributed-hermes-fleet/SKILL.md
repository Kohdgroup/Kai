---
name: distributed-hermes-fleet
description: Multi-machine Hermes orchestration via Kanban. Deploy Hermes agents across multiple nodes (control plane + N workers) with central task dispatch and native SSH terminal backend integration.
version: 1.0.0
author: Agent (from session learning)
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [hermes, kanban, distributed-systems, fleet, ssh, dispatch, multi-node]
    related_skills: [hermes-agent, hermes-docker-fleet, linear-dispatch-architecture]
---

# Distributed Hermes Fleet Orchestration

Deploy Hermes agents across **multiple physical nodes** (VMs, servers, or machines) with centralized Kanban task dispatch and named profile execution.

## When to Use

- **Multi-machine autonomous systems**: Control plane coordinates work across 2+ worker nodes
- **Distributed AI workload management**: Profile-based workers on remote nodes executing tasks assigned by a central dispatcher
- **Scale beyond single-machine capacity**: Each worker node runs a full Hermes instance independent of others
- **SSH-accessible infrastructure**: All worker nodes reachable via SSH from control plane

## Core Concept

```
CONTROL PLANE (60.10)
├── Rai profile (dispatcher)
│   └── Polls Linear every N minutes
│       └── Creates Kanban tasks on central board
└── Kanban dispatcher daemon
    └── Reads central kanban.db
        └── For each ready task:
            └── SSH to assigned worker node
                └── Spawns: hermes --profile <profile-name> [KANBAN env vars]

WORKER NODE 01-09 (local Hermes instances)
├── Terminal backend: local (executes on node)
├── Kanban access: NFS mount → /shared/mnt/kanban.db (central board)
├── Profiles: mai-architect, kai-validator, quinn-support, amelia-comms, etc.
└── On task spawn:
    └── Reads task via kanban_show tool
    └── Executes work locally
    └── Calls kanban_complete (writes to central board)
```

**Key invariant**: Kanban board is the system of record — all state lives in central SQLite.

---

## Architecture Overview

### Three Layers

1. **Control Plane** (`terminal.backend: ssh`):
   - Runs Rai profile (ops + dispatcher)
   - Owns kanban.db (SQLite on local disk)
   - Cron jobs poll Linear, create tasks
   - Dispatcher monitors task state transitions
   - **All SSH targets pre-configured** in `config.yaml`

2. **Worker Nodes** (`terminal.backend: local`):
   - Run full Hermes instances (independently)
   - Each mounts central kanban.db via NFS
   - Profiles (mai, kai, laura, quinn, amelia, etc.) are spawned on-demand
   - Never poll; only execute when dispatcher spawns them

3. **Shared Storage** (NFS):
   - `/shared/mnt/kanban/kanban.db` — central task board
   - Accessed by control plane (exclusive writer via dispatcher)
   - Accessed by all worker nodes (read during task execution, write on completion)

---

## Configuration

### Control Plane (60.10) — config.yaml

```yaml
terminal:
  backend: ssh
  ssh:
    hosts:
      - user@node01.internal:22
      - user@node02.internal:22
      # ... through node09
    key_file: ~/.ssh/id_rsa
    known_hosts_file: ~/.ssh/known_hosts
    connection_timeout: 10
    command_timeout: 600  # Long tasks may take time

kanban:
  db_path: /shared/mnt/kanban/kanban.db  # Local NFS mount on control plane
```

**Profiles on control plane**:
- `rai-ops` — dispatcher, Linear poller, ops tasks (Rai profile ONLY; no other profiles here)

**Cron job** (run on control plane):
```bash
hermes --profile rai-ops cron create "*/1 * * * *" \
  --prompt "Poll KOHD Linear project. For each NEW issue (Status=Backlog), create a kanban task with assignee derived from issue tags."
```

### Worker Nodes (01-09) — config.yaml

```yaml
terminal:
  backend: local
  cwd: /workspace/hermes-work

kanban:
  db_path: /shared/mnt/kanban/kanban.db  # NFS mount (same path as control plane for simplicity)
```

**NFS Mount on each worker** (as root or via sudoers):
```bash
sudo mount -t nfs 60.10:/export/kanban /shared/mnt/kanban
# Or add to /etc/fstab:
60.10:/export/kanban /shared/mnt/kanban nfs defaults 0 0
```

**Profiles on each worker**:
- `mai-architect` (design, content, platform decisions)
- `kai-validator` (QA, testing, validation)
- `laura-orchestrator` (routing, sprint planning)
- `quinn-support` (support, troubleshooting)
- `amelia-comms` (communications, status updates)

---

## End-to-End Flow

### Task Creation → Dispatch → Execution → Completion

**1. Neil creates issue on Laptop**
```
Linear: "Implement dashboard" (Status=Backlog, Tag=#design)
```

**2. Rai cron (1-min) detects & routes to Kanban**
```
hermes kanban create \
  --board kohd \
  --assignee mai-architect \
  --title "Implement dashboard" \
  --description "From Linear issue KOHD-42: ..."
```
→ Task status: `todo` → Rai posts comment to Linear: "Queued as kanban task ABC123"

**3. Kanban dispatcher (gateway daemon on 60.10) detects ready**
```
Dispatcher reads kanban.db → sees task in ready state
→ Resolves assignee: mai-architect
→ Attempts spawn: ssh node03 hermes --profile mai-architect [KANBAN_TASK_ID=ABC123 ...]
```

**4. Mai spawns on node03, executes**
```
Worker receives HERMES_KANBAN_BOARD=kohd, HERMES_KANBAN_TASK=ABC123
Worker calls: kanban_show ABC123 → reads task details from central board
Worker: "Let me design the dashboard..."
Worker calls: kanban_create (sub-task if needed)
Worker works locally on node03
Worker calls: kanban_complete ABC123 --summary "Dashboard completed; design doc at ..." --status success
```

**5. Rai detects completion**
```
Rai's next cron tick reads kanban.db
→ Sees task ABC123 now in completed state
→ Reads worker output + logs
→ Updates Linear issue KOHD-42 (Status=DONE, Comment with evidence JSON)
```

---

## Setup Checklist

- [ ] **NFS server on control plane** — exports `/export/kanban` from `/shared/mnt/kanban` (or equivalent)
  - [ ] Control plane: `mount -t nfs localhost:/export/kanban /shared/mnt/kanban` (verify access)
  - [ ] Worker nodes: `mount -t nfs 60.10:/export/kanban /shared/mnt/kanban` (verify access)
  - [ ] Permissions: Everyone can read/write (0777 or run as same UID)

- [ ] **SSH key on control plane** — `~/.ssh/id_rsa` authorized_keys on all 9 nodes
  - [ ] Test: `ssh user@node01 echo "OK"` (should succeed with no password)
  - [ ] Add to control plane `~/.ssh/config`:
    ```
    Host node*
      User <username>
      IdentityFile ~/.ssh/id_rsa
      StrictHostKeyChecking accept-new
    ```

- [ ] **Hermes installed on all nodes**
  - [ ] Control plane: `hermes --version` (e.g., v0.18.0)
  - [ ] Each worker node: `hermes --version` (same version recommended)

- [ ] **config.yaml on control plane**
  - [ ] `terminal.backend: ssh` with all 9 nodes listed
  - [ ] `kanban.db_path: /shared/mnt/kanban/kanban.db`

- [ ] **config.yaml on each worker node**
  - [ ] `terminal.backend: local`
  - [ ] `kanban.db_path: /shared/mnt/kanban/kanban.db` (same path)

- [ ] **Profiles exported to nodes** (or built independently)
  - [ ] Each worker has profiles in `~/.hermes/profiles/<name>/`
  - [ ] Each profile has OAuth tokens in `~/.hermes/profiles/<name>/.env`

- [ ] **Hermes kanban init on control plane**
  ```bash
  hermes --profile rai-ops kanban init --board kohd
  ```

- [ ] **Smoke test** — run verification script (see references/)
  ```bash
  bash ~/.hermes/skills/distributed-hermes-fleet/scripts/verify-fleet-connectivity.sh
  ```

---

## Pitfalls

### ❌ Kanban DB Lock Contention
**Problem**: Multiple nodes trying to write to kanban.db simultaneously → SQLite locks, timeouts.

**Prevention**:
- Dispatcher runs ONLY on control plane (one writer)
- Worker nodes ONLY call `kanban_complete` (brief write)
- Use NFS with `hard` mount option for consistency:
  ```bash
  mount -t nfs -o hard,intr 60.10:/export/kanban /shared/mnt/kanban
  ```

### ❌ SSH Key Permissions
**Problem**: SSH fails silently; dispatcher can't spawn on worker nodes.

**Debug**:
```bash
ssh -vvv user@node01 echo test  # See where handshake fails
ssh-copy-id -i ~/.ssh/id_rsa user@node01  # Re-sync authorized_keys
```

### ❌ Stale Profiles on Worker Nodes
**Problem**: Control plane spawns profile, but worker node's version is outdated.

**Prevention**:
- Deploy profiles to all nodes atomically (ansible, git pull, export/import)
- Use cron on each worker to sync profiles from a central repo:
  ```bash
  hermes profile export <name> > /tmp/<name>.tar.gz
  scp /tmp/<name>.tar.gz node01:/tmp/
  ssh node01 hermes profile import /tmp/<name>.tar.gz
  ```

### ❌ NFS Mount Unmounts Between Reboots
**Problem**: Worker node reboots, NFS mount is gone.

**Prevention**: Add to `/etc/fstab` (persistent across reboots):
```
60.10:/export/kanban /shared/mnt/kanban nfs defaults,hard,intr 0 0
```

### ❌ Dispatcher Doesn't Spawn Because Assignee Doesn't Exist
**Problem**: Task assigned to `unknown-profile`, task stays in `ready` forever.

**Prevention**:
```bash
hermes kanban diagnostics --board kohd  # Shows unresolved assignees
# Manually promote back to todo and reassign to existing profile:
hermes kanban reassign <task-id> --profile mai-architect
```

### ❌ Worker Runs Out of Disk Space Mid-Task
**Problem**: Task fully completes but `kanban_complete` fails → task stays in progress.

**Mitigation**:
- Monitor `/workspace/hermes-work` on each node
- Set `container_disk: <size>` in config for container backends (not applicable to SSH local)
- Implement periodic cleanup cron jobs on worker nodes

---

## Monitoring & Verification

### Check Fleet Status

```bash
# On control plane:
hermes kanban stats --board kohd  # Task counts per status
hermes kanban list --board kohd --status running  # See executing tasks
hermes kanban tail <task-id>  # Follow a task's event stream live
```

### View Worker Logs

```bash
# On control plane, for a specific task:
hermes kanban log <task-id>  # Worker's stdout/stderr from execution

# Or SSH to node directly:
ssh user@node03 tail -f /shared/mnt/kanban/<board>/logs/<task-id>/output.log
```

### Health Check

See `scripts/verify-fleet-connectivity.sh` (included) for:
- SSH connectivity to all nodes
- NFS mount health on all nodes
- Hermes version on all nodes
- Profile presence on all nodes
- Kanban.db accessibility

---

## v0.18.0 Specifics

This skill targets **Hermes v0.18.0 (2026.7.1)** natively:

- ✅ `terminal.backend: ssh` fully supported
- ✅ `kanban` CLI and daemon available
- ✅ `kanban_*` toolset for worker agents
- ✅ Named profile spawning via Kanban dispatcher
- ✅ Multi-board isolation (`--board <slug>`)

Verify your version:
```bash
hermes --version
# Should show: Hermes Agent v0.18.0 (2026.7.1)
```

---

## References

See `references/` directory for:
- `kanban-v0.18.0-multi-node.md` — Detailed Nous docs excerpts for this version
- `terminal-backend-ssh.md` — SSH terminal backend configuration deep-dive

See `templates/` for:
- `control-plane-config.yaml` — Full example
- `worker-node-config.yaml` — Full example

See `scripts/` for:
- `verify-fleet-connectivity.sh` — Automated smoke test
