# Kanban Dispatch Over SSH (v0.18.0)

## How Hermes' Native SSH Terminal Backend Enables Multi-Node Dispatch

### The Key: `terminal.backend: ssh`

When the control plane runs with `terminal.backend: ssh`, **all terminal operations** (tool calls that execute shell commands) are tunneled over SSH to the configured remote hosts.

**Critical**: The Kanban dispatcher is a **built-in gateway component** that spawns worker processes via the terminal backend. So when you run:

```bash
hermes kanban dispatch
```

or the dispatcher daemon auto-runs inside `hermes gateway`, it:

1. Detects ready tasks in kanban.db
2. For each ready task with assignee=`mai-architect`:
   - Constructs: `hermes --profile mai-architect [KANBAN env vars]`
   - Routes to SSH backend
   - Executes on one of the configured SSH hosts
   - mai-architect process starts on the remote node

**Result**: Named profiles execute on remote nodes, not on the local machine.

### Config Shape (Control Plane)

```yaml
terminal:
  backend: ssh
  ssh:
    hosts:
      - user@node01.internal:22
      - user@node02.internal:22
      - user@node03.internal:22
      # ... node04 through node09
    key_file: ~/.ssh/id_rsa
    known_hosts_file: ~/.ssh/known_hosts
    connection_timeout: 10
    command_timeout: 600
```

Dispatcher:
- Picks a host from the list (round-robin or least-loaded, exact algorithm in hermes source)
- SSHes into that host
- Runs `hermes --profile <assignee>` with KANBAN env vars
- Process runs on the remote machine

### Worker Node Config (Each of 01-09)

```yaml
terminal:
  backend: local
  
kanban:
  db_path: /shared/mnt/kanban/kanban.db
```

When a worker profile spawns on node03, it has:
- `terminal.backend: local` → runs commands on node03 itself
- Shared access to `/shared/mnt/kanban/kanban.db` → reads tasks, writes completion

### The Kanban Daemon (Dispatcher Loop)

After `hermes gateway` starts on control plane, the dispatcher runs continuously:

**Every second (or configurable interval)**:
```
1. Read kanban.db (lock safe, SQLite concurrency handled)
2. Find tasks in status=ready (and not claimed)
3. For each ready task:
   - Check if assignee profile exists (in ~/.hermes/profiles/ on control plane)
   - If not → leave ready with diagnostic
   - If yes, check terminal backend to determine spawn target
     - ssh backend: pick an SSH host, spawn there
     - local backend: spawn locally (for small fleets or single-node boards)
     - docker backend: spawn in a container
   - Atomically claim task (mark as claimed by this dispatcher instance)
   - Spawn worker process with HERMES_KANBAN_TASK_ID set
   - Wait or poll for completion
4. Repeat
```

### Why NFS Mount on Worker Nodes?

Worker nodes need `/shared/mnt/kanban/kanban.db` (NFS) because:

1. **Task Discovery**: When kanban dispatcher spawns `hermes --profile mai` on node03, mai's first action is `kanban_show` which reads from kanban.db
2. **Completion Write**: After work, mai calls `kanban_complete`, which writes a completion record to kanban.db
3. **No Polling Loop**: Worker nodes never actively poll; they only act when spawned. The dispatcher on control plane is the only active poller.

NFS allows all nodes to see the same board, with control plane as the author (dispatcher) and worker nodes as transient readers/writers.

### Isolation & Failure Handling

**Task Claim Lock**:
- Dispatcher atomically claims a task before spawning
- If spawn fails or worker crashes, dispatcher (via auto-reclaim logic) releases the claim after a timeout
- Task moves back to `ready`, dispatcher retries (up to `failure_limit`, default 2)
- After 2 failures, task auto-blocks to prevent infinite loop

**SSH Failures**:
- If SSH to node01 times out, dispatcher tries next SSH host in list
- If all hosts are unreachable, task stays in `ready` but is not claimed (safe state)
- Dispatcher retries next cycle

---

## Kanban Worker Lanes (v0.18.0 Terminology)

A **worker lane** is the abstraction for "where can a task run".

### Three Lane Types:

1. **Profile Lane** (default):
   - Assignee is a Hermes profile name (e.g., `mai-architect`)
   - Dispatcher checks if profile exists locally (for local backend) or on any SSH host (for ssh backend)
   - Spawns: `hermes --profile <assignee> [KANBAN env]`

2. **Plugin/CLI Lane**:
   - Assignee is a registered non-spawnable identifier (e.g., `review-bot`)
   - Dispatcher calls a pluggable handler (e.g., a webhook or external script)
   - Not used for this multi-node fleet (skip)

3. **API Lane**:
   - Non-Hermes external worker pulls tasks via REST API
   - Not used here (skip)

For your fleet: **all tasks use Profile Lanes**. Dispatcher routes to named profiles (mai, kai, laura, quinn, amelia), spawned on SSH nodes.

---

## Gotchas & Specifics

### SSH Host Selection
- Dispatcher does **not** know profile assignment to nodes
- Any profile can be spawned on any SSH host (round-robin)
- If a node doesn't have a profile installed, spawn fails → auto-reclaim → retry

**Solution**: Deploy all profiles to all nodes (or use a sync cron job).

### Kanban.db Concurrency
- **SQLite WAL mode** (write-ahead logging) handles NFS concurrency
- Max writers = 1 (the dispatcher on control plane)
- Many readers (worker nodes, CLI commands)
- **Hard NFS mounts** are critical: if NFS goes down, do not allow SQLite to timeout silently

```bash
# Good:
mount -t nfs -o hard,intr,retrans=5 60.10:/export/kanban /shared/mnt/kanban

# Bad:
mount -t nfs 60.10:/export/kanban /shared/mnt/kanban  # Soft mount; can timeout
```

### Dispatcher Restart Safety
- If dispatcher dies, tasks in-progress stay claimed until timeout
- Timeout is `task.claim_timeout`, default 5 minutes
- After timeout, auto-reclaim releases the task back to `ready`
- Next dispatcher spawn will retry

**Best Practice**: Use systemd or supervisor to auto-restart `hermes gateway` on control plane.

---

## Smoke Test Commands

```bash
# On control plane:
hermes kanban init --board kohd
hermes kanban create --board kohd --assignee mai-architect --title "Test task" --description "Verify dispatch"

# Watch dispatcher spawn:
hermes kanban watch --board kohd  # Live event stream

# In another terminal, tail the task:
hermes kanban tail <task-id>

# After completion, check result:
hermes kanban show <task-id>
hermes kanban log <task-id>
```

Expected flow:
```
1. Task created with status=todo
2. Dispatcher promotes to ready (automatic or manual: hermes kanban promote <task-id>)
3. Dispatcher detects ready, spawns on a worker node (e.g., node05)
4. Worker profile starts, calls kanban_show, reads task,does work, calls kanban_complete
5. Status transitions: todo → ready → claimed → in_progress → completed
6. Result visible in kanban show <task-id>
```
