# Session Notes: Control-Plane Autonomous Suite (2026-07-02)

## Resolved environment facts
- Control-plane host reachable at `administrator@192.168.60.10` using the local SSH key.
- The control plane can SSH directly to worker nodes with the same key.
- Linear token worked only when sent as a raw API token in `Authorization: <token>`.
- Current Linear query for finding the canonical issue by identifier:
  - `searchIssues(term: "KS-3048", first: 5)`
- Canonical parent issue details discovered during the session:
  - Issue identifier: `KS-3048`
  - Issue id: `da4048e4-ca46-47f0-87c9-fd4209ac471a`
  - Team key: `KS`
  - Team id: `51796d2d-8179-49bb-9ea6-559f9da98a23`
  - Team name: `KS_Kohd Systems`

## Launch path lessons
- Stage suite files on the control plane in a proper `scripts/` and `docs/` tree before running.
- Keep the suite runner and node scripts in sync; stale staged copies can silently preserve the old SSH path.
- For this session, the worker scripts should SSH directly to the node from the control plane; a redundant control-plane-to-control-plane hop caused the initial failure.
- When the user says “do not ask again” or “carry on,” proceed with the best available path and only stop for hard blockers.

## Evidence body template used in the run
```text
Actor: <worker>
Node: <node name>
Host: <node host/IP>
Stage: <readiness|smoke>
Run ID: <run id>
Exit code: <code>

Evidence:
<host output>
```

## Useful command pattern
```bash
ssh -i ~/.ssh/id_ed25519 administrator@192.168.60.10 \
  'ssh -i ~/.ssh/id_ed25519 administrator@192.168.60.12 "hostname; whoami"'
```
