# Linear project-comment troubleshooting

## When this applies
Use this reference when a project appears to have comments/updates that are visible in the UI but the agent keeps finding issue comments instead.

## What happened in ECOPUK
- The project `CD__ecopuk` had two visible project-level comments/updates.
- The correction workflow initially used issue-comment lookups, which produced `Issue not found`.
- After repeated failures, the Linear MCP server became unreachable for that session.
- No edits were made because the object type could not be positively identified.

## Correct approach
1. Identify the object type before editing:
   - issue comment
   - project update/comment
   - status update
2. Use the project-specific query/tool path for project-level updates.
3. Only delete/recreate after you have the exact id and author.
4. If the tool keeps returning issue-related errors, stop and re-check the target object rather than assuming the comment is missing.

## Useful symptoms
- `Issue not found` while trying to inspect a project comment usually means the wrong tool or object type is being queried.
- A project can have visible comments/updates that are not represented by issue-comment tools.
- Repeated misrouting is a sign to back up and re-identify the Linear entity.

## Outcome discipline
- Do not rewrite content blindly.
- Do not delete a comment/update without first confirming the exact entity and author.
- Prefer a second, explicit retrieval pass over a guessed mutation.
