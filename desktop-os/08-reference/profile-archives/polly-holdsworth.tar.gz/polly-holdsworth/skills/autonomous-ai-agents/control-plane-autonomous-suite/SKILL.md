---
name: control-plane-autonomous-suite
description: Use when building or running autonomous node test suites that dispatch work to worker nodes while the control plane owns Linear updates, evidence collection, and timeout-safe orchestration.
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos]
metadata:
  hermes:
    tags: [autonomy, control-plane, linear, workers, evidence, timeouts, greenfield]
    related_skills: [hermes-agent, claude-code, codex]
---

# Control-Plane Autonomous Suite

## Overview
Use this skill for autonomous rollout or validation suites where the **control plane** owns credentials, Linear writes, scheduling, and aggregation, while **worker nodes** only run checks and return host evidence.

The key discipline is to keep the control plane authoritative and the workers clean:
- Linear GraphQL auth stays on the control plane
- workers never receive Linear tokens
- every node test posts back host evidence from the control plane
- each step is timeout-safe and fail-forward where appropriate
- prefer greenfield node identity and reject stale artifacts

## When to Use
- Building node-by-node autonomous test suites
- Orchestrating control-plane-to-worker dispatch
- Posting Linear issues/comments from a central runner
- Capturing host evidence proving a dispatch hit the intended node
- Running time-sensitive suites where stale waits waste time

Do not use this skill for:
- one-off local scripts that never touch Linear
- pure coding tasks without orchestration
- legal or financial decision-making

## Operating Rules
1. **Control plane owns Linear.** Do not place Linear credentials on worker nodes.
2. **Workers only execute.** Nodes should run readiness, smoke, recovery, or dispatch checks and return stdout/log evidence.
3. **Use dry-run first.** Print the outgoing Linear payloads before making the first real post when the suite is new or changed.
4. **Timeout every step.** Set per-command and per-node timeouts so one stalled node cannot block the rest.
5. **Fail forward, not silently.** Record timeouts and failures in the summary and in Linear.
6. **Capture host evidence.** Include timestamp, node host/IP, container name, image tag, restart policy, and a log excerpt.
7. **Keep nodes greenfield.** Replace stale `latest` containers, old volumes, and leftover bootstrap artifacts.
8. **Prefer node-specific identity.** Each worker should have its own volume/name/record, even when the image and entrypoint are shared.
9. **Use the right actor.** Post comments under the appropriate human worker identity for the workstream.
10. **Be decisive.** Derive IDs from canonical control-plane sources when possible; only stop for missing control-plane auth or legal/financial decisions. Otherwise choose the best next step and keep moving without extra questions.
11. **Use the raw Linear API token format.** Linear API keys go in `Authorization: <token>` headers, not `Bearer <token>`.
12. **Prefer current Linear schema over old examples.** If an old search/query shape is deprecated, switch to the current query field instead of retrying the dead shape.
13. **When a canonical parent anchor is known, proceed.** Reuse the canonical issue anchor from the control-plane sources and do not block on extra clarification.
14. **Distinguish issue comments from project-level updates/comments.** A Linear project can expose its own comments/updates that are separate from issue comments; inspect the object type before deleting or recreating anything.
15. **Refresh OAuth tokens before concluding the bearer path is broken.** The Linear MCP token cache may need a refresh even when the server config is correct; re-read token state from `~/.hermes/mcp-tokens/linear.json` and retry the MCP path before escalating.
16. **If the MCP server routes the wrong object type, stop and re-identify.** A repeated `Issue not found` while looking for a project comment usually means the lookup target is wrong, not that the comment is missing.

See `references/linear-oauth-mcp-setup.md` for the session-learned Linear OAuth/MCP setup sequence and `references/linear-project-comment-troubleshooting.md` for project-comment vs issue-comment pitfalls.


## Recommended Execution Shape
### 1) Bootstrap
- Verify control-plane shell access
- Verify Linear auth on the control plane
- Discover the node list
- Create or reuse a parent suite issue
- Decide the run ID for traceability

### 2) Dry-run
- Emit the exact Linear GraphQL payloads
- Confirm issue titles, actor names, and evidence fields look right
- Fix payload shape before posting anything for real

### 3) Node loop
For each node:
- run readiness
- run smoke or dispatch proof
- capture stdout and log tail
- post the evidence back to the node’s Linear issue from the control plane

### 4) Aggregation
- build a pass/fail summary by node
- include issue IDs/URLs
- include the actor used
- include the host evidence fields
- post final sign-off only after the required checks pass

## Linear Posting Pattern
When posting from the control plane:
- create one parent suite issue
- create one child issue per node, or reuse a node issue if already present
- post readiness and smoke evidence as control-plane comments
- keep the body short and structured:
  - Actor
  - Node
  - Host
  - Stage
  - Run ID
  - Exit code
  - Evidence block

## Common Pitfalls
1. **Putting Linear tokens on workers.** This breaks the control-plane split and increases risk.
2. **Skipping dry-run.** Payload mistakes become expensive once the suite starts fanning out.
3. **Using stale nodes or old volumes.** Greenfield suites should replace old rollout artifacts.
4. **Letting one node stall the whole suite.** Always wrap each step in a timeout.
5. **Posting vague evidence.** Evidence should prove the dispatch on that specific host.
6. **Asking too many questions mid-run.** If the decision is not legal or financial, choose the best next step and proceed.
7. **Using the wrong Linear auth scheme.** API keys are sent raw in the Authorization header, not as Bearer tokens.

## Verification Checklist
- [ ] Control plane has Linear auth; workers do not
- [ ] Dry-run payloads are inspectable before real posting
- [ ] Each node step has a timeout
- [ ] Each node has host evidence with timestamp and node identity
- [ ] Node-specific Linear issue/comment exists for each test stage
- [ ] Summary includes pass/fail by node
- [ ] Stale artifacts are removed or replaced
- [ ] Final sign-off is posted only after required tests pass
