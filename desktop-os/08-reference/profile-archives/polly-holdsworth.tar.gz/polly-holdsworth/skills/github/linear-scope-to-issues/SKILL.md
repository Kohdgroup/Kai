---
name: linear-scope-to-issues
description: Convert scope documents (SOW, RFC, specs) to hierarchical Linear issue structures. Greenfield project bootstrap, consolidation, bulk-create patterns, GraphQL workflows.
meta:
  class: Linear project initialization & scope decomposition
  trigger: |
    Greenfield project setup, scope grooming from requirements doc (SOW, RFC, spec), 
    project consolidation/cleanup, bulk-create hierarchical issue structures, 
    multi-project scope verification & standardization
  related: linear-native-operating-model, linear-accurate-updates, ocr-and-documents
---

# Linear Scope-to-Issues: Convert Scope Documents to Hierarchical Issue Hierarchies

Use this when converting requirements documents (SOW, RFCs, requirements specs, blueprints) into Linear issue hierarchies. Covers scope decomposition, project consolidation, bulk-create patterns, and GraphQL workflows.

## When to Use

- **Greenfield project bootstrap** — new project, needs populated from scope doc
- **SOW/RFC → implementation** — requirements doc becomes Linear epic/story hierarchy
- **Project consolidation** — discover duplicates, merge into single source of truth, verify cleanup
- **Scope grooming** — group issues by workstream, finalize acceptance criteria
- **Multi-project verification** — query Linear to confirm scope alignment across projects

## Workflow

### 1. Parse Scope Document

**Input:** SOW, RFC, requirements spec, feature doc (commonly PDF, Markdown, Google Doc, Word)

```bash
# If PDF: try pdftotext first, fall back to PyMuPDF if missing
pip install pymupdf  # Fallback for missing pdftotext
python3 << 'PARSE'
import fitz  # PyMuPDF
pdf_path = "path/to/doc.pdf"
doc = fitz.open(pdf_path)
for page_num, page in enumerate(doc):
    text = page.get_text()
    print(f"PAGE {page_num+1}\n{text}\n")
PARSE
```

**Extract:** Workstreams, epics, acceptance criteria, dependencies, timeline, personas/roles, open questions

**Output:** Structured notes (keep in `references/{project}-decomposition.md` for this session's context)

### 2. Query Existing Linear Projects (Consolidation Check)

**Always run before creation** to detect duplicates and decide consolidation strategy.

```graphql
query SearchByName {
  projects(first: 50, filter: { searchableContent: { contains: "PROJECT_NAME" } }) {
    nodes {
      id
      name
      url
      issues(first: 50) {
        nodes {
          id
          identifier
          title
          parent { identifier title }
        }
      }
    }
  }
}
```

**Gotchas:**
- `searchableContent` (NOT `searchableTitle` — field name changed in v1.7+)
- Auth header is token ONLY — no "Bearer" prefix: `Authorization: {token}` not `Authorization: Bearer {token}`
- Pagination: if 50+ issues, use `after` cursor for next page

**Outcomes:**
- ✅ No projects found → proceed with greenfield creation
- ⚠️ One project exists, empty → greenfield in existing project
- ❌ Multiple projects found → consolidate into single source of truth (user decision)

### 3. Design Hierarchy from Scope

Map scope document structure to Linear hierarchy:

**Common patterns:**

| Scope Structure | Linear Mapping | Notes |
|---|---|---|
| Workstreams A-F | Epics (1 per) | Top-level containers, phased |
| Major deliverables | Stories (children of epics) | Acceptance criteria per story |
| Implementation steps | Tasks (children of stories) | Optional granularity |
| Dependencies | Parent → child link + comment | Use `parentId` in mutation |

**Example:** Aardvark SOW
```
Sprint 0: Discovery & Blueprint (EPIC CD-344)
  ├─ Locked SOW v1... (STORY CD-349, child of CD-344)
  ├─ Confirmed business rules... (STORY CD-350, child of CD-344)
  └─ Pipeline, fields... (STORY CD-351, child of CD-344)

Sprint 1: Core Data Model & Intake (EPIC CD-345)
  ├─ Contact/customer structure... (STORY CD-352)
  ├─ Company/billing entity... (STORY CD-353)
  ... etc
```

### 4. Bulk-Create Issues via GraphQL Mutations

**GET TEAMID FIRST** — required field, commonly missed:

```graphql
query GetTeams {
  teams(first: 20) {
    nodes {
      id
      name
      key
    }
  }
}
```

**Identify correct team:** Match on `key` (e.g., "CD" for "CD_Client Delivery") or `name`.

**CREATE EPICS:**

```graphql
mutation CreateEpic {
  issueCreate(input: {
    teamId: "TEAM_ID_FROM_ABOVE"
    projectId: "PROJECT_ID"
    title: "Epic Title"
    description: "Epic description..."
  }) {
    issue {
      id
      identifier
      title
    }
    success
  }
}
```

**CREATE STORIES (with parent):**

```graphql
mutation CreateStory {
  issueCreate(input: {
    teamId: "TEAM_ID"
    projectId: "PROJECT_ID"
    title: "Story Title"
    description: "Acceptance criteria, context..."
    parentId: "EPIC_ID_FROM_ABOVE"
  }) {
    issue {
      id
      identifier
      title
      parent { identifier title }
    }
    success
  }
}
```

**Gotchas:**
- **Required:** `teamId`, `projectId` (or `parentId` if creating child under existing issue)
- **Don't use:** `identifier`, `relationshipUserIds` (not valid in v1.7+)
- **Parent linkage:** `parentId` is the issue's parent ID, NOT the key; must fetch ID first
- **Escape quotes:** In GraphQL strings, replace `"` with `\"`
- **Rate limiting:** Linear allows ~60 creates/min; batch in subprocess loops to avoid timeouts

### 5. Verify & Document

**Query final state:**

```graphql
query VerifyHierarchy {
  project(id: "PROJECT_ID") {
    name
    url
    issues(first: 100) {
      nodes {
        identifier
        title
        parent { identifier title }
      }
    }
  }
}
```

**Expected:** All epics present, all stories listed as children of correct epic, ID ranges correct, count matches design.

**Generate summary:**
- Total issues created (epics + stories)
- Hierarchical tree (group by parent)
- Identifier range (e.g., CD-344 → CD-380)
- Link to Linear project
- Open questions / scope gaps (from SOW if applicable)

## Pitfalls & Fixes

| Pitfall | Cause | Fix |
|---|---|---|
| "teamId required" error | Didn't fetch team from workspace | Always query teams first via `teams(first: 20)` |
| "Field X not defined" GraphQL error | Schema field name changed or misspelled | Check reference doc for current field names; use GraphQL introspection if unsure |
| Bearer token auth failure | Added "Bearer" prefix to token | Use `Authorization: {token}` without Bearer |
| Issues stuck in creation loop / timeout | Querying too many results or no pagination | Use `first: 50` or `first: 100` and `after` cursor for pages |
| Parent link fails after creation | Tried to set parent in first mutation | Create parent (epic) first, get its ID, then create child with `parentId` |
| Child issues not grouped correctly in view | Used wrong epic ID or created issues without parent | Verify `parentId` matches correct epic ID; query to confirm parent linkage |
| Consolidation creates duplicate work | Didn't verify existing projects first | **Always run consolidation query before creation** |

## Example: Aardvark Greenfield

**Trigger:** "Use this SOW as source of truth, then groom the Linear projects and give Aardvark a greenfield approach."

**Steps:**
1. ✅ Parse Aardvark SOW → extract 5 sprints, 6 workstreams, 32 deliverables, 15 open questions
2. ✅ Query Linear → found 2 Aardvark projects (CD__Aardvark_Fine_Arts, KOHD-DISCOVERY)
3. ✅ Consolidate decision → keep CD__Aardvark_Fine_Arts (active), deprecate KOHD-DISCOVERY (empty)
4. ✅ Design hierarchy → map sprints to epics (5), workstreams to epic children (32 stories)
5. ✅ Bulk-create → 5 epics + 32 stories in CD__Aardvark_Fine_Arts (parent-child relationships)
6. ✅ Verify → final state: 37 issues, CD-344 → CD-380, all hierarchies correct
7. ✅ Document → summary with open questions, next steps, architecture notes

**Result:** Greenfield Linear project from SOW, ready for Sprint 0 kickoff.

## API Reference

### Linear GraphQL Endpoints

- **Workspace:** `https://api.linear.app/graphql`
- **Auth header:** `Authorization: {API_TOKEN}` (no Bearer prefix)
- **Content-Type:** `application/json`

### Key Queries

| Query | Use | Notes |
|---|---|---|
| `teams(first: N)` | Get workspace teams (to find teamId) | Always run this first |
| `projects(filter: { searchableContent: ... })` | Find projects by name/content | Check for duplicates before creating |
| `project(id: ...)` | Get project details + issues | Use to verify final state |
| `issues(first: N, after: CURSOR)` | Query issues with pagination | Max 100 per query; use cursor for next page |

### Key Mutations

| Mutation | Use | Required Fields |
|---|---|---|
| `issueCreate(input: {})` | Create issue | `teamId`, `projectId` (or `parentId` for child) |
| `issueUpdate(id: ..., input: {})` | Update issue | `id`, then any fields to change |

## Related Skills

- **linear-native-operating-model** — Linear-first planning for KOHD projects (broader orchestration)
- **linear-accurate-updates** — Post results to Linear via OAuth human actor
- **ocr-and-documents** — Extract text from PDFs/scans when pdftotext unavailable
- **plan** — Markdown-format scope planning (complement to Linear hierarchy)

---

**Session artifact:** `/tmp/AARDVARK_GREENFIELD_SUMMARY.md` (Aardvark-specific execution detail)
