# Linear GraphQL API: Gotchas & Fixes

## Auth Header

**WRONG:**
```bash
curl -H "Authorization: Bearer lin_api_7XI..."
# Error: "It looks like you're trying to use an API key as a Bearer token. Remove the Bearer prefix."
```

**RIGHT:**
```bash
curl -H "Authorization: lin_api_7XI..."
# No Bearer prefix — token only
```

---

## Field Names: What Changed / Current State (v1.7+)

### Projects Query

| Field | Status | Note |
|---|---|---|
| `searchableTitle` | ❌ REMOVED | Use `searchableContent` instead |
| `searchableContent` | ✅ ACTIVE | Searches project name, description, content |
| `identifier` | ❌ REMOVED | No direct project identifier field |
| `key` | ❌ REMOVED (on Team, still exists) | Use `id` or `name` for matching |

### IssueCreate Input

| Field | Status | Note |
|---|---|---|
| `teamId` | ✅ REQUIRED | Must provide; fetch from `teams(first: 20)` query |
| `projectId` | ✅ REQUIRED | Must provide or use `parentId` for nested issues |
| `identifier` | ❌ REMOVED | Cannot set; auto-generated from team key + sequence |
| `relationshipUserIds` | ❌ REMOVED | Not a valid field in v1.7+ |
| `parentId` | ✅ ACTIVE | Use to create child issues under existing parent |

### Issue Fields

| Field | Status | Note |
|---|---|---|
| `parent` | ✅ ACTIVE | Returns parent issue object (id, identifier, title) |
| `issues` (on Project) | ✅ ACTIVE | Connection type; use `nodes` to get edges |
| `totalCount` | ❌ REMOVED (on Connection) | Count from `nodes` length or use specific query |

---

## Mutation Patterns

### Creating Hierarchical Issues

**Pattern: Epic → Stories → Tasks**

```graphql
# 1. Create Epic (no parent)
mutation {
  issueCreate(input: {
    teamId: "TEAM_ID"
    projectId: "PROJECT_ID"
    title: "Sprint 0: Discovery"
    description: "Lock SOW..."
  }) {
    issue { id identifier }
  }
}
# Returns: issue.id = "abc123"

# 2. Create Story (child of epic)
mutation {
  issueCreate(input: {
    teamId: "TEAM_ID"
    projectId: "PROJECT_ID"
    parentId: "abc123"  # <-- EPIC_ID from step 1
    title: "Locked SOW v1"
    description: "Obtain sign-off..."
  }) {
    issue { id identifier parent { identifier } }
  }
}
# Returns: issue.parent.identifier = "CD-344"
```

**Key Points:**
- Get epic `id` from first mutation return, use as `parentId` in second
- Do NOT query epic → try to fetch its ID separately; that adds latency
- Parent must be created FIRST before child can reference it

### Escaping Quotes

```graphql
# WRONG: Unescaped " inside string
mutation {
  issueCreate(input: {
    title: "Sprint "0": Discovery"  # <-- Breaks GraphQL parser
  }) { issue { id } }
}

# RIGHT: Escaped \"
mutation {
  issueCreate(input: {
    title: "Sprint \"0\": Discovery"
  }) { issue { id } }
}
```

---

## Pagination & Limits

### Query Limits

| Query | Max Results | Default | Pagination |
|---|---|---|---|
| `teams(first: N)` | 100 | — | `after` cursor required for page 2+ |
| `projects(first: N)` | 100 | — | `after` cursor required for page 2+ |
| `issues(first: N)` | 100 | — | `after` cursor required for page 2+ |

### Example: Get All Issues in Project

```graphql
query GetPage1 {
  project(id: "PROJECT_ID") {
    issues(first: 100) {
      pageInfo { hasNextPage endCursor }
      nodes { id identifier title }
    }
  }
}

# If hasNextPage = true:
query GetPage2 {
  project(id: "PROJECT_ID") {
    issues(first: 100, after: "CURSOR_FROM_PAGE1") {
      pageInfo { hasNextPage endCursor }
      nodes { id identifier title }
    }
  }
}
```

### Rate Limiting

- Linear allows **~60 issue creates per minute**
- Batch mutations in loops; use subprocess + timeout to avoid hangs
- If hitting limit, add 1-2 second delay between mutations or batch fewer per request

---

## Consolidation Pattern

**Always validate before creating:**

```graphql
# 1. Search for existing projects
query {
  projects(first: 50, filter: { searchableContent: { contains: "Aardvark" } }) {
    nodes {
      id
      name
      url
      issues(first: 100) { nodes { id identifier } }
    }
  }
}

# Outcomes:
# - 0 projects → greenfield, create in new project
# - 1 project (empty) → create in existing
# - 2+ projects → STOP, decide consolidation strategy with user

# 2. If consolidating into one:
#    - Identify primary project (usually the one with the formal name)
#    - Create all new issues there
#    - Archive or deprecate duplicates
#    - Document consolidation in Linear comment
```

---

## Team ID Discovery

**Never hardcode team ID** — query workspace:

```graphql
query {
  teams(first: 20) {
    nodes {
      id
      name
      key
    }
  }
}
```

**Match strategy:**
- If you know the team Name (e.g., "CD_Client Delivery"), find its `id` from results
- If you know the Key prefix (e.g., "CD" for identifier CD-344), find team with matching `key`
- Fallback: ask user which team

**Common KOHD teams:**
- `CD` (CD_Client Delivery) — client project work
- `KS` (KS_Kohd Systems) — platform/infrastructure
- `ARC` (Architecture, Operations & Business) — cross-functional
- `RAI` (Rai) — orchestration/automation

---

## Error Messages: Common Causes

| Error | Cause | Fix |
|---|---|---|
| `Field "teamId" is required` | Forgot to provide `teamId` | Query teams, pass correct team ID |
| `Field "searchableTitle" is not defined` | Using old field name (pre-v1.7) | Use `searchableContent` |
| `Cannot query field "identifier" on type "Project"` | Trying to query project.identifier | Query project.name or include in filter |
| `Cannot query field "totalCount" on type "IssueConnection"` | totalCount doesn't exist; count nodes length instead | Use `nodes { id }` then count |
| `It looks like you're trying to use an API key as a Bearer token` | Auth header has "Bearer" prefix | Remove "Bearer ", use `Authorization: token` |
| `No Authorization header provided` | Missing auth header entirely | Add `-H "Authorization: {token}"` |

---

## Session Examples

### Aardvark (2026-07-03)

**Challenge:** Create 5 epics + 32 stories in hierarchical structure

**Solution:**
1. Query teams → found `CD` (CD_Client Delivery) team
2. Create 5 epics in loop, collect IDs
3. Create 32 stories in loop, reference epic IDs as `parentId`
4. Verify with `project(id)` → `issues(first: 100)` → group by `parent.identifier`

**Gotchas hit:**
- Bearer token → fixed by removing prefix
- Missing teamId → added teams query upfront
- Field name errors → referred to current API docs

**Result:** 37 issues created in correct hierarchy, verified in Linear UI
