# Aardvark Scope Decomposition Pattern

**Source:** Aardvark_Art_Services_Draft_SOW_v1.pdf (June 2026)

**Type:** Service operations platform (fine art logistics)

**Decomposition Strategy:** SOW sections → Sprints → Workstreams → Stories

---

## Level 1: Sprint Structure (Epics)

SOW section 6 ("Delivery Approach") defines 5 phased sprints.

| Sprint | Linear Identifier | SOW Outputs | Key Deliveerable |
|--------|---|---|---|
| Sprint 0 | CD-344 | Locked SOW v1, confirmed rules, blueprint | Requirements lock |
| Sprint 1 | CD-345 | CRM model, job model, forms, office workflow | Data model foundation |
| Sprint 2 | CD-346 | Dispatch structure, driver workflow, POD | Operational execution |
| Sprint 3 | CD-347 | Communications, invoicing, Xero handoff | Finance integration |
| Sprint 4 | CD-348 | Dashboards, CSAT, UAT, training, readiness | Go-live readiness |

---

## Level 2: Workstreams → Stories

SOW section 5 ("Functional Workstreams") defines 6 parallel workstreams (A-F). Mapped to sprint epics:

### Sprint 0 (Discovery Lock)
- **CD-349** — Locked SOW v1 with stakeholder sign-off
  - Acceptance: Client approves all sections, no open-ended questions
- **CD-350** — Confirmed business rules (pricing, collections, urgent handling)
  - Acceptance: Answers to 15 open questions (listed below) documented
- **CD-351** — Pipeline, fields, and automation blueprint
  - Acceptance: Data model diagram, field list, automation triggers approved

### Sprint 1 (Core CRM & Intake) — Workstream A
Covers: Contacts, customers, companies, opportunities, jobs

- **CD-352** — Contact and customer structure design
  - Acceptance: Contact records, customer records, relationships defined in GHL
- **CD-353** — Company/billing entity structure
  - Acceptance: Company records, company-to-customer links, billing fields
- **CD-354** — Opportunity-led job records and linked references
  - Acceptance: Job record model, delivery-only / collection-only / linked types
- **CD-355** — Customer request form UI and backend
  - Acceptance: Public intake form deployed, captures all required fields
- **CD-356** — Internal office job-entry workflow
  - Acceptance: Admin-only form, allows manual job creation and edit
- **CD-357** — Chargeable vs. non-chargeable job handling
  - Acceptance: Business logic enforces rules, reporting shows both types

### Sprint 2 (Route-Run Dispatch & Driver Execution) — Workstreams B & C
Covers: Scheduling, dispatch, driver workflows, proof of delivery

- **CD-358** — Route-run data model and scheduling structure
  - Acceptance: Route object model, repeating/ad hoc templates, driver/van fields
- **CD-359** — This Week / Following Week / Backlog planning views
  - Acceptance: Office sees three planning timeline tabs, drag-assignable jobs
- **CD-360** — Driver and van allocation interface
  - Acceptance: Office can assign runs and/or jobs to drivers/vans, track capacity
- **CD-361** — Office dispatch control and visibility
  - Acceptance: Dashboard shows by date, run, driver, van, unallocated status
- **CD-362** — Minimal-access driver workflow UI
  - Acceptance: Drivers see only assigned work, no CRM exposure, controlled UX
- **CD-363** — Job status progression and completion flows
  - Acceptance: Jobs transition through states (assigned → en-route → arrived → complete)
- **CD-364** — Signature capture and proof-of-delivery
  - Acceptance: Driver can sign on mobile, proof recorded with job, office can review
- **CD-365** — Exception reporting for incomplete jobs
  - Acceptance: Driver can report job cannot complete, exception logged, office notified

### Sprint 3 (Communications, Billing & Xero) — Workstreams D & E
Covers: Customer journey comms, invoicing, finance sync

- **CD-366** — Customer communication event architecture
  - Acceptance: Automation triggers at: request ack, booking confirm, schedule confirm, reminders, delay, completion, CSAT
- **CD-367** — Multi-channel communication (SMS, email, WhatsApp, voice)
  - Acceptance: At least 2 channels live at launch; channel selection by message type and customer pref
- **CD-368** — Communication logging and missed-update visibility
  - Acceptance: All comms logged; office can see what was sent, delivery status, failures
- **CD-369** — Quote creation and management workflow
  - Acceptance: Office creates quote from job, quote is editable, can convert to invoice
- **CD-370** — Post-completion invoice creation
  - Acceptance: Invoice auto-created from completed job, includes line items, amounts
- **CD-371** — Office invoice verification and editing
  - Acceptance: Office reviews all invoices before approval, can edit amounts/items
- **CD-372** — Controlled handoff to Xero
  - Acceptance: Approved invoices sync to Xero, sync is reversible/auditable
- **CD-373** — Customer detail sync from Xero to GHL
  - Acceptance: Customer master data from Xero pulls into GHL, sync rules defined

### Sprint 4 (Dashboards, CSAT & Go-Live) — Workstream F
Covers: Reporting, satisfaction, reputation, readiness

- **CD-374** — Office dashboards (dispatch control, driver activity, communications, billing, feedback)
  - Acceptance: 5 dashboard tabs deployed, drill-down to individual issues
- **CD-375** — Owner dashboards (operations summary, revenue/conversion, service quality, reputation)
  - Acceptance: KPI dashboard shows top 5 metrics, trend charts, exception alerts
- **CD-376** — CSAT workflow and post-service surveys
  - Acceptance: Auto-send CSAT survey after completion, capture ratings, capture comments
- **CD-377** — Low-score follow-up process
  - Acceptance: Low CSAT scores (≤2) trigger escalation workflow, office review, response templates
- **CD-378** — Content and reputation workflow foundation
  - Acceptance: Foundation for managing external reviews, rating platforms, internal reputation
- **CD-379** — UAT environment setup and readiness testing
  - Acceptance: Production-like environment, manual + regression test suite, sign-off checklist
- **CD-380** — Training documentation and handover materials
  - Acceptance: Training video (office + driver workflows), runbooks, FAQ, support contacts

---

## Level 3: Open Questions (From SOW Section 9)

**These MUST be answered in Sprint 0 (CD-350) before Sprint 1 build:**

### Commercial & Pricing (3 questions)
1. What is the standard pricing model for deliveries? (per delivery / per route / per km / per kg?)
2. How should urgent collections be priced and approved?
3. For combined collection + delivery requests: one commercial quote + linked ops jobs, or two separate chargeable items?

### Operations & Dispatch (5 questions)
4. How are route runs defined in practice? (by area / weekday / postcode cluster / driver / van / case-by-case?)
5. Are route runs recurring templates, ad hoc runs, or both?
6. Can one route run include both collections and deliveries freely?
7. Does one route run normally have one driver + one van, or can multiple resources sit under one run?
8. Does office need drag-and-drop planning, or is structured list-based dispatch acceptable for phase 1?

### Driver Workflow & Proof (2 questions)
9. Does driver need a queue of all assigned jobs, or can field work be completed one job at a time via controlled links/pages?
10. Is signature alone enough at launch, or also: printed name, notes, photo evidence, condition notes?

### Communications (2 questions)
11. Which communication channels are definitely in scope at launch: SMS, email, voice, WhatsApp, or others?
12. What level of timing precision: date only, AM/PM, time window, en-route alert?

### Finance & Sync (2 questions)
13. Does every invoice require office review, or only exceptions?
14. Is Xero customer sync: one-time import, ongoing sync, or both?

### KPIs (1 question)
15. Which 5 KPIs matter most to owners in first live release? (e.g., on-time %, CSAT, revenue, exceptions, driver utilization)

---

## Scope Extraction Tips

### For Future SOWs

**Structure to watch for:**
- Executive summary → project intent (use as epic descriptions)
- Objectives → acceptance criteria for stories
- Proposed scope / Functional workstreams → map to epic children (stories)
- Delivery approach / Phases → map to sprint epics
- Assumptions → add to story descriptions as constraints
- Open questions / TBD items → flag in Linear, lock in Phase 0

**Common antipatterns:**
- SOW lists 20+ "things to build" without grouping → group by workstream, not by technical layer
- Open questions scattered through doc → consolidate, answer all in Phase 0 before Phase 1 kick-off
- No acceptance criteria → extract from SOW objectives or acceptance/delivery principles

---

## Project Template Mapping

**Aardvark is a "Service Operations" template:**

- **GHL-native** (all on GHL, no custom front-end or API layer)
- **Single customer** (one client, one instance, no multi-tenancy)
- **Route-run driven** (scheduling pivot, not CRM pivot)
- **Minimal driver access** (job completion, not CRM exposure)
- **Finance-integrated** (quote → invoice → Xero built-in)

**Contrast with KOHD Heritage (Multi-Tenant SaaS Template):**
- Multi-tenant (per-club instances)
- Webhook-driven (intake from customers)
- Full CRM + marketplace
- Complex provisioning (sub-account creation, schema isolation)

**Future projects with similar structure to Aardvark:**
- Any "field operations" platform (deliveries, repairs, installations)
- Any "intake → scheduling → execution → billing" workflow
- Any service business wanting minimal field app footprint

