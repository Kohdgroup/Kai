# Aardvark session notes

This session established several layout and wording rules for customer-facing process decks.

## Effective deck pattern
- Repeat the same **process spine** on every page.
- Keep a visible **How to read this page** key near the top.
- Add a short **Page guide** sentence for each page.
- Keep the active stage highlighted in the spine.
- Use generous top-right padding so header labels do not touch the page edge.
- Keep the main flow vertically centered and below the key band.

## Queue / planning wording used
- **Coming Week**
- **Following Week**
- **Future Dates to Set**

## Multi-van planning
- The deck should show a distinct **van run allocation** step.
- Multiple vans may be assigned across different runs.
- Future automation ideas can be shown as a separate page, not blended into the current-state flow.

## Customer-review structure
Pages used in the deck:
1. Master Customer Journey
2. Queue Allocation Flow
3. Estimate Preparation Flow
4. Booking Flow — Delivery or Pickup
5. Day-of Delivery Confirmation Flow
6. Delivery Completion Flow
7. Pickup Completion Flow
8. Closeout Flow
9. Exception / Delay Flow
10. Optional future-enhancement page for run planning automation
