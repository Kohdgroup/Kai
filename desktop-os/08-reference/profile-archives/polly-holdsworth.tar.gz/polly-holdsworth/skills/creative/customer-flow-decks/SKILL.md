---
name: customer-flow-decks
description: Build customer-facing process flow decks with clear stage spines, reading keys, and future-state variants.
version: 1.0.0
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [diagrams, flowcharts, customer-facing, presentation, process, html, pdf]
---

# Customer Flow Decks

Use this skill for customer-facing process diagrams that need to be understandable by non-technical stakeholders.

## When to use
- customer validation decks
- business process flowcharts
- multi-page process presentations
- future-state / current-state comparison decks
- operational flows that need to be reviewed with customers

## Core approach
1. **Start with the business journey**, not the implementation.
2. **Repeat a stage spine on every page** so the reader can orient instantly.
3. **Add a key / legend / reading guide** near the top of each page.
4. **Keep language business-centric** and remove technical jargon unless the customer already uses it.
5. **Show queueing / planning buckets explicitly** when the process depends on them.
6. **Include future-state enhancements as separate pages** when the idea is not live yet.
7. **Keep flows vertically centered** so the page reads cleanly and does not collide with the key/header.

## Layout rules
- Use left-to-right flow on a page unless the business meaning is clearer another way.
- Keep the top header roomy; add right padding to prevent labels from hitting the edge.
- Keep the main process lower than the key band.
- Prefer orthogonal connectors that do not cross through box centers.
- Use consistent stage numbering across all pages.
- Use short helper notes only where they improve comprehension.

## Common stage spine
A good default spine for Aardvark-style customer reviews is:
- Request
- Estimate
- Approve
- Date / Queue
- Run Allocation
- Day Of
- Complete
- Invoice
- Close

Not every page needs to emphasize all stages equally, but the spine should still appear so the deck reads as one process.

## Queue / planning labels
Prefer concrete planning buckets the customer recognizes:
- Coming Week
- Following Week
- Future Dates to Set

If the business uses a manual review pile for routing jobs into runs, show that as a planning step and, if needed, a future enhancement page.

## Future-state handling
When a process is currently manual but the customer may want automation later:
- label the page or section clearly as **Future Enhancement**
- describe what the manual process is today
- separate the aspiration from the current-state flow

## Export expectations
- Produce a clean HTML deck first when visual refinement is likely.
- Export to PDF only after the page layout is visually confirmed.
- Verify page spacing and header fit before claiming completion.

## Pitfalls
- Don’t put the flow too close to the key/header band.
- Don’t leave the reader guessing how to interpret colours or states.
- Don’t bury a future-state automation idea inside the current-state flow.
- Don’t use technical language when the user asked for customer-facing material.

## Related reference
- See `references/customer-flow-decks.md` for the Aardvark-style layout lessons, queue wording, and future-enhancement guidance.
