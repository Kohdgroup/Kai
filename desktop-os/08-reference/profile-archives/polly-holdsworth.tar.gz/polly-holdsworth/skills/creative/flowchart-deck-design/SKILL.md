---
name: flowchart-deck-design
description: Build polished multi-page flowchart decks for customer validation, process reviews, and future-state storytelling, usually as HTML first and PDF second.
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [flowcharts, decks, html, pdf, process, swimlanes, visualization, presentation]
    related_skills: [claude-design, architecture-diagram, excalidraw]
---

# Flowchart Deck Design

Use this skill when the user wants a **flowchart deck**, **process validation pack**, or **customer-facing operating model** with multiple pages/slides.

This skill is for decks where readability matters more than density, and where the user wants the result to be presented back for review or sign-off.

## Default approach

1. **Clarify the story shape**
   - What is current state vs future state?
   - Is this for customer validation, internal ops, or executive review?
   - Do they need one page per flow, or a single master flow?

2. **Choose the right framing**
   - Use business language first.
   - If the deck includes future-state ideas, label them clearly as **Assisted** or **Future**.
   - Avoid technical system labels unless the audience is technical.

3. **Design for read-through**
   - Add a repeated process spine or stage bar at the top of each page.
   - Add a short key / explanation band beneath the header.
   - Keep the main flow centered vertically and horizontally.
   - Leave generous header padding, especially on the right.

4. **Use swimlanes when the story needs separation**
   - Common lanes: Today / Assisted / Future.
   - Each lane should read as a complete mini-flow.
   - Do not strip the start of a lane just to save space; restore the lane entrance so the narrative remains intact.

5. **Show operational queues clearly**
   - When the work has planning states, prefer business queues such as:
     - New Requests
     - Coming Week
     - Following Week
     - Future Dates to Set
   - If multiple vans/runs exist, make run allocation explicit.

6. **Build HTML first when possible**
   - Create the deck as a self-contained HTML artifact.
   - Verify visually in a browser.
   - Only then export to PDF.

## Layout principles

- Use one page/slide per flow when the audience is validating a process.
- Keep the title readable; do not let the top-right metadata collide with the edge.
- Keep the key or legend lightweight but visible.
- Make routing clean; no connectors through the middle of nodes.
- Use consistent spacing across pages so the deck feels like one system.

## Good labels

Prefer labels that sound like business states or actions:
- Request received
- Estimate sent
- Approved?
- Future Dates to Set
- Coming Week
- Following Week
- Allocate to van run
- Signature captured
- Invoice auto-created
- Review request sent

## Anti-patterns

- Treating future-state ideas as if they are already live.
- Overly technical labels in a customer-facing deck.
- Letting the key collide with the flow.
- Removing the beginning of a swimlane so the lane no longer reads as a full flow.
- Making every page look like a different design system.
- Overpromising full automation when the process is still human-in-the-loop.

## Verification checklist

Before handing the deck over:
- Title and header are fully visible.
- Right-side header has breathing room.
- Key / legend is readable.
- Flow is vertically centered and not touching the reading band.
- Swimlanes all start cleanly.
- Page count matches the deck.
- If a future-state page exists, it is clearly separated from today’s process.

## Support files

- `references/flowchart-deck-session-notes.md` — session-derived rules and layout lessons.
