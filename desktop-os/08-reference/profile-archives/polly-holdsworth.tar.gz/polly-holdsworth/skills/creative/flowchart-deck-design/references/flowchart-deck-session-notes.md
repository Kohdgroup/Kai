# Flowchart Deck Session Notes

This reference captures the recurring patterns that worked for the Aardvark customer-validation deck.

## Useful structure
- Build multi-page HTML first, then export to PDF.
- Use one page per flow when the audience needs validation or review.
- Keep a repeated process spine at the top of each page so the deck reads end-to-end.
- Add a small key / explanation band below the header so colors and lane meanings are immediately obvious.
- Leave extra padding on the right side of the header and after the final spine item (e.g. `Complete`).

## Swimlane pattern
For future-state pages, separate lanes by business state rather than by technical system:
- Today
- Assisted
- Future

In the Aardvark session, the later slide worked best when it explicitly restored the start of each swimlane so each lane read as a mini-flow:
- Today: manual invoicing
- Assisted: driver captures signature → invoice auto-created and auto-sent
- Future: automatic review request → visibility/trust improvements → AI follow-up

## Typical stage labels used
- Request
- Estimate
- Approve
- Date / Queue
- Run Allocation
- Day Of
- Complete
- Invoice
- Close

## Layout warnings discovered
- Do not let the main flow collide with the “How to read this page” band.
- Center the spine and the page header visually; give the top-right metadata breathing room.
- If you add a future-state / art-of-the-possible page, label it clearly as assisted/future-state and keep it human-in-the-loop.

## Export note
A clean HTML deck can be verified visually in-browser before PDF export. When PDF export is needed, a headless browser print route is usually the right path; if the environment blocks one exporter, switch to another instead of changing the deck design.
