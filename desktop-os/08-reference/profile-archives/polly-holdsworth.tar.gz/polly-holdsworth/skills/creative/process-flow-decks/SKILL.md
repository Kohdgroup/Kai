---
name: process-flow-decks
description: Create polished, customer-facing process flow decks as HTML/PDF with legends, stage spines, and future-state pages.
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [diagrams, flowcharts, html, pdf, presentation, customer-facing, process, transformation]
---

# Process Flow Decks

Use this skill when the user wants a **customer-facing flow deck**, **process diagram set**, **journey map**, or **future-state transformation story** presented as a polished HTML artifact and optionally exported to PDF.

This skill is about **clarity + presentation quality**, not raw diagram generation.

## Core principles

- Make the deck readable by non-technical stakeholders.
- Prefer **business language** over implementation jargon.
- Use **one clear flow per page** when the process is long.
- Add a **legend / key** and a short **How to read this page** band.
- Keep a repeated **process spine** when it improves continuity.
- Leave enough padding around header elements so nothing feels cramped or clipped.
- Re-layout the page if connectors cross through boxes; do not try to hide a bad composition with styling.
- Route connectors orthogonally where possible.
- Use explicit states for **Today / Assisted / Future** when presenting transformation concepts.
- Keep future-state claims credible and human-in-the-loop unless the user explicitly wants a fully automated vision.
- When the user wants extra depth, add **click-to-reveal stage detail** so the main flow stays business-facing while technical notes live behind progressive disclosure.

## Recommended workflow

1. **Identify the audience**
   - customer validation
   - internal operations review
   - transformation roadmap
   - executive summary

2. **Choose the surface**
   - process/journey decks should usually be a **Monitor** or **Operate** style surface, not a marketing hero layout.

3. **Define the stage model**
   - examples: Request, Estimate, Approve, Date / Queue, Run Allocation, Day Of, Complete, Invoice, Close
   - keep the same stage labels across pages when possible

4. **Build the page structure**
   - header with title + subtitle
   - spine/legend area
   - explanation band
   - main flow area
   - small footer note

5. **Lay out the flow**
   - center the diagram vertically if the page has a lot of white space
   - move the flow lower if the key band is crowded
   - separate planning buckets clearly (e.g. Queue 1 / Coming Week / Following Week / Future Dates to Set)
   - make manual vs assisted vs future-state distinctions obvious

6. **Verify visually**
   - inspect the first page and the most crowded page
   - check the header right edge and title clipping
   - check that the key does not collide with the diagram
   - check that stage pills fit with extra padding after the final stage if the header is long

7. **Export only after the HTML is correct**
   - if PDF export is needed, do it after visual verification
   - prefer a clean export route over a low-fidelity fallback

## Future-state / digital transformation pages

When the user wants “art of the possible” or digital transformation content:

- split the page into **Today**, **Assisted**, and **Future** lanes or columns
- explicitly show what remains manual today
- show what GHL/AI can assist with now
- show the future capability as a credible next step
- examples of valuable future-state outcomes:
  - automatic review requests after completion
  - better visibility into job status and customer satisfaction
  - smarter run grouping / route suggestions
  - faster estimate preparation
  - automated customer reminders and updates

## Common pitfalls

- Putting too much text in the header or legend.
- Letting the process run into the key band.
- Making the top-right stage pills touch the edge.
- Mixing current state and future state without labels.
- Using technical implementation language for customer-facing decks.
- Exporting to PDF before the HTML composition is actually good.

## Verification checklist

- File exists at the expected path.
- Deck opens in the browser without clipping.
- Header is fully visible.
- Key/legend is readable.
- Flow is vertically balanced.
- No connector crosses through box centers.
- Future-state slide clearly distinguishes manual, assisted, and future behavior.

## Reference material

See `references/process-flow-decks.md` for session-learned layout and presentation rules, including header padding, key placement, flow centering, and future-state framing.
