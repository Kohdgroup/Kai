# Process Flow Deck Notes

This reference captures the layout and wording decisions learned while building customer-facing process flow decks.

## What worked
- A repeated process spine across pages makes the deck easier to follow.
- A dedicated key / legend band helps non-technical reviewers understand the colors and flow states.
- A short page guide near the top improves readability.
- Moving the diagram lower avoids collisions with the key band.
- Extra padding after the final stage pill prevents the header from feeling cramped.
- Business-friendly language reads better than technical implementation language.
- Vertically centering the flow improves readability when the page has more white space.

## Planning / queue model learned during the session
For planning and run allocation, prefer wording like:
- Coming Week
- Following Week
- Future Dates to Set

This worked better than a generic backlog label because it matches how the business actually plans van runs.

When multiple vans exist, make the run allocation explicit rather than implying a single queue.

## Click-to-reveal stage detail
Clickable stage detail is useful when the visible diagram stays business-facing and the technical solution is hidden behind progressive disclosure.

Use a small detail panel or drawer that reveals, for a selected stage:
- what happens
- trigger / condition
- what GHL does
- what AI does
- what humans still control
- failure / fallback behaviour if needed

This is especially helpful for stages like:
- Request
- Estimate
- Approve
- Date / Queue
- Run Allocation
- Day Of
- Complete
- Invoice
- Close

## Future-state framing
When the user wants an “art of the possible” page, keep it credible:
- Today = manual process
- Assisted = GHL + AI support, human-in-the-loop
- Future = guided automation, not magic autonomy

Useful future-state themes:
- AI reads and structures incoming requests
- GHL creates and drives the workflow
- jobs are grouped by date / region / fit
- driver signature can trigger auto-created / auto-sent invoicing
- review requests can be automated after signature or completion
- visibility improves through better status, chase, and feedback loops

## Presentation pitfalls discovered
- The top-right header pills can clip if the spine is too wide.
- The main diagram can collide with the key band if the page is not vertically centered properly.
- The deck is easier to read when each page contains one clear idea rather than too many sub-processes.
- The future-state page should explicitly contrast manual today vs assisted now vs future automation.

## Suggested review checklist
1. Open the HTML in a browser.
2. Check the header title and spine for clipping.
3. Confirm the key band is readable.
4. Check the most crowded page for overlap.
5. Verify the future-state page separates Today / Assisted / Future.
6. Export to PDF only after the HTML looks right.
