# Flowchart Deck Guidance

This reference captures the process-diagram pattern used for the Aardvark validation deck.

## Audience and tone
- Keep labels **business-centric** for customer review.
- Avoid implementation language unless the audience is internal.
- Prefer concise stage names: request, estimate, approval, slot, execution, signature, invoice, closeout.

## Queue model
Use explicit waiting states when delivery date is not yet fixed:
- **Queue 1: New Requests** — request received, not yet ready for scheduling
- **Backlog / Future** — approved but date still needs confirmation
- **Week 1** — active jobs due this week
- **Week 2** — active jobs due next week
- **Queue 3: Delivered / Collected / Closeout** — signed and ready for invoicing/closure

## Flow design rules
1. Build one flow per page for customer validation decks.
2. Keep arrows outside node centers; use orthogonal/elbow routing.
3. Route around boxes; never draw through the middle of a node.
4. Make decisions explicit (e.g. approved?, date confirmed?, issue or delay?).
5. Include signature -> office notification -> invoice -> closeout as a dedicated final path.
6. Show delivery and pickup as separate execution branches if both are in scope.
7. Include automated day-of-delivery confirmation as its own step.

## Diagram structure that worked well
- Header band with title and subtitle
- Small legend for queue colors
- Node rows with ample whitespace
- Optional explanatory callout cards under the main chain

## Pitfalls observed
- A generic "scheduled" bucket hides important customer-facing states.
- Delivery diagrams are incomplete without the date-confirmation and day-of confirmation stages.
- Backlog/future must be shown distinctly from Week 1 / Week 2.
- Straight connectors through node centers look cheap and reduce legibility.

## Recommended flow pages
1. Master customer journey
2. Queue allocation flow
3. Estimate preparation flow
4. Booking flow (delivery or pickup)
5. Day-of confirmation flow
6. Delivery completion flow
7. Pickup completion flow
8. Closeout flow
9. Exception / delay flow

## If exporting to PDF
- Prefer rendering from a designed HTML deck rather than trying to hand-draw a PDF directly.
- Verify visual layout in-browser before export.
- Keep page size consistent across the deck.
