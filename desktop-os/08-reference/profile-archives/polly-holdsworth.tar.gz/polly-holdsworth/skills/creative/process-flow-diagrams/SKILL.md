---
name: process-flow-diagrams
description: Create polished business/process flowcharts and validation decks as HTML, SVG, or PDF-ready artifacts.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [process, flowchart, diagram, deck, html, svg, pdf, business, operations]
    related_skills: [claude-design, architecture-diagram, excalidraw]
---

# Process Flow Diagrams

Use this skill for business/process diagrams, customer journey maps, queue/state flows, approval paths, and presentation decks where the goal is to explain an operating process clearly to stakeholders.

## When to use
- Business process flowcharts
- Customer validation decks
- Queue/state diagrams
- Approval / booking / fulfillment flows
- Customer-facing process explanations

## Working style
- Start with the **business outcome**, not implementation details.
- Use **non-technical labels** for external audiences.
- Prefer **one flow per page** when the goal is customer review or sign-off.
- Treat the diagram as a **communication artifact**, not just a draft of logic.

## Composition rules
1. Choose the primary flow type first:
   - journey / stage flow
   - queue allocation flow
   - decision / branching flow
   - closeout / exception flow
2. Place each status in an explicit lane or queue when the process depends on waiting states.
3. Keep arrows outside node centers; route with elbows or orthogonal paths.
4. Separate active queues from backlog / future states.
5. Keep closeout triggers clear: signature, office notification, invoicing, closure.

## Queue model
When jobs are waiting for a date or slot, represent them explicitly instead of collapsing them into a generic scheduled bucket.
Common business states:
- Queue 1: New Requests
- Queue 2: Confirmed Bookings
- Queue 3: Delivered / Collected / Closeout
- Backlog / Future: accepted but date still to be confirmed
- Week 1 / Week 2: active delivery queues once the date is known

## Delivery and pickup flows
For fulfillment processes, always show:
- estimate / approval
- slot booking
- day-of confirmation
- delivery or pickup execution
- signature capture
- office notification
- invoice issuance
- closure

## Artifact guidance
- Build as a clean **HTML + SVG deck** first when visual quality matters.
- Use CSS for the page frame, header, legend, and notes.
- Use SVG for the flow nodes and connectors.
- Export to PDF only after the deck has been visually checked.

## Verification
- Verify each page visually before sending.
- Check that connectors do not run through boxes.
- Check that labels remain legible at stakeholder-review size.
- Keep the deck business-centric unless the user explicitly wants technical detail.

## Pitfalls
- Do not over-technicalize the labels for customer-facing diagrams.
- Do not collapse backlog/future states into “scheduled”.
- Do not draw straight lines through the middle of nodes.
- Do not produce generic box-and-arrow clutter when a staged deck is requested.

See `references/flowchart_deck_guidance.md` for a concise pattern guide and queue/state notes.
