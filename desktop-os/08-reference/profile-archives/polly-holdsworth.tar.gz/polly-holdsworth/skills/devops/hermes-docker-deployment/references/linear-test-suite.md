# Linear Test Suite Blueprint

This reference captures the active Linear anchors and the validation pattern used for the Hermes GTM greenfield rollout.

## Primary anchor
- **KS-3048 — Platform Readiness: Hermes V3 Deployment Validation**

## Supporting issue chain observed in Linear
- KS-3051 — Infrastructure Unreachable (Command Gateway + Node Network)
- KS-3052 — Dispatcher (Rai) Process Not Running
- KS-3054 — Swarm Pool Not Active
- KS-3055 — Eve Sterling Reporting System Not Live
- KS-3056 / KS-3057 — historical blockers already completed
- KS-3049 / KS-3050 / KS-3053 — historical blockers already completed

## Proposed test suite structure
1. **Control plane readiness**
   - Confirm the dispatcher container is running.
   - Confirm Linear GraphQL access from inside the control plane.
   - Confirm Redis and Postgres health.

2. **Scope gate validation**
   - Confirm sprint membership and issue state determine dispatch scope.
   - Confirm the user-facing model stays Linear-first for internal work.

3. **Actor comments**
   - Verify comment templates for Rai, Laura, Eve, and Mai.
   - Verify blocker comments are written back to the issue.

4. **Worker execution**
   - Verify 9 Dockerized worker nodes can be reached over SSH.
   - Verify Docker runs successfully on each node.
   - Verify a faceless worker can take a dispatched task and return evidence.

5. **Done-done validation**
   - Verify evidence is attached or summarized in Linear before closure.
   - Verify a final validation note exists before marking the issue done.

## Notes
- Keep the suite concise and native; avoid adding extra labels or custom workflow state unless a real gap is found.
- Use this as the basis for Linear issues once the suite is created in the workspace.
