# Control-plane Linear dispatch notes

This reference captures the deployment pattern learned during the node01 → node02–node09 rollout.

## Key rule
- Linear auth and issue/comment posting stay on the **control plane**.
- Worker nodes only run the local readiness/smoke commands and return host evidence.
- Do not require Linear credentials on worker nodes for dispatch tests or sign-off helpers.

## Evidence pattern
Each worker test should capture:
- UTC timestamp
- hostname / node label
- container name
- pinned image tag
- restart policy
- container state
- short log excerpt
- optional container ID

## Greenfield worker rule
- Replace stale `latest` containers before relaunching a worker.
- Give each node its own storage identity (node-specific named volume or equivalent).
- Remove inherited bootstrap artifacts when they are no longer part of the clean baseline.

## Timeout rule
- Use per-step timeouts and fail-forward behavior.
- A single stalled node should not stale the whole suite.
- Prefer short freshness checks before acting on rebooted nodes.

## Linear posting shape
- Control-plane runner creates a parent suite issue.
- Control-plane runner creates one issue per node or one node-specific comment trail.
- Actor-authored comments should reflect the workstream (Kai/Mai/Rai etc.), not the control-plane operator identity.

## Deprecated pattern
- Node-local Linear signoff scripts are deprecated; they should be stubs or removed from the worker path.
