# Human Lattice

This reference captures the named human roles used in the Hermes GTM autonomy model.

## Triplets / platform core
- **Mai Matsuda** — Chief Platform Engineer
  - owns engineering, integrations, platform configuration, infrastructure build-out, environment preparation, Docker, Git, API integrations, GHL configuration, Linear preparation, and pre-Kai testing
- **Kai** — pre-prod
- **Rai** — production / orchestrator

## Delivery and governance
- **Laura Bennett** — delivery gate / Scrum Master
- **Eve Sterling** — Chief of Staff / escalation / risk / metrics

## Domain ownership
- **Quinn Graham** — engineering
- **Maya Khan** — customer
- **Thomas Advani** — commercial
- **Amelia Cross** — growth
- **Joseph Webb** — operations

## Routing note
- Use the lattice to route comments, blockers, and ownership in Linear.
- Do not collapse the named human layer into only four roles; the autonomy model depends on the broader set being preserved.
