# Greenfield Worker Rollout Notes

## What this session proved
- Worker nodes should be treated as **one-at-a-time** greenfield rebuilds.
- The safe pattern is: inspect current state → remove stale container → create fresh node-specific storage → pull pinned image → run → verify immediately.
- Node health checks should be re-run after any reboot or restart; earlier results become stale quickly.

## Node rollout rules
- Do **not** carry forward `latest`-tag worker containers when the rollout target is a pinned release.
- Do **not** reuse old node rollout artifacts, bootstrap tarballs, or legacy env/state when a clean-room rebuild is required.
- Give each node its **own identity**:
  - node-specific container name
  - node-specific storage volume
  - node-specific evidence trail in Linear if a node diverges
- When node storage is old or ambiguous, replace it with a fresh named volume for that node.

## Verified container fields to check
- image tag
- restart policy
- status
- restarting flag
- exit code
- started-at timestamp
- mount target for `/opt/data`
- logs immediately after start

## Timeout-safe execution pattern
When running rollout scripts or manual steps:
1. Run one step at a time.
2. Put a timeout on each step.
3. Re-check live state after each step.
4. Never trust a prior check if the host rebooted, the container restarted, or the command hung.

## Control-plane hop pattern
- If the authoritative path is via the control-plane server, use the server as the hop rather than going direct from the local workstation.
- This is especially useful when the local workstation lacks direct trust/route to the worker node.

## Clean-room proof checklist
- no legacy `latest` worker container remains
- no historical tarball/bootstrap bundle is reused
- no stale node-local env is required for normal operation
- the worker uses the pinned release image
- the worker comes back after reboot with the expected restart policy

## Node-by-node rollout rule
- Finish one node completely before moving to the next.
- Use the same validation pattern for each node, but preserve node-specific identity and storage.

## Suggested references
- `references/node01-done-done.md` — condensed node01 done-done sequence and sign-off expectations.
- `references/node02-greenfield-rebuild.md` — node02 replacement from stale `latest` to a clean pinned container.
