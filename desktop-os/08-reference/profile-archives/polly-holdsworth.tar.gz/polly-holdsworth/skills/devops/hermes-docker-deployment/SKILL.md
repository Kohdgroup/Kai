---
name: hermes-docker-deployment
description: Deploy and operate Hermes in Docker/Compose, including greenfield control-plane stacks, release pinning, and SSH-managed worker nodes.
category: devops
---

# Hermes Docker Deployment

Use this skill when the user wants a Hermes instance deployed in containers, upgraded to a specific release, or spread across a control plane plus remote worker nodes.

## Trigger conditions
- Greenfield Hermes install in Docker or Docker Compose
- Release-pinned Hermes deployment (e.g. `v2026.7.1` / `0.18.0`)
- Migrating an existing Hermes host to a clean container stack
- Remote worker nodes managed via SSH and Docker
- Need to verify Linear/API connectivity from the deployed stack

## Core model
Hermes-in-Docker uses a host-mounted data directory (official docs use `/opt/data`) for config, credentials, sessions, skills, and memories. Secrets go in the mounted `.env` file, while behavior lives in `config.yaml`.

## Greenfield notes from recent deployment work
- Treat the existing control plane as live until the new stack is validated beside it.
- Pin the Hermes image to the release tag before rollout; do not rely on `latest` for a greenfield rebuild.
- Replace stale worker artifacts explicitly: old `latest` containers, anonymous volumes, and inherited bootstrap paths should be removed before relaunching a worker node.
- Each worker node must keep its own identity (node-specific volume / storage identity) even when the runtime pattern matches the other nodes.
- Keep workers faceless and shared; do not recreate the older per-profile worker sprawl.
- Control-plane Linear writes should stay on the control plane: worker nodes produce evidence, while the control-plane runner creates issues/comments and posts the evidence back to Linear.
- Worker nodes must not require Linear credentials for dispatch tests or sign-off helpers.
- Use `DRY_RUN=1` first to inspect GraphQL payloads before any real Linear posting.
- Use per-step timeouts and fail-forward behavior for multi-node rollout scripts so one stalled node does not stale the whole run.
- The user is a product architect who wants decisive, time-efficient execution; do not spend time on avoidable clarification if the next action is obvious.
- Ask only for financial or legal decisions when the path is otherwise clear.
- Keep the human lattice explicit in the architecture:
  - Mai Matsuda = Chief Platform Engineer
  - Kai = pre-prod
  - Rai = production / orchestrator
  - Laura = delivery gate / Scrum Master
  - Eve = Chief of Staff / escalation / metrics
  - Quinn, Maya, Thomas, Amelia, Joseph = domain ownership roles
- Keep updates short and progress-oriented when reporting deployment status to the user.
- Preserve a narrow workstream and avoid context switching; surface one focused question at a time if blocking.
- Separate repo/docs/working-notes layers: Git repo for source-of-truth docs, Obsidian for working notes/visuals, Linear for execution, GoHighLevel for customer-facing docs/support.
- For memory, prefer self-hosted Honcho plus local Postgres, not cloud Honcho, when cost control and data locality matter.
- Capture the full Linear operating model in docs and tests:
  - sprint membership + issue state as the scope gate
  - actor-based Linear comments
  - evidence-backed done-done validation
  - test suite creation in Linear before large rollout steps
- Treat **Actor mode** as the full human lattice, not just a few core names:
  - Mai Matsuda (platform / control-plane persona)
  - Kai (pre-prod)
  - Rai (production / orchestrator)
  - Laura Bennett (delivery gate)
  - Eve Sterling (Chief of Staff / escalation / metrics)
  - Quinn Graham, Maya Khan, Thomas Advani, Amelia Cross, Joseph Webb for domain ownership
- When writing Linear comments from the control plane, use the relevant human actor voice where appropriate (including Mai as the platform persona) rather than generic bot phrasing.
- For autonomous node dispatch suites, keep Linear writes on the control plane only; worker nodes must never need Linear credentials.
- For worker-node rollout, use one node at a time with a timeout-safe step chain: inspect → remove stale container if needed → create fresh node-specific storage → pull pinned image → run → verify immediately.
- Replace stale `latest`-tag worker containers with pinned release containers before trusting a node.
- Give each node its own identity: node-specific container state, node-specific storage volume, and node-specific evidence trail if it diverges.
- Re-check live state after any reboot or restart; prior results go stale quickly.
- When running autonomous suite fan-out, capture stdout/stderr as node evidence first, then post the evidence from the control plane with the intended actor identity.

## Support files
- `references/docker-greenfield.md` — release-aligned control-plane + 9-node worker rollout notes from this session.
- `references/linear-validation-checklist.md` — Linear-first validation expectations, sprint gate rules, and done-done criteria from this session.
- `references/human-lattice.md` — named human role lattice and routing implications for the autonomy model.
- `references/linear-test-suite.md` — issue anchors and proposed validation suite structure for KS-3048 and related backlog items.
- `references/linear-actor-mode.md` — comment/update voice patterns for Mai, Kai, Rai, Laura, Eve, and the broader human lattice.
- `references/autonomous-control-plane-linear-suite.md` — control-plane Linear suite contract, dry-run pattern, and timeout/fail-forward guidance.
- `references/control-plane-linear-dispatch.md` — control-plane vs worker split, greenfield node replacement, timeout handling, and Linear posting shape from this rollout.

1. **Stay on one workstream at a time**
   - If the user asks to keep them focused, keep the active objective pinned and avoid introducing side quests, cleanup tangents, or redesigns that are not required for the current step.
   - Ask at most one clarification question at a time when a decision is needed.

2. **Inspect the host first**
   - Check whether existing containers already own the desired ports/volumes.
   - Confirm SSH access to every worker node before writing a compose file.

3. **Pin the release explicitly**
   - Prefer the exact tagged image for the target release instead of `:latest`.
   - Verify the tag exists before rollout.

4. **Use one data directory per Hermes stack**
   - Mount a dedicated host path to `/opt/data`.
   - Keep `.env` and `config.yaml` inside that directory.
   - Never share the same data directory between two running Hermes containers.

5. **Prefer Compose for the control plane**
   - Use `docker compose up -d` when the plugin exists.
   - Fall back to `docker-compose up -d` only if the plugin is missing.

6. **Treat worker nodes as independently managed Docker hosts**
   - Each node should run its own worker container with a unique node ID.
   - Use SSH to start, inspect, and verify the worker container on each host.

7. **Verify in layers**
   - Container status
   - Hermes logs
   - API connectivity (e.g. Linear)
   - Worker reachability and container health

8. **Model the operating roles explicitly**
   - For the greenfield GTM model, keep Linear as the system of record, Rai as orchestrator, Laura as delivery gate, Eve as escalation/metrics, and workers faceless.
   - Keep the architecture native and minimize custom glue.

## Common pitfalls
- Don’t assume `docker compose` and `docker-compose` are interchangeable; check which one exists on the target host.
- Don’t reuse an existing Hermes volume for a “greenfield” install if you want a clean slate.
- Don’t put non-secret behavior knobs in `.env`; keep those in `config.yaml`.
- Don’t declare the deployment done until you’ve checked both the control plane and at least one worker host.

## Verification checklist
- `docker ps` shows the control-plane services running
- the mounted data dir exists and contains `.env` and `config.yaml`
- the pinned Hermes image tag matches the intended release
- each worker host responds over SSH
- each worker host can run Docker commands successfully
- Linear/API integration is exercised from the deployed runtime

## Support files
- `references/docker-greenfield.md` — release-aligned control-plane + 9-node worker rollout notes from this session
- `references/linear-validation-checklist.md` — Linear-first validation expectations and done-done gate criteria from this session
- `references/human-lattice.md` — named human role lattice and routing implications for the autonomy model
- `references/linear-test-suite.md` — issue anchors and proposed validation suite structure for KS-3048 and related backlog items
- `references/linear-actor-mode.md` — comment/update voice patterns for Mai, Kai, Rai, Laura, Eve, and the broader human lattice
