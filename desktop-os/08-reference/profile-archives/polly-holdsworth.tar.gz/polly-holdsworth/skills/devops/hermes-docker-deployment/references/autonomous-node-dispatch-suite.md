# Autonomous node dispatch suite notes

## Session-derived rules
- The control plane owns all Linear writes.
- Worker nodes only execute checks and emit evidence.
- Each node needs its own named volume identity.
- Use pinned `nousresearch/hermes-agent:v2026.7.1`; reject `latest` for trusted nodes.
- Run one node at a time, with per-step timeouts and fail-forward behavior.
- Capture node host evidence first, then post the resulting text to Linear from the control plane.

## Evidence fields to capture from each worker
- UTC timestamp
- hostname / node label
- node IP
- container name
- image tag
- restart policy
- container status
- short log excerpt

## Linear write model
- Parent suite issue lives in Linear.
- Child node evidence is posted as comments from the control-plane runner.
- Use the intended actor identity for the comment author.
- Workers do not need Linear tokens.

## Avoid
- node-local Linear helpers that require credentials
- anonymous/stale volumes
- any fallback to `latest`
- long waits without fresh status checks
