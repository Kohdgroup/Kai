# Worker rollout timeouts and greenfield verification

## Proven pattern from node01–node06
- Inspect the target host first before changing anything.
- Use the control-plane server as the SSH hop to each worker.
- Prefer short, per-step timeouts over long polling loops.
- Replace stale `latest` worker containers with pinned `nousresearch/hermes-agent:v2026.7.1`.
- Give each worker its own named volume identity instead of reusing prior rollout artifacts.
- Set worker restart policy to `unless-stopped`.
- Verify immediately after start:
  - image tag
  - running status
  - restart state
  - exit code
  - restart policy
  - mount identity
  - fresh logs

## Anti-patterns observed
- Direct SSH from the local machine when the control-plane hop is the intended path.
- Long stale loops without refreshing live state before acting.
- Reusing old `latest` containers for a greenfield worker.
- Reusing anonymous or legacy volume identity when a node-specific named volume is required.
- Treating a host reboot as proof that the worker container is back; verify the container separately.

## Recommended node-by-node sequence
1. Inspect current container and volume state.
2. Remove stale `hermes-worker` if it is a `latest`/legacy artifact.
3. Create a fresh node-specific named volume.
4. Pull `nousresearch/hermes-agent:v2026.7.1`.
5. Run `hermes-worker` with `--restart unless-stopped` and `gateway run`.
6. Wait briefly, then inspect the container state and logs.
7. Record evidence in Linear.
8. Move to the next node only after the current node is verified.

## Verification snippet shape
- Use a one-shot readiness check.
- Use a one-shot smoke check (`hermes doctor` or equivalent).
- If sign-off is needed, write the final status back to Linear with the appropriate human actor.
