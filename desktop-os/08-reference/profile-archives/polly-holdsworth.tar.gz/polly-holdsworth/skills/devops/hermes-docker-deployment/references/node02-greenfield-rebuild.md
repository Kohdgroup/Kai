# node02 Greenfield Rebuild Notes

## What changed
- Replaced stale `nousresearch/hermes-agent:latest` node02 container.
- Created a fresh named volume: `kohd-worker-node02-data`.
- Relaunched node02 with pinned image `nousresearch/hermes-agent:v2026.7.1`.
- Set restart policy to `unless-stopped`.
- Verified the worker starts cleanly and the gateway logs show the normal s6 startup path.

## Verified runtime shape
- Image: `nousresearch/hermes-agent:v2026.7.1`
- Restart policy: `unless-stopped`
- Command: `gateway run`
- Entry point: `/init` + `/opt/hermes/docker/main-wrapper.sh`
- Data path: `/opt/data`
- Storage identity: `kohd-worker-node02-data`

## Lesson
For greenfield worker rollouts, do not try to “save” a stale node by just starting the old container. Replace the old artifact with a pinned clean-room container and a node-specific storage identity.
