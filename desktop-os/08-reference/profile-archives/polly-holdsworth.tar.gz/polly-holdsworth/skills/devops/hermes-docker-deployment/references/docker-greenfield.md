# Hermes GTM greenfield deployment notes

Session-specific deployment notes for the Hermes GTM control plane and worker pool.

## Target shape
- Control plane: `192.168.60.10`
- Workers: `192.168.60.11`–`192.168.60.19` now, expand to 22 later
- Workers are faceless shared execution nodes
- Named control-plane actors: Rai, Laura, Eve, plus domain leads only if they still map to active Linear ownership

## Current architecture decisions
- Linear is the system of record for work, comments, blockers, approvals, and done-done sign-off
- GoHighLevel is the customer-facing support/docs platform
- Obsidian is for working notes and visuals
- Git repo is the authoritative source for architecture/runbooks
- Redis is the operational state layer
- Self-hosted Honcho + local Postgres are required for persistent memory
- Hermes built-in memory remains enabled for curated core facts

## Control-plane docs/repo split
- `Hermes GTM` repo: version-controlled architecture, runbooks, and operating model docs
- `deployment/`: greenfield compose files and runbooks
- `docs/`: target-state architecture and Linear operating model
- `profiles/`: first-name-only lead profiles

## Validation pattern
1. Validate current live stack first
2. Draft new greenfield files beside the live stack
3. Verify pinned image/tag exists before rollout
4. Bring up new stack and inspect logs
5. Only then proceed to Linear test-suite creation

## User preference reminders
- Keep updates short and progress-oriented
- Ask one focused clarification question at a time
- Avoid broad option dumps unless the user asks for them
- Keep the workstream narrow and prevent context switching

## Useful verification targets
- `docker ps` on control plane
- SSH + Docker on worker nodes
- Pinned Hermes image tag `v2026.7.1`
- Local Postgres + Honcho stack present for memory
- Linear workflow tests created before declaring deployment done
