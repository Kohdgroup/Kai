# Linear-first validation checklist for Hermes GTM

Session notes for the Linear-first validation step that will happen after the greenfield control-plane deployment.

## Scope
- Validate sprint scoping and in-scope issue selection
- Validate actor-based comments
- Validate blocker escalation to the user via Telegram
- Validate evidence-based completion before issues are marked done
- Create a Linear test suite to prove the target operating model end to end

## Working assumptions
- Linear is the system of record for internal work
- GoHighLevel handles customer-facing docs/support
- Rai posts comments and dispatch status back into Linear
- Laura manages sprint alignment and delivery gate decisions
- Eve handles escalation/risk/metrics and daily blocker surfacing

## Expected test-suite areas
1. Ready issue selection
2. Sprint membership filtering
3. Actor comment formatting
4. Blocker detection and escalation
5. Evidence posting
6. Done-done gate enforcement

## Reminder
Keep the test suite native and minimal. Prefer Linear-native constructs over custom side systems unless a real gap appears.
