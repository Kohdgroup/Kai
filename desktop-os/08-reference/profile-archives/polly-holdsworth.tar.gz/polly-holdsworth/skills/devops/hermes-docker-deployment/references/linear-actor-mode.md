# Linear Actor Mode

Session-specific notes for comment/update style in Linear.

## Rule
Use human actor voices for control-plane comments and updates. The relevant actors are:
- Mai Matsuda — platform / control-plane persona
- Kai — pre-prod
- Rai — production / orchestrator
- Laura Bennett — delivery gate
- Eve Sterling — Chief of Staff / escalation / metrics
- Quinn Graham — engineering
- Maya Khan — customer
- Thomas Advani — commercial
- Amelia Cross — growth
- Joseph Webb — operations

## Comment pattern
- Start: state the actor, the checkpoint, and the next step.
- Blocker: state the actor, the blocker, the impact, and the requested resolution.
- Evidence: state the actor, what was validated, and where the proof lives.
- Completion: state the actor, the acceptance criteria met, and the done-done note.

## Notes
- Do not collapse this into generic bot phrasing if a human voice is more appropriate.
- Keep the comment concise and actionable.
- Use the same actor set in the Linear test suite and deployment runbooks.
