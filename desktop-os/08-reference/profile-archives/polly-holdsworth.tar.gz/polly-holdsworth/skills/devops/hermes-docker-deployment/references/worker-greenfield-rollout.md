# Worker Greenfield Rollout Notes

Session-derived notes for rolling workers node-by-node in a clean-room fashion.

## Verified pattern
- Replace stale `nousresearch/hermes-agent:latest` worker containers.
- Create a fresh node-specific named volume, e.g. `kohd-worker-node02-data`.
- Run the pinned image: `nousresearch/hermes-agent:v2026.7.1`.
- Use `--restart unless-stopped`.
- Mount the node volume at `/opt/data`.
- Verify immediately after start with `docker inspect` and recent logs.

## Identity / cleanup rules
- Each worker node gets its own storage identity.
- Do not reuse anonymous/bind-mounted leftover rollout state when a fresh named volume is expected.
- If a node has a stale container from an earlier rollout, remove it before relaunching.
- Treat `latest` on worker nodes as stale unless the node is explicitly in a legacy comparison task.

## Timeout-safe verification
- Prefer a control-plane hop when verifying remote workers.
- Use per-step timeouts: inspect state, smoke test, log readback, then move on.
- After reboot, verify live state immediately instead of trusting the pre-reboot snapshot.

## Linear evidence pattern
- Post a short actor-style comment for each node.
- Include node host evidence: timestamp, image tag, restart policy, and mount identity.
- Keep the parent issue updated with node-by-node results and exceptions.

## Example proof fields
- host timestamp
- node hostname/IP
- container name
- image tag
- restart policy
- volume name
- a short log excerpt showing normal startup under s6
