# Autonomous Control-Plane Linear Suite Notes

## What this session established
- Linear GraphQL credentials belong on the control plane only.
- Worker nodes should not receive Linear tokens or post directly to Linear.
- The control-plane suite runner should:
  1. create a parent suite issue or reuse one
  2. create a per-node issue for node02–node09
  3. run readiness and smoke checks on each worker via the server hop
  4. capture node host evidence (timestamp, node name/IP, container image, status, restart policy, log tail)
  5. post evidence comments from the control plane using the appropriate actor name
- Use a dry-run mode first so the exact Linear GraphQL payloads are visible before posting.

## Control-plane execution contract
Required control-plane env:
- `LINEAR_TOKEN`
- `LINEAR_PARENT_ISSUE_ID`
- `LINEAR_TEAM_ID`

Optional env:
- `LINEAR_WORKER_NAME` (defaults to Kai Matsuda)
- `RUN_ID`
- `STEP_TIMEOUT`
- `DRY_RUN=1` to inspect payloads without posting

## Operational pattern
1. Bootstrap on the control plane.
2. Verify worker health using server-hop SSH.
3. Capture the proof output locally in the runner.
4. Post the proof back to the parent Linear issue from the control plane.
5. Keep worker scripts free of Linear auth.

## Pitfalls
- Do not push Linear posting into worker-side scripts.
- Do not skip the dry-run pass when wiring a new suite.
- Do not let one stalled node block the rest; use per-step timeouts and fail-forward behavior.
- Do not assume env vars exist in the shell; verify the control-plane source of truth before execution.
