# Freshness Evidence Pattern

## Use case
Use this pattern when a process has been running for a while and the agent needs to confirm the current state before reporting progress.

## Minimum evidence set
- Current UTC timestamp
- Process/container state
- Recent log tail
- Any successful command execution proving the service is still alive and doing work

## Reporting rule
If the fresh evidence does not match the previously reported state, report the fresh evidence and correct the record immediately.
