# Worker Greenfield Rebuild: Freshness Case

## What happened
A worker rollout was assumed healthy because containers were present, but freshness checks showed:
- some nodes restarting instead of staying stable
- legacy artifacts still present on the hosts
- worker containers running `nousresearch/hermes-agent:latest` instead of the pinned `nousresearch/hermes-agent:v2026.7.1`
- an interactive gateway startup path being used for a faceless worker role

## Why it mattered
The runtime looked active, but the rollout was not a true greenfield rebuild. The mismatch between control plane and workers created a semi-stale state that was easy to misread without re-checking logs, image tags, and host files.

## Freshness signals that exposed the drift
- `docker ps` showed restart loops on some nodes
- `docker inspect` revealed `latest` on workers rather than the pinned version
- host directories still contained tarballs, patch files, and old node-specific artifacts
- logs showed the service starting and then shutting down cleanly rather than behaving like a stable worker

## Lesson
For worker fleets, a freshness check must include:
1. image tag verification
2. restart policy and state
3. host-side legacy artifact scan
4. startup mode review (interactive vs faceless)
5. comparison against the pinned baseline used by the control plane

## Recommended verification snippet
- `docker inspect <container> --format '{{.Config.Image}} {{json .Config.Cmd}} {{json .Config.Entrypoint}}'`
- `docker ps --format '{{.Names}} {{.Status}} {{.Image}}'`
- host file inventory for tarballs, env files, JSON manifests, and patch leftovers

## Status rule
If any worker differs from the pinned baseline or still depends on legacy artifacts, do not call the fleet stable.
