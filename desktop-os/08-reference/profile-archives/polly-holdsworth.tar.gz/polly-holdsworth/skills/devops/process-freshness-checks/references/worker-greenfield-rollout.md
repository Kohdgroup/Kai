# Worker Greenfield Rollout Freshness Notes

## Session-derived lessons
- Treat every worker node as a clean-room greenfield node.
- Do not reuse historic rollout artifacts (tarballs, node-local env files, old JSON/patch files, old custom bootstrap scripts) when a pinned greenfield rebuild exists.
- Pin all workers to `nousresearch/hermes-agent:v2026.7.1`; do not mix `latest` and pinned tags in the same fleet.
- Use one node as the golden template first (node01), then expand only after the node holds steady.
- A worker is not considered stable just because it is "Up"; verify restart state, exit code, logs, and repeated checks over time.

## Node01 stability loop pattern
1. Confirm the container is running and not restarting.
2. Inspect the startup logs for a stable s6/gateway sequence.
3. Repeat the check several times over a short window.
4. Only promote the node to the golden baseline if status, restart flag, and exit code remain unchanged.
5. If the node stays up, use it as the template for the other workers.

## Common drift to watch for
- Legacy KOHD/worker-client files still present on disk.
- Old container names or scripts that point at `hermes:latest`.
- Mixed worker versions across the fleet.
- Restart loops caused by an interactive startup path on a non-interactive node.
