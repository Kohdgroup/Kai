---
name: process-freshness-checks
description: Use when local processes, containers, or long-running services have been running for a while and may have drifted from the intended state. Re-verify status, logs, env, ports, and key outputs to catch mistakes early.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [process, freshness, validation, long-running, drift, containers]
    related_skills: [linear-freshness-guard, linear-accurate-updates]
---

# Process Freshness Checks

## Overview
Use this skill for long-running local services, control-plane containers, background jobs, and other processes that can look healthy while silently drifting, misconfiguring, or accumulating stale state.

The goal is not constant polling. The goal is to perform deliberate freshness checks after a process has been running for a while, after a deploy, after a restart, or whenever the workstream has moved on and you want to catch mistakes before they become hidden problems.

For a concrete worker-fleet example, see `references/worker-greenfield-rollout.md`.
For the node02 rebuild example, see `references/node02-greenfield-rebuild.md`.

For worker fleets, always check image tag pinning, restart state, and host-side legacy artifacts before trusting the rollout.

## When to Use
- A container, daemon, or background service has been up for a while
- A deployment just completed and you want to verify the system did not drift
- You suspect stale env, config, or mount state
- You want to catch subtle mistakes that a single start-up check would miss
- You need to validate a process before trusting it for subsequent work

## What to Check
1. **Process state**
   - Is the process/container still running?
   - Has it restarted unexpectedly?
   - Has the uptime changed in a suspicious way?

2. **Logs**
   - Look for recent errors, warnings, retries, or config migration messages.
   - Confirm there is no hidden failure masked by a healthy status.

3. **Environment and config**
   - Re-check important env vars, config files, and mounted paths.
   - Confirm secrets are present where expected and not blank.

4. **Ports and connectivity**
   - Confirm the expected ports are still bound.
   - Probe the real endpoint or protocol used by the service.

5. **Source-of-truth alignment**
   - Compare current runtime state against the canonical record.
   - If the canonical record has changed, update the runtime or note the drift.

## Freshness Pattern
1. Capture the current state.
2. Compare it against the intended state.
3. Re-read the most important logs and env values.
4. Re-validate the service endpoint or command path.
5. Record any drift immediately.
6. If the process is long-running, repeat the check at the next meaningful checkpoint rather than continuously.

## Common Mistakes
- Trusting a container just because it is still “Up”
- Assuming a service is fine because it started cleanly hours ago
- Ignoring config drift after a redeploy
- Treating a blank env file as if it were valid
- Skipping log review because the service already passed an initial smoke test

## Verification Checklist
- [ ] Process is still running and expected uptime looks sane
- [ ] Logs show no new hidden errors or repeated failures
- [ ] Important env/config values are still present and correct
- [ ] Ports/endpoints still respond as expected
- [ ] Runtime state matches the canonical source of truth
- [ ] Any drift found is recorded and corrected immediately
