# Remote control-plane notes

Current session findings for Hermes Docker deployment and Linear wiring.

## Verified host
- Control plane host: `192.168.60.10`
- SSH user: `administrator`

## Access and runtime
- SSH to the control plane works.
- Docker is installed and functional.
- The host has `docker-compose` available as a standalone binary.
- The `docker compose` plugin is not present on this host, so use `docker-compose` for Compose operations.

## Existing containers
- `rai-dispatcher` is already running.
- `hermes-redis` is already running.
- `hermes-postgres` is already running.

## Existing config files
- `/home/administrator/hermes-dispatch/config.yaml` exists.
- That config already points Linear integration at `LINEAR_API_KEY` and lists worker nodes `192.168.60.11` through `192.168.60.19`.
- `/opt/hermes-workspace/docker-compose.yml` exists and defines a workspace UI container pointing `HERMES_API_URL` at `http://192.168.60.10:8642`.
- No `.env` file was present in `/opt/hermes-workspace` or `/home/administrator/hermes-dispatch` at the time of inspection.

## Useful verification commands
Run these on the control plane host:

```bash
docker ps --format 'table {{.Names}}\t{{.Image}}\t{{.Status}}\t{{.Ports}}'
cd /opt/hermes-workspace && docker-compose ps
sed -n '1,220p' /home/administrator/hermes-dispatch/config.yaml
```

## Notes
- The Linear API key must be available to the service process that actually talks to Linear, not just to the chat session.
- If Compose brings up the workspace but Linear actions fail, check whether the dispatcher container receives the correct env file.
- When a host has `docker` but not `docker compose`, prefer the legacy `docker-compose` command rather than spending time trying to install the plugin first.
