---
name: hermes-docker-fleet
description: Deploy and operate Hermes as a Docker-based control plane with remote worker nodes, dispatcher services, and external integrations like Linear.
category: devops
version: 1.0.0
---

# Hermes Docker Fleet Deployment

Use this skill when the user wants to run Hermes in Docker on a control-plane host, connect remote worker nodes over SSH, or wire the deployment to external services such as Linear.

## What this covers

- Hermes running **in Docker** on a remote host
- Control-plane services such as dispatcher, PostgreSQL, Redis, and workspace UI
- Remote worker nodes that join via SSH or container orchestration
- Environment variable wiring for secrets such as `LINEAR_API_KEY`
- Health checks, container verification, and end-to-end smoke tests

## Quick workflow

1. **Confirm the target host and access path**
   - Verify SSH connectivity to the intended control-plane host.
   - Confirm whether the host uses `docker compose` or legacy `docker-compose`.
   - Do not assume both are installed.

2. **Inspect the existing deployment state**
   - Look for existing compose files, dispatcher configs, env files, and running containers.
   - Reuse existing control-plane services when present instead of recreating them blindly.

3. **Provision secrets and service environment**
   - Put runtime secrets in the service `.env` used by Docker Compose.
   - Keep `LINEAR_API_KEY` available to the dispatcher or integration service that actually calls Linear.
   - Ensure database and queue URLs match the live container topology.

4. **Start or restart the control plane**
   - Bring up PostgreSQL, Redis, dispatcher, and any workspace/UI service.
   - Validate with `docker ps`, `docker-compose ps`, and service logs.

5. **Add or update worker nodes**
   - Use one worker per remote node or container slot.
   - Give each worker a stable node ID.
   - Keep workers restartable and observable.

6. **Verify integrations**
   - Test the Linear path first.
   - Then validate dispatch/evidence flow and any worker fan-out path.

## Common pitfalls

- Some hosts have `docker` but **not** the Compose v2 plugin. Fall back to `docker-compose` if needed.
- Remote deployments often already have partially running services. Check first so you do not break a working control plane.
- Linear wiring can be present in config while still failing at runtime if the service `.env` is missing or stale.
- Worker-node IP lists and SSH reachability should be verified from the control-plane host before assuming the fleet is healthy.

## Verification checklist

- `docker ps` shows the dispatcher, database, and queue services up.
- Compose files match the actual host layout.
- The service environment includes the Linear key where needed.
- Worker nodes are reachable and accounted for.
- A Linear API probe or dispatcher smoke test succeeds.

## Session-specific notes

- See `references/remote-control-plane-notes.md` for the concrete findings from the current deployment session.
