Linear GraphQL auth for this workflow belongs on the control plane and should never be stored on worker nodes.
§
Kai Matsuda is pre-production only; Rai Matsuda owns the production control plane; Mai Matsuda is the platform architect across platforms within the Matsuda governance family line.
§
User prefers Hermes-native autonomous work to use Linear as system of record, named control-plane profiles, and faceless workers for actual execution.