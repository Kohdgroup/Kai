Greenfield Hermes: 9 Dockerized workers now (192.168.60.11-192.168.60.19), control plane 192.168.60.10, Redis ops, Honcho+local Postgres memory.
§
User has Linear OAuth actor labels: Laura Bennett, Maya Khan, Quinn Graham, Thomas Advani, Amelia Cross, Joseph Webb, Eve Sterling, Rai Matsuda, Kai Matsuda, and Mai Matsuda; do not store or repeat their secrets/tokens.
§
For Linear actor-mode comments, use the appropriate human worker for the workstream rather than a fixed default.
§
Linear actor mapping: Mai=platform/admin/integrations; Kai=pre-prod/validation; Rai=production/incidents.
§
Do not complete node02-09 until node01 is confirmed done-done first.
§
User prefers Hermes-native, Linear-first autonomous workflows with faceless workers; profiles should heartbeat and then claim a unique Linear work signal to begin work.
§
For Linear actor-mode comments and ownership, use the relevant OAuth human/app identity; do not use the personal API-key identity.
§
User wants KOHD/ADF architecture work to maintain a versioned platform registry and solution blueprint, with Laura owning sprint slicing.