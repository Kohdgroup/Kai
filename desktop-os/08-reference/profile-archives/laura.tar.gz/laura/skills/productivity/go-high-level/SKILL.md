---
name: go-high-level
description: Use when a project depends on Go High Level (GHL) for CRM, pipelines, automations, messaging, or client operations. Identify the account/workflow scope, configure access, and keep the integration reusable across projects.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [go-high-level, ghl, crm, automation, messaging, workflows, reusable]
    related_skills: [adf-platform-dependency-framework, linear-native-operating-model, linear-accurate-updates]
---

# Go High Level

## Overview

Use this skill when a project depends on Go High Level as an external operating platform for CRM, pipelines, automations, conversations, or client management.

This skill is intentionally platform-focused rather than project-specific. It helps you identify the minimum reusable workflow for GHL so later projects can reuse the same setup, validation, and update pattern.

## When to Use

- The project needs Go High Level as a CRM or workflow platform
- You need to manage pipelines, automations, forms, conversations, or client records
- A project requires a reusable GHL integration pattern rather than a one-off manual process
- You need to decide whether GHL is the system of record, execution layer, or notification layer

## Workflow

### 1) Identify the GHL role in the project
Classify the platform’s role before doing any configuration:

- **System of record** — client/contact truth, pipeline state, or conversation history
- **Execution layer** — automation triggers, task routing, follow-up sequences
- **Messaging layer** — SMS, email, call handling, or conversation capture
- **Reporting surface** — pipeline metrics, attribution, or client status reporting

### 2) Confirm the access method
Use the smallest access model that actually works for the project:

- Native GHL UI for manual operations
- GHL API when the workflow needs repeatability
- Webhooks or automation triggers when the project needs event-driven updates
- MCP or middleware only if the workspace already has a supported connector pattern

### 3) Standardize the workspace inputs
Capture the reusable values the project will need every time:

- account / sub-account ID
- pipeline name
- automation name
- contact owner / assignee model
- message channel used
- reporting fields needed by the delivery lead

### 4) Validate the smallest useful loop
A GHL setup is only real when a minimal loop works end to end:

- create or locate a contact / record
- move or update the pipeline state
- trigger or observe the automation
- confirm the downstream message or note appears where expected

### 5) Write back to Linear
When GHL is part of the project, keep the current truth in Linear:

- what GHL is responsible for
- what is configured already
- what still needs automation or cleanup
- what failed during validation

## Pitfalls

- Do not assume every GHL project needs the same pipelines or automations.
- Do not encode client-specific campaign logic directly into a reusable skill.
- Do not treat the visual pipeline as proof unless the underlying automation and data paths were verified.
- Do not let message handling drift away from the project’s reporting requirements.

## Verification Checklist

- [ ] GHL’s role in the project is classified
- [ ] Access method is known
- [ ] The reusable account/workspace inputs are recorded
- [ ] A minimal contact/pipeline/automation loop was validated
- [ ] The resulting truth was written back into Linear
