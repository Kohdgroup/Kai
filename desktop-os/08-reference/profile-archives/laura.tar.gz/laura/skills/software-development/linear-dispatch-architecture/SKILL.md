---
name: linear-dispatch-architecture
description: "Use when designing or revising Hermes control-plane, worker, and governance architecture around Linear as the system of record. Keeps the model aligned to current release behavior, native-first deployment choices, actor-based Linear comments, and evidence-backed completion."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [linear, dispatch, orchestration, workers, governance, deployment, architecture]
    related_skills: [hermes-agent, plan, requesting-code-review]
---

# Linear-Driven Hermes Dispatch Architecture

## Overview

Use this skill when the user is shaping the Hermes operating model around Linear, control-plane governance, worker execution, and evidence-backed completion.

This skill favors the smallest native-first design that matches the latest Hermes release behavior and the user's live Linear reality. It is especially relevant when the user wants to avoid over-engineering, keep Linear as the source of truth, and design for both current worker capacity and near-term expansion.

## When to Use

- The user asks how to structure Hermes control-plane orchestration around Linear
- The user wants a greenfield or refactored deployment aligned to the latest Hermes release
- The user needs actor-based comments, blocker escalation, or daily standup routing
- The user is deciding between named profiles and faceless workers
- The user wants a deployment that can grow from a smaller worker pool to a larger one without a rewrite
- The user explicitly says Linear is the system of record

## Core Model

- **Linear is the system of record** for work intake, status, comments, blockers, and completion evidence.
- **Rai** is the orchestrator, not the worker.
- **Control-plane actors** may be named and human-readable where identity matters.
- **Worker nodes** should be faceless shared execution nodes whenever identity does not add value.
- **Comments and blockers** must be written back into Linear so the record stays complete.
- **Done means proven**: an issue is only complete when the business requirement and validation evidence are satisfied.

## Release-Alignment Rule

Before using an older architecture document, reconcile it against the current Hermes release notes and baseline release behavior.

Default assumptions for v2026.7.1-era planning:
- MoA / mixture-of-agents is a first-class option
- verification and completion contracts matter
- background fan-out is supported
- scale-to-zero and drain coordination are intended behaviors
- `/learn` and `/journey` are part of the self-improvement loop

Do not let an older plan overrule these unless the user explicitly wants legacy behavior preserved.

## Architecture Heuristics

### Prefer native over custom
Choose the simplest native Hermes / Docker / Linear path that meets the need.

Good:
- Hermetic Docker deployment
- Native Hermes release image pinned to the release tag
- Linear API integration for intake and comments
- Simple worker containers with shared execution identity

Avoid by default:
- Custom orchestration layers that duplicate Linear
- Complex identity-per-worker schemes when faceless workers are enough
- Local queues that become a second source of truth
- Over-engineered profile sprawl across dozens of identities

### Separate identity from execution
A useful default split is:
- **Named control-plane actors** for governance, approvals, escalation, and comments
- **Faceless worker nodes** for execution, validation, and artifact generation

If the user later asks for more named identities, add them only where a business or governance role genuinely needs a voice.

### Design for expansion without redesign
If the user says the pool may grow, design the deployment so a 9-node baseline can expand cleanly to a larger pool later.

That means:
- stable naming conventions
- node lists or inventories that are easy to extend
- worker configuration that is templated, not hand-crafted per node
- no coupling that assumes the pool size is forever fixed

## Questioning Style

When the operating model is still being shaped, ask **one question at a time**.

This matters because:
- multi-part clarification grids trigger premature design commitments
- the user often wants the next highest-value decision, not a long menu
- it keeps the architecture converging instead of re-litigating the whole stack

Use one focused question until the next key decision is clear.

## Linear Commenting Pattern

When the user wants actor-based comments in Linear:

- write comments in the voice of the right actor
- include the business meaning of the update
- capture real blockers explicitly
- include evidence links or validation outputs when available
- distinguish approval, clarification, escalation, and completion comments
- for start-of-work situations, pair the comment with the native dispatch signal and kickoff child issue so the lead can actually act in Linear

A good comment should make the issue state legible without needing the chat thread.

## Standup / Blocker Escalation Pattern

When the user wants blockers raised via Telegram daily standup:

- keep the standup short and action-oriented
- only escalate what the user actually needs to unblock
- include the issue identifier, blocker type, and next action
- do not bury urgent blockers in a long progress recap

## Common Pitfalls

1. **Assuming the older V3 architecture is still authoritative.**
   Check the latest release behavior first.

2. **Turning workers into identity-heavy actors.**
   Shared faceless execution nodes are usually better when the work is mechanical and repeatable.

3. **Creating a second work-tracking system.**
   If Linear is the source of truth, keep it that way.

4. **Marking work done without evidence.**
   The finish line is business validation, not just successful execution.

5. **Asking too many questions at once.**
   Ask the single decision that unlocks the next design step.

## Verification Checklist

- [ ] Linear remains the source of truth
- [ ] Control-plane actors are only named where identity matters
- [ ] Worker nodes remain faceless shared execution nodes
- [ ] Comments and blockers are written back to Linear
- [ ] Completion requires evidence, not vibes
- [ ] The design respects the latest release baseline
- [ ] Expansion to a larger worker pool does not require a rewrite

## Reference Material

See `references/linear-dispatch-architecture.md` for session-specific decisions, release-alignment notes, and current open topology choices.

See `references/native-dispatch-start-signal.md` for the KOHD native dispatch pattern: visible start signal, kickoff child issue, and what counts as actually underway.

